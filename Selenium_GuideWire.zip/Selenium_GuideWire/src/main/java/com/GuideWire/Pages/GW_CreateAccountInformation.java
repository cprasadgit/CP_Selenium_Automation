package com.GuideWire.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


public class GW_CreateAccountInformation {

	WebDriver driver;
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


	public GW_CreateAccountInformation(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "CreateAccount-CreateAccountScreen-CreateAccountDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-AddressLine1")
	WebElement txt_Address1;

	@FindBy(name = "CreateAccount-CreateAccountScreen-CreateAccountDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-City")
	WebElement txt_City;

	@FindBy(name = "CreateAccount-CreateAccountScreen-CreateAccountDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-PostalCode")
	WebElement txt_Postal;
	
	@FindBy(name = "CreateAccount-CreateAccountScreen-CreateAccountDV-AddressInputSet-globalAddressContainer-GlobalAddressInputSet-State")
	WebElement cmbState;
	
	@FindBy(name="CreateAccount-CreateAccountScreen-CreateAccountDV-AddressType")
	WebElement cmbAddressType;
	
	@FindBy(xpath = "//*[@id=\"CreateAccount-CreateAccountScreen-CreateAccountDV-ProducerSelectionInputSet-Producer-SelectOrganization\"]/span")
    WebElement SearchOrganization;
		
	@FindBy(name="OrganizationSearchPopup-OrganizationSearchPopupScreen-OrganizationSearchDV-GlobalContactNameInputSet-Name")
	WebElement txtOrganizationName;
	
	
	@FindBy(id="OrganizationSearchPopup-OrganizationSearchPopupScreen-OrganizationSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Search")
	WebElement btnOrganizationSearch;

	@FindBy(xpath = "//*[@id=\"OrganizationSearchPopup-OrganizationSearchPopupScreen-OrganizationSearchResultsLV-0-_Select\"]/div/div[2]")
    WebElement btnSelectOrganization;
	
	@FindBy(xpath = "//*[@id=\"CreateAccount-CreateAccountScreen-CheckForDuplicates\"]/div/div[2]")
	WebElement btnCheckduplicates;
	
	@FindBy(xpath = "//*[@id=\"CreateAccount-CreateAccountScreen-ForceDupCheckUpdate\"]/div/div[2]")
	WebElement btnCreateAccountUpdate;
	
	@FindBy(xpath ="//*[@id=\"AccountFile_Summary-ttlBar\"]/div[1]/div")
	WebElement lblAccountSummary;
	
	@FindBy(xpath = "//*[@id=\"AccountFile_Summary-AccountSummaryDashboard-AccountDetailsDetailViewTile-AccountDetailsDetailViewTile_DV-AccountNumber\"]/div/div")
    WebElement lblAccountNumber;	
	
	public void setAddress(String Address1) {
		txt_Address1.sendKeys(Address1);
	}

	public void setCity(String City) {

		txt_City.sendKeys(City);
	}

	public void setPostal(String Postal) throws InterruptedException {


		    	txt_Postal.sendKeys(Postal);
	}
	
	
	  public void selectState(String State) throws InterruptedException {
		  cmbState.click();
		    
		    // 2. Perform the selection
			/*
			 * Thread.sleep(2000); Select CreateAccountState = new Select(cmbState);
			 * CreateAccountState.selectByVisibleText("Alabama");
			 */  
		    WaitUtils.selectByText(driver, cmbState, State);
	  }
	 
	
	public void selectAddressType(String CreateAccountAddressType) throws InterruptedException {		
		cmbAddressType.click();  
		
		/*
		 * Select CreateAccountAddressType = new
		 * Select(cmbAddressType);
		 * CreateAccountAddressType.selectByVisibleText("Billing");
		 */    
	                
	    		    WaitUtils.selectByText(driver, cmbAddressType, CreateAccountAddressType);	                
			
		}
	
	public void OrganizationSearchIcon() {
		SearchOrganization.click();
	}
		
	public void Organization(String OrganizationName) {
			
		txtOrganizationName.sendKeys(OrganizationName);
	
	}
	public void OrganizationSearch() {
	
	btnOrganizationSearch.click();
	}
	
	public void SelectOrganization() {
		btnSelectOrganization.click();
	}
	
	public void CheckDuplicate() {
		btnCheckduplicates.click();
	}
	
	public void AccountUpdate() {
		btnCreateAccountUpdate.click();
	}
	
	public void clickAccountSummary() {
		
		WaitUtils.clickElement(driver, lblAccountSummary);
		String labeltextOfAccountSummary = lblAccountSummary.getText();
		System.out.println(labeltextOfAccountSummary);
		String labelAccountText = lblAccountNumber.getText();
		System.out.println("Account Number: " + labelAccountText);
		
	}
	
}

