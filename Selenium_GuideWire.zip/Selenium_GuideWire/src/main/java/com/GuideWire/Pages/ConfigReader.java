package com.GuideWire.Pages;
	import java.io.FileInputStream;
	import java.io.IOException;
	import java.util.Properties;

import net.datafaker.Faker;

	public class ConfigReader {
	    private static Properties properties;

	    static {
	        try {
	            // Path to the properties file
	            FileInputStream fis = new FileInputStream("config.properties");
	            properties = new Properties();
	            properties.load(fis);
	        } catch (IOException e) {
	            e.printStackTrace();
	            throw new RuntimeException("Could not load config.properties file.");
	        }
	    }

	    public static String getProperty(String key) {
	        return properties.getProperty(key);
	    }
	    
	    private static final Faker faker = new Faker();
	    
	 // Method to get a completely random name via Datafaker
	    public static String generateRandomFirstName() {
	    	return faker.name().firstName();
	    }
	    public static String generateRandomLastName() {
	    	return faker.name().lastName();
	    }	    
	}


