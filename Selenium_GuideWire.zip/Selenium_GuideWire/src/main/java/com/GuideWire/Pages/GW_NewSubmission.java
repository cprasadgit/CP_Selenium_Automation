package com.GuideWire.Pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GW_NewSubmission {
	 WebDriver driver;
	  
	 public GW_NewSubmission(WebDriver driver) { this.driver = driver;
	  PageFactory.initElements(driver, this); }
	 
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

	 
	 @FindBy(xpath = "//*[@id=\"TabBar-AccountTab\"]/div[3]/div")
	 WebElement dropdownAccount;
	 
	@FindBy (xpath="//*[@id=\"TabBar-AccountTab-AccountTab_AccountNumberSearchItem\"]/div/input") 
	WebElement searchAccount;
	
    @FindBy (xpath = "//*[@id=\"TabBar-AccountTab-AccountTab_AccountNumberSearchItem_Button\"]") 
	WebElement searchIcon;
    
    @FindBy(xpath = "//*[@id=\"AccountFile_Summary-AccountSummaryDashboard-OpenPolicyTransactionsAccountListViewTile-NewSubmission\"]/div/div[2]" )
    WebElement btnNewSubmission;
    
    
    @FindBy(id="NewSubmission-NewSubmissionScreen-ProductOffersDV-ProductSelectionLV-5-addSubmission")
    WebElement btnHomeOwner;
    
    
    
    @FindBy(name ="SubmissionWizard-SubmissionWizard_PreQualificationScreen-CoveragePartSelectionDV-HOPCoveragePartType")
    WebElement selectPolicyType;

   @FindBy(name = "SubmissionWizard-SubmissionWizard_PreQualificationScreen-CoveragePartSelectionDV-HOPCoverageForm")
    WebElement selectCoverageForm;
   
    
    @FindBy(name = "SubmissionWizard-SubmissionWizard_PreQualificationScreen-PreQualQuestionSetsDV-QuestionSetsDV-0-QuestionSetLV-2-QuestionModalInput-ChoiceSelectInput")
     WebElement drpselectdwelling;
    
    
    @FindBy(id= "SubmissionWizard-SubmissionWizard_PreQualificationScreen-PreQualQuestionSetsDV-QuestionSetsDV-0-QuestionSetLV-3-QuestionModalInput-BooleanRadioInput_0")
	 WebElement  rdodwelling;
    
    @FindBy(xpath = "//*[@id=\"SubmissionWizard-Next\"]/div/div[2]")
    WebElement  btnQulificationNext;
    
    
    @FindBy (xpath = "//input[@name='SubmissionWizard-LOBWizardStepGroup-SubmissionWizard_PolicyInfoScreen-SubmissionWizard_PolicyInfoDV-DateQuoteNeeded']")
    WebElement dateQuote;
    
    @FindBy (xpath = "//*[@id=\"SubmissionWizard-Next\"]/div/div[2]")
    WebElement btnPolicyInfoNext;
    
    @FindBy(name ="SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-HOPDwellingScreen-HOPDwellingPanelSet-HOPDwellingCV-HOPDwellingDetailsDV-HOPDwellingProtectionInputSet-ProtectionClass")
    WebElement drpFireProtectClass;
    
    
    @FindBy(name="SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-HOPDwellingScreen-HOPDwellingPanelSet-HOPDwellingCV-HOPDwellingDetailsDV-HOPDwellingProtectionInputSet-FireAlarm")
     WebElement drpFireAlarm;
       
    
    @FindBy(xpath = "//*[@id=\"SubmissionWizard-Next\"]/div/div[2]")
    WebElement btnDwellingNext;
        
    
    @FindBy(name = "SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-HOPDwellingConstructionScreen-HOPDwellingConstructionPanelSet-HOPDwellingConstructionDetailsDV-YearBuilt")
    WebElement txt_yearBuilt;
    
    
    @FindBy(xpath = "//*[@id=\"SubmissionWizard-Next\"]/div/div[2]" )
    WebElement btnDwellingConstruction; 
  
    
    
    
    public void clickAccounts() {
    	dropdownAccount.click();
    }
    
    public void searchwithAccountNumber (String AccountSearch) {
    	searchAccount.sendKeys(AccountSearch);
    }
    
    
    public void searchIcon() {
 		 
    	  searchIcon.click();
	 }
	 
     public void btnNewSubmission() {
    	 btnNewSubmission.click();
     }
     
     public void btnHomeOwner() {
    	 btnHomeOwner.click();
     }
     
     public void policyType(String qualificationPagePolicyType) throws InterruptedException {
    	 selectPolicyType.click();
    	 
    	// Wait until the dropdown element is visible and clickable
    	WaitUtils.selectByText(driver, selectPolicyType, qualificationPagePolicyType); 
    	 
     }
     
     public void coverageForm(String qualificationpageCoverageForm) {
     selectCoverageForm.click();
     
     WaitUtils.selectByText(driver, selectCoverageForm, qualificationpageCoverageForm);
     
     
     
     }
		 
     public void selectdwelling(String selectDwelling) throws InterruptedException {
    	 drpselectdwelling.click();
			 
    	 WaitUtils.selectByText(driver, drpselectdwelling, selectDwelling);
    	 
    	 
     }
     
     public void rdodwelling() {
    	 rdodwelling.click();
     }
     
     public void qualificationNext() {
     btnQulificationNext.click();}
     
     public void policyInfoDateQuote(String policyInfoDateQuote) {
    	 dateQuote.sendKeys(policyInfoDateQuote);
    	 
     }
     
     public void policyNext() {
    	 btnPolicyInfoNext.click();
     }
     
     public void dwellingFireProtect(String dwellingFireProtect) throws InterruptedException {
    	drpFireProtectClass.click();
    	WaitUtils.selectByText(driver, drpFireProtectClass, dwellingFireProtect);
     }
     
     public void dwellingFireAlarm(String dwellingFireAlarm) throws InterruptedException {
    	 drpFireAlarm.click();
    	 
    	 WaitUtils.selectByText(driver, drpFireAlarm, dwellingFireAlarm);
     }
     
     public void dwellingNext() {
    	 btnDwellingNext.click();
     }
     
     public void dwellingConstructionPageYearBuild(String dwellingConstructionyear) 
     {
    	 
     txt_yearBuilt.sendKeys(dwellingConstructionyear);
     }
     
     public void dwellingConstruction() {
         btnDwellingConstruction.click();
     }
    
    
}
