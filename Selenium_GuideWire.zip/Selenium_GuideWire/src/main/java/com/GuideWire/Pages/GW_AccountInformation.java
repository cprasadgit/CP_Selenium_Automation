
  package com.GuideWire.Pages;
  
  import org.openqa.selenium.WebDriver; import
  org.openqa.selenium.WebElement; import org.openqa.selenium.support.FindBy;
  import org.openqa.selenium.support.PageFactory;
  
  public class GW_AccountInformation {
  
  WebDriver driver;
  
  public GW_AccountInformation(WebDriver driver) { this.driver = driver;
  PageFactory.initElements(driver, this); }
  
  // locators
  
  
   @FindBy(css = "div[id='gw-west-panel--top-section'] div[data-gw-click='toggleSubMenu'][role='button']")
   WebElement actionsBtn;
	
	
   @FindBy(xpath = "(//div[text()='New Account'])[2]")
   WebElement createAccount;
  
  
  @FindBy(name ="NewAccount-NewAccountScreen-NewAccountSearchDV-GlobalContactNameInputSet-Name")
  WebElement txt_companyname;
  
  
  @FindBy(name ="NewAccount-NewAccountScreen-NewAccountSearchDV-GlobalPersonNameInputSet-FirstName")
  WebElement txt_firstname;
  
  @FindBy(name = "NewAccount-NewAccountScreen-NewAccountSearchDV-GlobalPersonNameInputSet-LastName")
  WebElement txt_lastname;
  
  
  @FindBy(id = "NewAccount-NewAccountScreen-NewAccountSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Search")
  WebElement btnSearch;
  
  @FindBy(id = "NewAccount-NewAccountScreen-NewAccountButton")
  WebElement btnCreateNewAccount;
  
  
  @FindBy(id = "NewAccount-NewAccountScreen-NewAccountButton-NewAccount_Person")
  WebElement btnPerson;
  
  public void actionButton() {

		actionsBtn.click();
	}
	public void createAccount() {
		createAccount.click();
		
	}

  public void setCompanyName(String comapanyName) {
	  txt_companyname.sendKeys(comapanyName);
	}

  public void setFirstName(String firstName) {
	  
	  txt_firstname.sendKeys(firstName);
	}
  
  public void setLastName(String lastName) {
	  txt_lastname.sendKeys(lastName);
	}
  public void clickSearch() {
	  btnSearch.click();
	  }
  public void clickCreateNewAcc() {
	  btnCreateNewAccount.click();
	  }
  public void clickCreateAccPerson() {
	  btnPerson.click();
  }
  
  }
 