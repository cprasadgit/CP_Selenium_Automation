package com.GuideWire.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GW_LogOut {
	
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"gw-TabBarWidget--settings\"]/div[1]")
	
	WebElement logoutIcon;
	
	@FindBy(xpath = "	//*[@id=\"TabBar-LogoutTabBarLink\"]/div/div[2]")
	WebElement logoutSuperUser;	
  
	// Constructor 
	
	public GW_LogOut(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickLogoutIcon(){
    	logoutIcon.click();
    }
    
    public void clicklogoutSuperUser() {
    	logoutSuperUser.click();
    }
}
