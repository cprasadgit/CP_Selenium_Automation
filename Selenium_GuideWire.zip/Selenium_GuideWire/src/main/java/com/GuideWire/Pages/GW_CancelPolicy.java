package com.GuideWire.Pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;


public class GW_CancelPolicy {
	
WebDriver driver;
WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    
	// Locate the Web elements 

	@FindBy(xpath = "//*[@id=\"PolicyFile_Summary-PolicyOverviewDashboard-PolicyDetailsDetailViewTile-0\"]/div[1]/div")
	WebElement btnNewTransaction;
	
	@FindBy(xpath = "//*[@id=\"PolicyFile_Summary-PolicyOverviewDashboard-PolicyDetailsDetailViewTile-CancelPolicy\"]/div/div[2]")
	WebElement drpvalueCancelPolicy;
	
	@FindBy(name="StartCancellation-StartCancellationScreen-CancelPolicyDV-Source")
    WebElement	drpSource;  //Insured 
	
	
	@FindBy(name="StartCancellation-StartCancellationScreen-CancelPolicyDV-Reason")
	WebElement drpReason;   // value Out of business/sold
	
	@FindBy(xpath = "//*[@id=\"StartCancellation-StartCancellationScreen-NewCancellation\"]/div/div[2]")
	WebElement btnStartCancellation;
	
	
	@FindBy(xpath = "//*[@id=\"CancellationWizard-CancellationWizard_QuoteScreen-JobWizardToolbarButtonSet-BindOptions\"]/div[1]")
	WebElement btnBindOption; 
	
	
	@FindBy(xpath ="//*[@id=\"CancellationWizard-CancellationWizard_QuoteScreen-JobWizardToolbarButtonSet-BindOptions-CancelNow\"]/div")
	WebElement drpValueCancelNow;
	
	
	@FindBy(xpath = "//*[@id=\"JobComplete-JobCompleteScreen-JobCompleteDV-ViewPolicy\"]/div/div/div[2]")
	WebElement linkViewyourPolicy;
	
	@FindBy(xpath = "//*[@id=\"PolicyFile_Summary-ttlBar\"]/div[1]/div")
	WebElement lblPolicySummary;
	
	// Constructor
	public GW_CancelPolicy(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//Actions 

	public void policySummaryNewTransaction() {
		btnNewTransaction.click();
		 }
	
	
	public void policySummarypageCancelPolicy() {
		drpvalueCancelPolicy.click();
		 }
		
	
	 public void startCancelForPolicyPageSource() throws InterruptedException {
		 drpSource.click();
			
		 WaitUtils.selectByText(driver, drpSource, "Insured");
	  }
	 
		 public void startCancelForPolicyPagerReason() {
		 drpReason.click();

		   WaitUtils.selectByText(driver, drpReason, "Out of business/sold");
		}
	 
	 public void startCancellationForPolicyStartCancellationbutton() {
		WaitUtils.clickElement(driver, btnStartCancellation);
	 }
	 
	 public void confirmationPageBindOptions() {
	 btnBindOption.click();
	 }
	 
	 public void confirmationCancelNow() {
		 drpValueCancelNow.click();		 
	 }
	 
	 public void cancelledPolicySummaryView()
	 {
		 linkViewyourPolicy.click();
	 }
	 public void palicySummarylabel()
	 {
		 lblPolicySummary.getText();
	 }
	 
}
