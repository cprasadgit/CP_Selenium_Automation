package com.GuideWire.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GW_Login {

	WebDriver driver;
    
	// Locate the Web elements 

	@FindBy(name = "Login-LoginScreen-LoginDV-username")
	WebElement txt_username;

	@FindBy(name = "Login-LoginScreen-LoginDV-password")
	WebElement txt_password;

	@FindBy(xpath = "//div[@role='button' and .//div[text()='Log In']]")
	WebElement loginBtn;
	
	

	//Initialize the elements in the constructor
		public GW_Login(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}

		public void login(String user, String pwd) {
			txt_username.sendKeys(user);
			txt_password.sendKeys(pwd);
			loginBtn.click();
	    }
        
		
}
