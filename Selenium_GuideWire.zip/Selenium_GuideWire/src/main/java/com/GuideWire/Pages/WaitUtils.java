package com.GuideWire.Pages;
	
	import org.openqa.selenium.*;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import java.time.Duration;

	public class WaitUtils {

	    private static final Duration TIMEOUT = Duration.ofSeconds(20);
	    private static final By GW_OVERLAY = By.id("gw-click-overlay");

	    // Helper to wait for Guidewire's loading spinner/overlay to vanish
	    public static void waitForGuiLoading(WebDriver driver) {
	        new WebDriverWait(driver, TIMEOUT)
	            .until(ExpectedConditions.invisibilityOfElementLocated(GW_OVERLAY));
	    }

	    // Handles Stale Elements and Intercepted Clicks in one go
	    public static void clickElement(WebDriver driver, WebElement element) {
	        WebDriverWait wait = new WebDriverWait(driver, TIMEOUT);
	        
	        waitForGuiLoading(driver);
	        
	        wait.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(element)));
	        
	        try {
	            element.click();
	        } catch (ElementClickInterceptedException e) {
	            // Final fallback: If still intercepted, wait 1 sec and try one last time
	            waitForGuiLoading(driver);
	            element.click();
	        }
	    }

	    // Safe wrapper for Dropdowns (Select)
	    public static void selectByText(WebDriver driver, WebElement element, String text) {
	        clickElement(driver, element); // Ensure it's clickable/visible first
	        org.openqa.selenium.support.ui.Select select = new org.openqa.selenium.support.ui.Select(element);
	        select.selectByVisibleText(text);
	        waitForGuiLoading(driver); // Guidewire often refreshes after a selection
	    }
	}


