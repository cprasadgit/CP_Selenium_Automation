package com.GuideWire.Pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GW_Coverages {
	
	WebDriver driver;
	  
	public GW_Coverages(WebDriver driver) { this.driver = driver;
	  PageFactory.initElements(driver, this); }
	 
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	 
	 
	 @FindBy(name = "SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-HOPCoveragesScreen-HOPMainCoveragesPanelSet-dwellingCoveragePatternIterator-0-CoverageInputSet-CovPatternInputGroup-HOPCovACoinsurance")
	 WebElement drpCoinsurance;
	 
	 @FindBy(name = "SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-HOPCoveragesScreen-HOPMainCoveragesPanelSet-dwellingCoveragePatternIterator-2-CoverageInputSet-CovPatternInputGroup-HOPCovCValuationMethod")
	 WebElement drpValuationMethod;
	 
	 @FindBy(id="SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-HOPCoveragesScreen-HOPMainCoveragesPanelSet-dwellingCoveragePatternIterator-3-CoverageInputSet-CovPatternInputGroup-HOPCovDLossOfRent_0")
	 WebElement rdolossofRentalIncome;
	 
	 @FindBy (name = "SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-HOPCoveragesScreen-HOPMainCoveragesPanelSet-dwellingCoveragePatternIterator-3-CoverageInputSet-CovPatternInputGroup-HOPCovDProhibitedUse")
	 WebElement drpProhibitedUseCivilAuthority;
	 
	 @FindBy(xpath = "//*[@id=\"SubmissionWizard-Next\"]/div/div[2]")
	 WebElement btnCoverageNext;
    
	 @FindBy(xpath = "//*[@id=\"SubmissionWizard-Next\"]/div/div[2]")
	 WebElement btnModifierNext;
	 
	 @FindBy(xpath ="//*[@id=\"SubmissionWizard-Job_RiskAnalysisScreen-JobWizardToolbarButtonSet-QuoteTypeToolbarButtonSet-Quote\"]/div/div[2]")
	 WebElement btnQuote;
	 
	 @FindBy(xpath= "//*[@id=\"SubmissionWizard-SubmissionWizard_QuoteScreen-JobWizardToolbarButtonSet-BindOptions\"]/div[1]")
	 WebElement btnBindOption;
	 
	 @FindBy(xpath = "//*[@id=\"SubmissionWizard-SubmissionWizard_QuoteScreen-JobWizardToolbarButtonSet-BindOptions-BindAndIssue\"]/div/div[2]")
	 WebElement valIssuePolicy;
	 
	 
	 @FindBy(id="SubmissionWizard-LOBWizardStepGroup-LineWizardStepSet-HOPModifiersScreen-HOPModifiersPanelSet-LineModifiers-HOPModifiersInputSet-0-BooleanModifier_0")
	 WebElement modifierMultiPolicy; 
	 
	 //@FindBy(xpath = "//*[@id=\\\"PolicyFile_Summary-ttlBar\\\"]/div[1]/div")
	@FindBy(xpath= "//*[@id=\"PolicyFile_Summary-PolicyOverviewDashboard-PolicyDetailsDetailViewTile-PolicyDetailsDetailViewTile_DV-PolicyNumber\"]/div/div")
	 WebElement lblPolicyNumber;
	 
	@FindBy(xpath = "//*[@id=\"JobComplete-JobCompleteScreen-JobCompleteDV-ViewPolicy\"]/div/div/div[2]")
	 WebElement linkViewYourPolicy;
	 
      public void coveragesPageCoinsurance(String coveragesPageCoinsurance) throws InterruptedException {
    	  drpCoinsurance.click();
    	  	  WaitUtils.selectByText(driver, drpCoinsurance, coveragesPageCoinsurance);
      }
      
      public void coveragesPageValuationMethod(String coveragesPageValuationMethod) throws InterruptedException {
    	  drpValuationMethod.click();
    	  WaitUtils.selectByText(driver, drpValuationMethod, coveragesPageValuationMethod);
      }
      
      public void LossOfRentalIncom() throws InterruptedException {
    	  Thread.sleep(1000);
    	  rdolossofRentalIncome.click();
      }
      
      public void coveragePageProhibitedUseCivilAuth(String coveragePageProhibitedUseCivilAuth) throws InterruptedException {
    	  drpProhibitedUseCivilAuthority.click();
    	  
    	  WaitUtils.selectByText(driver, drpProhibitedUseCivilAuthority, coveragePageProhibitedUseCivilAuth);
      }
      
      public void CoverageNext() {
      
      btnCoverageNext.click();
      }
      
      public void ModifierNext()
      {
      btnModifierNext.click();
      }

      public void Quote()
      {
    	  btnQuote.click();
      }
      public void BindOption()
      {
    	  btnBindOption.click();
      }

      public void IssuePolicy()
      {
    	  valIssuePolicy.click();
      }
      
      public void MultiPolicy()
      {
    	  modifierMultiPolicy.click();
      }

      public void ViewyourPolicy() {
    	  linkViewYourPolicy.click();
      }
      
	  public void labelPolicyNumber() {
		
		  String lblPolicySummay = lblPolicyNumber.getText();
		  System.out.println("Policy Number :" +lblPolicySummay);
	  }

      
      
      
}
