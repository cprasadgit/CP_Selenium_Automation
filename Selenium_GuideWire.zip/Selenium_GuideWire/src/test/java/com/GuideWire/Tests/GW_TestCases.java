package com.GuideWire.Tests;

import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.GuideWire.Pages.ConfigReader;
import com.GuideWire.Pages.GW_AccountInformation;
import com.GuideWire.Pages.GW_CancelPolicy;
import com.GuideWire.Pages.GW_Coverages;
import com.GuideWire.Pages.GW_CreateAccountInformation;
import com.GuideWire.Pages.GW_LogOut;
import com.GuideWire.Pages.GW_Login;
import com.GuideWire.Pages.GW_NewSubmission;
import org.apache.logging.log4j.LogManager;

import org.apache.logging.log4j.Logger;
 
 
 public class GW_TestCases {

	WebDriver driver;

	@BeforeTest

	public void Launch() {

		driver = new ChromeDriver();

		driver.manage().window().maximize();
		// Accessing the URL from the properties file
		String appUrl = ConfigReader.getProperty("url");
		driver.get(appUrl);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		String user = ConfigReader.getProperty("username");
		String password = ConfigReader.getProperty("password");
		GW_Login guidewireloginpage = new GW_Login(driver);
		// Execute the action
		guidewireloginpage.login(user, password);


	}

	@Test(enabled = true, priority = 1, description = "TC01_Verify whether the user is able to create a new person account.")

	public void guidewireNewAccount() throws InterruptedException {
		
		// Get data from Config.Properties file
		String firstName = ConfigReader.generateRandomFirstName();
		String lastName = ConfigReader.generateRandomLastName();
		String address1 = ConfigReader.getProperty("address1");
		String city = ConfigReader.getProperty("city");
		String CreateAccountZipCode = ConfigReader.getProperty("zipCode");
		String State = ConfigReader.getProperty("CreateAccountState");
		String CreateAccountAddressType = ConfigReader.getProperty("CreateAccountAddressType");
        String OrganizationName = ConfigReader.getProperty("OrganizationName");

		try {
			
			GW_AccountInformation GWA = new GW_AccountInformation(driver);
			GWA.actionButton();
			GWA.createAccount();

			GWA.setFirstName(firstName);
			GWA.setLastName(lastName);
			GWA.clickSearch();
			GWA.clickCreateNewAcc();
			GWA.clickCreateAccPerson();

			GW_CreateAccountInformation GWC = new GW_CreateAccountInformation(driver);
			GWC.setAddress(address1);
			GWC.setCity(city);
			GWC.selectState(State);
			GWC.setPostal(CreateAccountZipCode);
			GWC.selectAddressType(CreateAccountAddressType);
			GWC.OrganizationSearchIcon();
            GWC.Organization(OrganizationName);
			GWC.OrganizationSearch();
			GWC.SelectOrganization();
			GWC.CheckDuplicate();
			GWC.AccountUpdate();
			
			
			GWC.clickAccountSummary();
			 		
			//GWNewSubmission();
			
		} catch (Exception e) {
			System.err.println(e);
		}
	}

	@Test(enabled = true, priority = 2,description = "TC02_Verify whether User able to Quote and Issue the  Homeowners  with term type as Annual/12 months")

	public void GWNewSubmission() throws InterruptedException {
		
		try
		{

		GW_NewSubmission GNS = new GW_NewSubmission(driver);
		//GNS.clickAccounts();
		//String AccountNumberSearch = ConfigReader.getProperty("searchAccountNumber");
		//GNS.searchwithAccountNumber(AccountNumberSearch);
		//GNS.searchIcon();
		GNS.btnNewSubmission();
		GNS.btnHomeOwner();
		
		String qualificationpagePolicyType = ConfigReader.getProperty("qualificationPagePolicyType");
		String qualificationpageCoverageForm = ConfigReader.getProperty("qualificationPageCoverageForm");
		String qualificationpageSelectDewelling = ConfigReader.getProperty("selectDwelling");		
		String policyInfoDateQuote = ConfigReader.getProperty("policyInfoDateQuote");
		String dwellingFireAlarm = ConfigReader.getProperty("dwellingFireAlarm");
		String dwellingFireProtect = ConfigReader.getProperty("dwellingFireProtect");
		String dwellingConstructionPageYearBuild = ConfigReader.getProperty("dwellingConstructionPageYearBuild");
		String coveragesPageCoinsurance = ConfigReader.getProperty("coveragesPageCoinsurance");
		String coveragesPageValuationMethod   =   ConfigReader.getProperty("coveragesPageValuationMethod");
		String coveragePageProhibitedUseCivilAuth  =   ConfigReader.getProperty("coveragePageProhibitedUseCivilAuth");
						
		
		
		//dwellingFireAlarm
        
		GNS.policyType(qualificationpagePolicyType);
        GNS.coverageForm(qualificationpageCoverageForm);
        GNS.selectdwelling(qualificationpageSelectDewelling);

		GNS.rdodwelling();
		GNS.qualificationNext();
		GNS.policyInfoDateQuote(policyInfoDateQuote);
		GNS.policyNext();
		
		GNS.dwellingFireProtect(dwellingFireProtect);
		
		GNS.dwellingFireAlarm(dwellingFireAlarm);
		GNS.dwellingNext();
		GNS.dwellingConstructionPageYearBuild(dwellingConstructionPageYearBuild);
		GNS.dwellingConstruction();

		GW_Coverages GWC = new GW_Coverages(driver);

		GWC.coveragesPageCoinsurance(coveragesPageCoinsurance);
		GWC.coveragesPageValuationMethod(coveragesPageValuationMethod);
		GWC.LossOfRentalIncom();
		GWC.coveragePageProhibitedUseCivilAuth(coveragePageProhibitedUseCivilAuth);
		GWC.CoverageNext();
		GWC.MultiPolicy();
		GWC.ModifierNext();
		
		
		GWC.Quote();
		GWC.BindOption();
		GWC.IssuePolicy();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		GWC.ViewyourPolicy();
		GWC.labelPolicyNumber();
		}
		catch (Exception e) {
			System.err.println(e);
		}
		
	}
	
	@Test(enabled = true, priority = 3,description = "TC03_Verify whether the user able to Cancel a homeowners policy using flat cancellation method.")
	public void guidewirePolicyCancel() throws InterruptedException {
		{
			try {
					 			
			GW_CancelPolicy GWCP = new GW_CancelPolicy(driver);
			
			GWCP.policySummaryNewTransaction();
			
			GWCP.policySummarypageCancelPolicy();
			
			GWCP.startCancelForPolicyPageSource();
						
			GWCP.startCancelForPolicyPagerReason();
			
			GWCP.startCancellationForPolicyStartCancellationbutton();
			
			GWCP.confirmationPageBindOptions();
			
			GWCP.confirmationCancelNow();
			
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			wait.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
			GWCP.cancelledPolicySummaryView();  
			GWCP.palicySummarylabel();
			
			}
			catch (Exception e) {
				System.err.println(e);
			}
		}
	}

	@AfterTest
	void Browserquit() {
		GW_LogOut GWL = new GW_LogOut(driver);
		
		GWL.clickLogoutIcon();
        GWL.clicklogoutSuperUser();
	    driver.quit();
        
	}
}
