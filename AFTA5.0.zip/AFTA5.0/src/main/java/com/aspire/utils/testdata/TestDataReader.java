package com.aspire.utils.testdata;

import java.io.IOException;
import java.util.Map;

import com.aspire.utils.IPropertiesReader;
import com.aspire.utils.PropertiesReaderUtil;

public class TestDataReader {
	private static IPropertiesReader propertiesReader = PropertiesReaderUtil.getInstance();

	static String testDataSource = propertiesReader.testDataSource();

	private static IDataReader getDataReaderInstance() {
		IDataReader dataReader = null;
		try {
			if (testDataSource.equals("excel"))
				dataReader = WorkBookUtils.getWorkBook("testdata/" + propertiesReader.excelName());
			else if (testDataSource.equals("googleSheet"))
				dataReader = GoogleSheetUtils.createSheetsService(propertiesReader.googleCredentialJson(),
						propertiesReader.googleSheetID());
			else if (testDataSource.equals("postgresql"))
				dataReader = SQLUtils.getInstance(propertiesReader.dbHost(), propertiesReader.dbPort(),
						propertiesReader.dbName(), propertiesReader.dbUsername(), propertiesReader.dbPassword());
		} catch (IOException e) {
			e.printStackTrace();
		}

		return dataReader;
	}

	public static Map<String, String> readData(String sheetTableName, String tcID) {
		return getDataReaderInstance().getRowValuesByTcId(sheetTableName, tcID);
	}

}
