package com.aspire.utils.nft;

import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.map.LinkedMap;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;




//import com.Generic.utils.ExcelWrite;
public class MetricsCalculation {
	
	private static final String DOMAIN_LOOKUP_END =  "domainLookupEnd"; 
	private static final String CONNECT_END = "connectEnd";
	private static final String CONNECT_START = "connectStart";
	private static final String DOMAIN_LOOKUP_START = "domainLookupStart";
	private static final String REDIRECT_START = "redirectStart";
	private static final String FETCH_START = "fetchStart";
	private static final String REQUEST_START = "requestStart";
	private static final String REDIRECT_END = "redirectEnd";
	private static final String RESPONSE_START = "responseStart";
	private static final String RESPONSE_END = "responseEnd";
	private static final String START_TIME = "startTime";
	private static final String LOAD_EVENT_END = "loadEventEnd";
	private static final String DOM_INTERACTIVE = "domInteractive";
	private static final String ENTRY_TYPE = "entryType";
	private static final String EMPTY_EMPTY = "empty:empty";
	private static final String LABEL ="label";
	private static final String TIMESTAMP = "timestamp";
	private static final String BROWSER = "browser";
	private static final String THREAD = "_Thread";
	private static final String NUMBER_REGX = "^-?(\\d+\\.?\\d*)$|(\\d*\\.?\\d+)$";
	private static final String RUN_ID = "RunID";
	private static final String HOST_NAME = "hostName";
	private static final String NAVIGATION_TIMING = "Navigation Timing";
	private static final String INFLUXDB_PASSWORD = "qEEzTHTv3WOc2VPCh7yS";
	private static final String INFLUXDB_USERNAME = "influxdb";
	private static final String INFLUX_SUCCESS_MSG = "Successfully connected to influxDB database test";
	private static final String SAMPLE = "sample";
	private static final String ERROR_DETAILS = "Error details : ";
	private static final String INFLUXDB_CONNECTION_MSG = "There is no influx DB is connection established earlier to close";
	private static final String PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH = "return(JSON.stringify(window.performance.getEntriesByType(\"resource\").length))";
	private static final String PERFORMANCE_ENTRIES_BY_RESOURCE = "return(performance.getEntriesByType(\"resource\")[";
	private static final String ENTRIES_NAME = "].name)";
	private static final String PERFORMANCE_ENTRIES_BY_RESOURCE_JSON = "return(JSON.stringify(window.performance.getEntriesByType(\"resource\")[";
	private static final String INITIATOR_TYPE = "].initiatorType))";
	private static final String INITIATOR_TYPE01 = ",initiatorType";
	private static final String PERFORMANCE_ENTRIES_BY_RESOURCE_JSON01 = "return(JSON.stringify(performance.getEntriesByType(\"resource\")[";
	private static final String SECURE_CONNECTION_START = "secureConnectionStart";
	private static final String TIME_TO_FIRST_BYTE = "TimetoFirstByte";
	private static final String REQUEST_END = "requestEnd";
	
	
	static Date date = new Date();
	static SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:sss");
	static Capabilities cap = null;
	static String apiSwitch = "true";
	static boolean detailedRawData = false;
	static boolean StopExecutionDrivers = false;
	static String performanceMetricField[] = { CONNECT_END, CONNECT_START, DOMAIN_LOOKUP_END, DOMAIN_LOOKUP_START,
			"duration", FETCH_START, REDIRECT_END, REDIRECT_START, REQUEST_START, RESPONSE_END, RESPONSE_START,
			START_TIME };
	static String navigationMetricField[] = { CONNECT_END, CONNECT_START, DOMAIN_LOOKUP_END, DOMAIN_LOOKUP_START,
			"duration", FETCH_START, "initiatorType", "name", REDIRECT_END, REDIRECT_START, REQUEST_START,
			RESPONSE_END, RESPONSE_START, START_TIME, "domComplete", "domContentLoadedEventEnd",
			"domContentLoadedEventStart", DOM_INTERACTIVE, "domLoading", LOAD_EVENT_END, "loadEventStart",
			"navigationStart", "redirectCount", "unloadEventEnd", "unloadEventStart" };
	static String stringMetricField[] = { "name", ENTRY_TYPE };

	// *********************************************************************************
	// Method used to get navigation related performance metrics and push to influx
	// DB
	// *********************************************************************************
	public static void navigationPerformance(String dbName, WebDriver driver, String browserInit,String workBookName, String labelName,
			String buildNumber, String dbUrl, String OutputFileLocation, String influxDBCon) throws Exception {
		try {
	
		cap = ((RemoteWebDriver) driver).getCapabilities();
		System.out.println("Current window url is: "+driver.getCurrentUrl());
		Map<String, Object> ssObj = new HashMap<String, Object>();
		Map<String, String> ssObj1 = new HashMap<String, String>();
		// Map<String, Object> ssObj4 = new LinkedMap<String, Object>();
		Map<String, Object> ssObj2 = new LinkedMap<String, Object>();
		Map<String, Object> ssObjCalcMetrics = new HashMap<String, Object>();
		String navigationEntries = EMPTY_EMPTY;
		String FirstPaint = "";
		String FirstContentfulPaint = "";
		//if (cap.getBrowserName().equalsIgnoreCase("internet explorer")) {
		if (browserInit.equalsIgnoreCase("ie")) {
			for (String entries : navigationMetricField) {
				navigationEntries = navigationEntries + "," + entries + ":"
						+ (String) ((JavascriptExecutor) driver)
								.executeScript("return(JSON.stringify(performance.getEntriesByType(\"navigation\")[0]."
										+ entries + "))");
				System.out.println(entries);
			}
			for (String entries : stringMetricField) {
				navigationEntries = navigationEntries + "," + entries + ":"
						+ (String) ((JavascriptExecutor) driver)
								.executeScript("return(JSON.stringify(performance.getEntriesByType(\"navigation\")[0]."
										+ entries + "))");
			}
		} else {
			navigationEntries = (String) ((JavascriptExecutor) driver)
					.executeScript("return(JSON.stringify(performance.getEntriesByType(\"navigation\")[0]))");
		}
		try
		{
		if (browserInit.equalsIgnoreCase("chrome") || browserInit.equalsIgnoreCase("edge")) {
			FirstPaint = (String) ((JavascriptExecutor) driver).executeScript(
					"return(JSON.stringify(window.performance.getEntriesByType(\"paint\")[0].startTime+window.performance.getEntriesByType(\"paint\")[0].duration))");
			FirstContentfulPaint = (String) ((JavascriptExecutor) driver).executeScript(
					"return(JSON.stringify(window.performance.getEntriesByType(\"paint\")[1].startTime+window.performance.getEntriesByType(\"paint\")[1].duration))");
		}
		}
		catch(Exception e)
		{
			if(FirstPaint.isEmpty())
			{
				FirstPaint="";
			}
			if(FirstContentfulPaint.isEmpty())
			{
				FirstContentfulPaint="";
			}
		}
		System.out.println("FirstPaint:" + FirstPaint);
		System.out.println("FirstContentfulPaint :" + FirstContentfulPaint);
		System.out.println("navigationEntries:" + navigationEntries);
		String[] navigationEntryArray = navigationEntries.split(",");
		ssObj2.put(LABEL, labelName);
		long threadId = Thread.currentThread().getId();
		ssObj2.put(TIMESTAMP, InetAddress.getLocalHost() + THREAD + threadId + "_" + formatter.format(new Date())); // For
																															// Excel
		// ssObj2.put(BROWSER, cap.getBrowserName());
		ssObj2.put(BROWSER, browserInit.substring(0, 1).toUpperCase() + browserInit.substring(1));
		String browserName = browserInit.substring(0, 1).toUpperCase() + browserInit.substring(1); // change
																														// 1st
																														// letter
																														// to
																														// capital
		ssObj1.put(BROWSER, browserName); // browsername to push to db as tag
		for (String value : navigationEntryArray)
			System.out.println(value);
		for (String value : navigationEntryArray) {
			String[] val = null;
			if (value.contains("://")) {
				val = value.split(":");
				val[0] = val[0].replace('{', ' ').trim();
				val[1] = val[1] + ":" + val[2];
				val[0] = val[0].replace('"', ' ').trim();
				val[1] = val[1].replace('"', ' ').trim();
				ssObj1.put(val[0], val[1]);
				ssObj2.put(val[0], val[1]);

			} else {
				val = value.split(":");
				val[0] = val[0].replace('{', ' ').trim();
				val[1] = val[1].replace('}', ' ').trim();
				val[0] = val[0].replace('"', ' ').trim();
				val[1] = val[1].replace('"', ' ').trim();
				if (val[1].matches(NUMBER_REGX))

				{
					float value1 = Float.parseFloat(val[1]);
					ssObj.put(val[0], value1);
					ssObj2.put(val[0], value1);
				} else {
					// ssObj.put(val[0], val[1]); //old commented to introduce as tag
					ssObj1.put(val[0], val[1]);
					ssObj2.put(val[0], val[1]);
				}
			}

		}
		if (browserInit.equalsIgnoreCase("chrome") || browserInit.equalsIgnoreCase("edge")) {
			if(!FirstPaint.isEmpty())
			{
			ssObj.put("FirstPaint", Float.parseFloat(FirstPaint));
			}
			if(!FirstContentfulPaint.isEmpty())
			{
			ssObj.put("FirstContentfulPaint", Float.parseFloat(FirstContentfulPaint));
			}
		}
		
		ssObj1.replace("name", driver.getCurrentUrl());
		ssObj2.replace("name", driver.getCurrentUrl());
		System.out.println(ssObj);
		// ssObj.put(LABEL, labelName);
		ssObj1.put(LABEL, labelName); // to put as tag
		ssObj1.put(RUN_ID, buildNumber); // runid

		// change 1st letter to capital - for entryType
		String entryType = ssObj1.get(ENTRY_TYPE);
		String entryTypeRevised = entryType.substring(0, 1).toUpperCase() + entryType.substring(1); // change 1st letter
																									// to capital
		ssObj1.replace(ENTRY_TYPE, entryTypeRevised);
		String[] hostName = InetAddress.getLocalHost().toString().split("/");
		ssObj1.put(HOST_NAME, hostName[0]);
		ssObjCalcMetrics = MetricsArithmeticCalculationNavigation(ssObj);

		ssObj2.putAll(ssObjCalcMetrics);
		ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj2, workBookName, OutputFileLocation);
		// for (Map.Entry<String,Object> entry : ssObj.entrySet()) {
		// ssObj4.put(entry.getKey(), entry.getValue());
		// }
		// for (Entry<String, String> entry : ssObj1.entrySet()) {
		// ssObj4.put(entry.getKey(), entry.getValue());
		// }
		// long threadId1 = Thread.currentThread().getId();
		// ssObj4.put(TIMESTAMP, InetAddress.getLocalHost() + THREAD + threadId1 +
		// "_" + formatter.format(new Date()));
		// ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj4, workBookName);

		if(influxDBCon.equalsIgnoreCase("true")) {
		InfluxDB influxDB = InfluxDBFactory.connect(dbUrl, INFLUXDB_USERNAME, INFLUXDB_PASSWORD);
		if (influxDB != null) {
			System.out.println(INFLUX_SUCCESS_MSG);
		}
		Point point1 = null;

		point1 = Point.measurement(SAMPLE).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS).tag(ssObj1)
				.fields(ssObj).build();
		System.out.println(point1);

		BatchPoints batchPoints = BatchPoints.database(dbName).build();
		batchPoints.point(point1);
		influxDB.write(batchPoints);
		influxDB.close();
		} else 
			System.out.println(INFLUXDB_CONNECTION_MSG);
		} catch(Exception e) {
			System.out.println(ERROR_DETAILS +e.getMessage());
		}
	}

	// *********************************************************************************
	// Method used to get action/resource related performance metrics and push to
	// influx DB
	// *********************************************************************************
	public static void actionPerformance(String dbName, WebDriver driver,String browserInit, List<String> urlList, String labelName,
			String workBookName, String buildNumber, String dbUrl, String OutputFileLocation, String influxDBCon) throws Exception {
		String name = null;
		cap = ((RemoteWebDriver) driver).getCapabilities();
		Map<String, Object> ssObj7 = new LinkedMap<String, Object>();
		Map<String, Object> ssObj = new HashMap<String, Object>();
		Map<String, String> ssObj1 = new HashMap<String, String>();
		Map<String, Object> ssObj3 = new HashMap<String, Object>();
		Map<String, Object> ssObj4 = new HashMap<String, Object>();
		Map<String, Object> ssObj5 = new HashMap<String, Object>();
		Map<String, Object> ssObjCalcMetrics = new HashMap<String, Object>();
		Map<String, Object> ssObj6 = new LinkedMap<String, Object>(); // For excel with combined value
		Map<String, Object> ssObjCalcMetrics1 = new HashMap<String, Object>();
		String timeStamp = formatter.format(new Date());
		for (String url : urlList) {
			int length = Integer.parseInt((String) ((JavascriptExecutor) driver)
					.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH));
			for (int i = 0; i <= length - 1; i++) {
				name = (String) ((JavascriptExecutor) driver)
						.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE + (i) + ENTRIES_NAME);
				if (name.equals(url)) {
					String navigationEntries = EMPTY_EMPTY;
					if (browserInit.equalsIgnoreCase("ie")) {
						for (String entries : performanceMetricField) {
							navigationEntries = navigationEntries + "," + entries + ":"
									+ (String) ((JavascriptExecutor) driver).executeScript(
											PERFORMANCE_ENTRIES_BY_RESOURCE_JSON
													+ i + "]." + entries + "))");
						}
						for (String entries : stringMetricField) {
							navigationEntries = navigationEntries + "," + entries + ":"
									+ (String) ((JavascriptExecutor) driver).executeScript(
											PERFORMANCE_ENTRIES_BY_RESOURCE_JSON
													+ i + "]." + entries + "))");
						}
						navigationEntries = navigationEntries + INITIATOR_TYPE01 + ":"
								+ (String) ((JavascriptExecutor) driver).executeScript(
										PERFORMANCE_ENTRIES_BY_RESOURCE_JSON + i
												+ INITIATOR_TYPE);
					} else {
						navigationEntries = (String) ((JavascriptExecutor) driver).executeScript(
								PERFORMANCE_ENTRIES_BY_RESOURCE_JSON01 + i + "]))");
					}
					navigationEntries = navigationEntries.replace('"', ' ').trim();
					String[] navigationEntryArray = navigationEntries.split(",");
					Map<String, Object> ssObj2 = new LinkedMap<String, Object>();
					for (String value : navigationEntryArray) {

						ssObj2.put(LABEL, labelName);
						ssObj6.put(LABEL, labelName);
						long threadId = Thread.currentThread().getId();
						ssObj2.put(TIMESTAMP, InetAddress.getLocalHost() + THREAD + threadId + "_" + timeStamp); // For
																														// Excel
						ssObj6.put(TIMESTAMP, timeStamp);
						ssObj2.put(BROWSER,
								browserInit.substring(0, 1).toUpperCase() + browserInit.substring(1));
						ssObj6.put(BROWSER, browserInit);
						String browserName = browserInit.substring(0, 1).toUpperCase()
								+ browserInit.substring(1); // change 1st letter to capital
						ssObj1.put(BROWSER, browserName); // to push to db as tag
						String[] val = null;
						if (value.contains("://")) {
							val = value.split(":");
							val[0] = val[0].replace('{', ' ').trim();
							val[1] = val[1] + ":" + val[2];//+ ":"+val[3];
							val[0] = val[0].replace('"', ' ').trim();
							val[1] = val[1].replace('"', ' ').trim();
							ssObj5.put(val[0], val[1]);
							ssObj2.put(val[0], val[1]);
							ssObj6.put(val[0], val[1]);
						} else {
							val = value.split(":");
							val[0] = val[0].replace('{', ' ').trim();
							val[1] = val[1].replace('}', ' ').trim();
							val[0] = val[0].replace('"', ' ').trim();
							val[1] = val[1].replace('"', ' ').trim();
							if (val[1].matches(NUMBER_REGX))

							{
								float value1 = Float.parseFloat(val[1]);
								ssObj2.put(val[0], value1);
								ssObj3.put(val[0], value1);
							} else {
								ssObj2.put(val[0], val[1]);
								ssObj4.put(val[0], val[1]);
							}
						}

					}

					String[] arrExcludeAddition_Start = new String[] { CONNECT_START, DOMAIN_LOOKUP_START,
							FETCH_START, REQUEST_START, RESPONSE_START, SECURE_CONNECTION_START, START_TIME,
							REDIRECT_START, TIME_TO_FIRST_BYTE };

					String[] arrExcludeAddition_End = new String[] { CONNECT_END, DOMAIN_LOOKUP_END, REQUEST_END,
							RESPONSE_END, REDIRECT_END };

					// Convert String Array to List
					List<String> listExcludeAddition_Start = Arrays.asList(arrExcludeAddition_Start);
					List<String> listExcludeAddition_End = Arrays.asList(arrExcludeAddition_End);

					ssObj3 = MetricsArithmeticCalculationAction(ssObj3);
					ssObj2 = MetricsArithmeticCalculationAction(ssObj2);

					if (!ssObj3.isEmpty()) {
						for (String key : ssObj3.keySet()) {
							if (!ssObj.containsKey(key)) {
								ssObj.put(key, ssObj3.get(key));
								ssObj6.put(key, ssObj3.get(key));
							} else {
								if (listExcludeAddition_Start.contains(key)) {
									// Replace if the new value is less than the old start value, else skip
									if (Float.parseFloat(ssObj3.get(key).toString()) < Float
											.parseFloat(ssObj.get(key).toString())) {
										ssObj.replace(key, ssObj3.get(key));
										ssObj6.replace(key, ssObj3.get(key));
									}

								} else if (listExcludeAddition_End.contains(key)) {
									// Replace if the new value is greater than the old end value, else skip
									if (Float.parseFloat(ssObj3.get(key).toString()) > Float
											.parseFloat(ssObj.get(key).toString())) {
										ssObj.replace(key, ssObj3.get(key));
										ssObj6.replace(key, ssObj3.get(key));
									}
								} else {
									float value1 = Float.parseFloat(ssObj3.get(key).toString());
									float value2 = Float.parseFloat(ssObj.get(key).toString()) + value1;
									ssObj.replace(key, value2);
									ssObj6.replace(key, value2);
								}
							}
						}
						for (String key : ssObj4.keySet()) {

							if (!ssObj1.containsKey(key)) {
								ssObj1.put(key, ssObj4.get(key).toString());
								ssObj6.put(key, ssObj4.get(key).toString());
							} else {
								ssObj1.replace(key, ssObj4.get(key).toString());
								ssObj6.replace(key, ssObj4.get(key).toString());
							}
						}
						if (!ssObj1.containsKey("name")) {
							ssObj1.put("name", ssObj5.get("name").toString());
							ssObj6.put("name", ssObj5.get("name").toString());
						} else {
							String nameUrl = ssObj1.get("name") + " " + ssObj5.get("name").toString();
							ssObj1.replace("name", nameUrl);
							ssObj6.replace("name", nameUrl);
						}
					}
					if (detailedRawData) {
						ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj2, workBookName, OutputFileLocation);
					}
				}

			}

		}

		ssObj1.put(LABEL, labelName); // To put as tag type
		ssObj1.put(RUN_ID, buildNumber); // runid

		// change 1st letter to capital - for entryType
		String entryType = ssObj1.get(ENTRY_TYPE);
		
		String entryTypeRevised = entryType.substring(0, 1).toUpperCase() + entryType.substring(1); // change 1st letter
		String[] hostName = InetAddress.getLocalHost().toString().split("/");
		ssObj1.put(HOST_NAME, hostName[0]);																							// to capital
		ssObj1.replace(ENTRY_TYPE, entryTypeRevised);
		ssObjCalcMetrics = MetricsArithmeticCalculationAction(ssObj);
		ssObjCalcMetrics1 = MetricsArithmeticCalculationAction(ssObj6);
		if (!detailedRawData) {
			for (Map.Entry<String, Object> entry : ssObj.entrySet()) {
				ssObj7.put(entry.getKey(), entry.getValue());
			}
			for (Entry<String, String> entry : ssObj1.entrySet()) {
				ssObj7.put(entry.getKey(), entry.getValue());
			}
			long threadId = Thread.currentThread().getId();
			ssObj7.put(TIMESTAMP,
					InetAddress.getLocalHost() + THREAD + threadId + "_" + formatter.format(new Date()));
			ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj7, workBookName, OutputFileLocation);
		}
        if(influxDBCon.equalsIgnoreCase("true")) {
		InfluxDB influxDB = InfluxDBFactory.connect(dbUrl, INFLUXDB_USERNAME, INFLUXDB_PASSWORD);
		if (influxDB != null) {
			System.out.println(INFLUX_SUCCESS_MSG);
		}
		Point point1 = null;

		point1 = Point.measurement(SAMPLE).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS).tag(ssObj1)
				.fields(ssObj).build();
		System.out.println(point1);

		BatchPoints batchPoints = BatchPoints.database(dbName).build();
		batchPoints.point(point1);
		influxDB.write(batchPoints);
		influxDB.close();
        } else 
        	System.out.println(INFLUXDB_CONNECTION_MSG);
	}

	// *********************************************************************************
	// Method used to get action/resource related performance metrics and push to
	// influx DB : To use where screens/navigation are under embedded frame - Call
	// when your action has new urls
	// *********************************************************************************
	/*
	 * public static void actionPerformance1(String dbName, WebDriver driver, String
	 * labelName, String workBookName, String buildNumber) throws Exception { String
	 * name = null; cap = ((RemoteWebDriver) driver).getCapabilities(); Map<String,
	 * Object> ssObj = new HashMap<String, Object>(); Map<String, String> ssObj1 =
	 * new HashMap<String, String>(); Map<String, Object> ssObj3 = new
	 * HashMap<String, Object>(); Map<String, Object> ssObj4 = new HashMap<String,
	 * Object>(); Map<String, Object> ssObj5 = new HashMap<String, Object>();
	 * Map<String, Object> ssObjCalcMetrics = new HashMap<String, Object>();
	 * Map<String, Object> ssObj6 = new LinkedMap<String, Object>(); // For excel
	 * with combined value Map<String, Object> ssObjCalcMetrics1 = new
	 * HashMap<String, Object>(); String timeStamp = formatter.format(new Date());
	 * //for (String url : urlList) { int length = Integer.parseInt((String)
	 * ((JavascriptExecutor) driver) .executeScript(
	 * PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH
	 * )); for (int i = 0; i <= length - 1; i++) { name = (String)
	 * ((JavascriptExecutor) driver)
	 * .executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE + (i) +
	 * ENTRIES_NAME); //if (name.equals(url)) { String navigationEntries =
	 * EMPTY_EMPTY; if
	 * (cap.getBrowserName().equalsIgnoreCase("internet explorer")) { for (String
	 * entries : performanceMetricField) { navigationEntries = navigationEntries +
	 * "," + entries + ":" + (String) ((JavascriptExecutor) driver) .executeScript(
	 * PERFORMANCE_ENTRIES_BY_RESOURCE_JSON +
	 * i + "]." + entries + "))"); } for (String entries : stringMetricField) {
	 * navigationEntries = navigationEntries + "," + entries + ":" + (String)
	 * ((JavascriptExecutor) driver) .executeScript(
	 * PERFORMANCE_ENTRIES_BY_RESOURCE_JSON+i+
	 * "]." + entries + "))"); } navigationEntries = navigationEntries +
	 * INITIATOR_TYPE01 + ":" + (String) ((JavascriptExecutor) driver)
	 * .executeScript(
	 * PERFORMANCE_ENTRIES_BY_RESOURCE_JSON+i+
	 * INITIATOR_TYPE); } else { navigationEntries = (String)
	 * ((JavascriptExecutor) driver).executeScript(
	 * PERFORMANCE_ENTRIES_BY_RESOURCE_JSON01 + i +
	 * "]))"); } navigationEntries = navigationEntries.replace('"', ' ').trim();
	 * String[] navigationEntryArray = navigationEntries.split(","); Map<String,
	 * Object> ssObj2 = new LinkedMap<String, Object>(); for (String value :
	 * navigationEntryArray) {
	 * 
	 * ssObj2.put(LABEL, labelName); ssObj6.put(LABEL, labelName);
	 * ssObj2.put(TIMESTAMP, timeStamp); ssObj6.put(TIMESTAMP, timeStamp);
	 * ssObj2.put(BROWSER, cap.getBrowserName()); ssObj6.put(BROWSER,
	 * cap.getBrowserName()); String browserName = cap.getBrowserName().substring(0,
	 * 1).toUpperCase() + cap.getBrowserName().substring(1); // change 1st letter to
	 * capital ssObj1.put(BROWSER, browserName); // to push to db as tag String[]
	 * val = null; if (value.contains("://")) { val = value.split(":"); val[0] =
	 * val[0].replace('{', ' ').trim(); val[1] = val[1] + ":" + val[2]; val[0] =
	 * val[0].replace('"', ' ').trim(); val[1] = val[1].replace('"', ' ').trim();
	 * ssObj5.put(val[0], val[1]); ssObj2.put(val[0], val[1]); ssObj6.put(val[0],
	 * val[1]); } else { val = value.split(":"); val[0] = val[0].replace('{', '
	 * ').trim(); val[1] = val[1].replace('}', ' ').trim(); val[0] =
	 * val[0].replace('"', ' ').trim(); val[1] = val[1].replace('"', ' ').trim(); if
	 * (val[1].matches(NUMBER_REGX))
	 * 
	 * { float value1 = Float.parseFloat(val[1]); ssObj2.put(val[0], value1);
	 * ssObj3.put(val[0], value1); } else { ssObj2.put(val[0], val[1]);
	 * ssObj4.put(val[0], val[1]); } }
	 * 
	 * }
	 * 
	 * String[] arrExcludeAddition_Start = new String[] { CONNECT_START,
	 * DOMAIN_LOOKUP_START, FETCH_START, REQUEST_START, RESPONSE_START,
	 * SECURE_CONNECTION_START, START_TIME, REDIRECT_START, TIME_TO_FIRST_BYTE };
	 * 
	 * String[] arrExcludeAddition_End = new String[] { CONNECT_END,
	 * DOMAIN_LOOKUP_END, REQUEST_END, RESPONSE_END, REDIRECT_END };
	 * 
	 * // Convert String Array to List List<String> listExcludeAddition_Start =
	 * Arrays.asList(arrExcludeAddition_Start); List<String> listExcludeAddition_End
	 * = Arrays.asList(arrExcludeAddition_End);
	 * 
	 * ssObj3 = MetricsArithmeticCalculationAction(ssObj3); ssObj2 =
	 * MetricsArithmeticCalculationAction(ssObj2);
	 * 
	 * if (!ssObj3.isEmpty()) { for (String key : ssObj3.keySet()) { if
	 * (!ssObj.containsKey(key)) { ssObj.put(key, ssObj3.get(key)); ssObj6.put(key,
	 * ssObj3.get(key)); } else { if (listExcludeAddition_Start.contains(key)) { //
	 * Replace if the new value is less than the old start value, else skip if
	 * (Float.parseFloat(ssObj3.get(key).toString()) < Float
	 * .parseFloat(ssObj.get(key).toString())) { ssObj.replace(key,
	 * ssObj3.get(key)); ssObj6.replace(key, ssObj3.get(key)); }
	 * 
	 * } else if (listExcludeAddition_End.contains(key)) { // Replace if the new
	 * value is greater than the old end value, else skip if
	 * (Float.parseFloat(ssObj3.get(key).toString()) > Float
	 * .parseFloat(ssObj.get(key).toString())) { ssObj.replace(key,
	 * ssObj3.get(key)); ssObj6.replace(key, ssObj3.get(key)); } } else { float
	 * value1 = Float.parseFloat(ssObj3.get(key).toString()); float value2 =
	 * Float.parseFloat(ssObj.get(key).toString()) + value1; ssObj.replace(key,
	 * value2); ssObj6.replace(key, value2); } } } for (String key :
	 * ssObj4.keySet()) {
	 * 
	 * if (!ssObj1.containsKey(key)) { ssObj1.put(key, ssObj4.get(key).toString());
	 * ssObj6.put(key, ssObj4.get(key).toString()); } else { ssObj1.replace(key,
	 * ssObj4.get(key).toString()); ssObj6.replace(key, ssObj4.get(key).toString());
	 * } } if (!ssObj1.containsKey("name")) { ssObj1.put("name",
	 * ssObj5.get("name").toString()); ssObj6.put("name",
	 * ssObj5.get("name").toString()); } else { String nameUrl = ssObj1.get("name")
	 * + " " + ssObj5.get("name").toString(); ssObj1.replace("name", nameUrl);
	 * ssObj6.replace("name", nameUrl); } }
	 * ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj2, workBookName); //}
	 * 
	 * }
	 * 
	 * //}
	 * 
	 * ssObj1.put(LABEL, labelName); // To put as tag type ssObj1.put(RUN_ID,
	 * buildNumber); // runid
	 * 
	 * // change 1st letter to capital - for entryType String entryType =
	 * ssObj1.get(ENTRY_TYPE); String entryTypeRevised = entryType.substring(0,
	 * 1).toUpperCase() + entryType.substring(1); // change 1st letter // to capital
	 * ssObj1.replace(ENTRY_TYPE, entryTypeRevised); ssObjCalcMetrics =
	 * MetricsArithmeticCalculationAction(ssObj); ssObjCalcMetrics1 =
	 * MetricsArithmeticCalculationAction(ssObj6);
	 * 
	 * InfluxDB influxDB = InfluxDBFactory.connect("http://172.24.112.219:8086",
	 * "root", "root"); if (influxDB != null) {
	 * System.out.println(INFLUX_SUCCESS_MSG); }
	 * Point point1 = null;
	 * 
	 * point1 = Point.measurement(SAMPLE).time(System.currentTimeMillis(),
	 * TimeUnit.MILLISECONDS).tag(ssObj1) .fields(ssObj).build();
	 * System.out.println(point1);
	 * 
	 * BatchPoints batchPoints = BatchPoints.database(dbName).build();
	 * batchPoints.point(point1); influxDB.write(batchPoints); influxDB.close(); }
	 */
	// *********************************************************************************
	// Method used to get action/resource related performance metrics and push to
	// influx DB - Use when urls keeps on adding and url is not unique
	// *********************************************************************************
	public static void actionPerformance2(String dbName, WebDriver driver,String browserInit, List<String> urlList, String labelName,
			String workBookName, String buildNumber, String dbUrl, String OutputFileLocation, String influxDBCon) throws Exception {
		try {
			String name = null;
			cap = ((RemoteWebDriver) driver).getCapabilities();
			Map<String, Object> ssObj7 = new LinkedMap<String, Object>();
			Map<String, Object> ssObj = new HashMap<String, Object>();
			Map<String, String> ssObj1 = new HashMap<String, String>();
			Map<String, Object> ssObj3 = new HashMap<String, Object>();
			Map<String, Object> ssObj4 = new HashMap<String, Object>();
			Map<String, Object> ssObj5 = new HashMap<String, Object>();
			Map<String, Object> ssObjCalcMetrics = new HashMap<String, Object>();
			Map<String, Object> ssObj6 = new LinkedMap<String, Object>(); // For excel with combined value
			Map<String, Object> ssObjCalcMetrics1 = new HashMap<String, Object>();
			String timeStamp = formatter.format(new Date());
			int length = Integer.parseInt((String) ((JavascriptExecutor) driver)
					.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH));
			// for (String url : urlList) {
			// System.out.println("--------------------------------------> Before loop
			// resource count :" + length);
			try {
				for (int i = length - urlList.size(); i <= length - 1; i++) {
					try {
						name = (String) ((JavascriptExecutor) driver)
								.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE + (i) + ENTRIES_NAME);
					} catch (Exception e) {
						System.out.println(
								"-------------------->Name Property not available: am catched ------------------>");
						name = "UNKNOWN";
					}
					// if (name.equals(url)) {
					String navigationEntries = EMPTY_EMPTY;
					if (browserInit.equalsIgnoreCase("ie")) {
						for (String entries : performanceMetricField) {
							navigationEntries = navigationEntries + "," + entries + ":"
									+ (String) ((JavascriptExecutor) driver).executeScript(
											PERFORMANCE_ENTRIES_BY_RESOURCE_JSON
													+ i + "]." + entries + "))");
						}
						for (String entries : stringMetricField) {
							navigationEntries = navigationEntries + "," + entries + ":"
									+ (String) ((JavascriptExecutor) driver).executeScript(
											PERFORMANCE_ENTRIES_BY_RESOURCE_JSON
													+ i + "]." + entries + "))");
						}
						navigationEntries = navigationEntries + INITIATOR_TYPE01 + ":"
								+ (String) ((JavascriptExecutor) driver).executeScript(
										PERFORMANCE_ENTRIES_BY_RESOURCE_JSON + i
												+ INITIATOR_TYPE);
					} else {
						navigationEntries = (String) ((JavascriptExecutor) driver).executeScript(
								PERFORMANCE_ENTRIES_BY_RESOURCE_JSON01 + i + "]))");
					}
					navigationEntries = navigationEntries.replace('"', ' ').trim();
					String[] navigationEntryArray = navigationEntries.split(",");

					//Remove track resource from list
//					if (navigationEntryArray[0].contains("v2/track")) {
//						continue;
//						List<String> list = Arrays.asList(navigationEntryArray);
//						for (String str : list) {
//							if (str.contains("v2/track"))
//								list.remove(str);
//						}
//						navigationEntryArray = (String[]) list.toArray();
//					}

					Map<String, Object> ssObj2 = new LinkedMap<String, Object>();
					for (String value : navigationEntryArray) {

						ssObj2.put(LABEL, labelName);
						ssObj6.put(LABEL, labelName);
						ssObj2.put(TIMESTAMP, timeStamp);
						ssObj6.put(TIMESTAMP, timeStamp);
						ssObj2.put(BROWSER,
								browserInit.substring(0, 1).toUpperCase() + browserInit.substring(1));
						ssObj6.put(BROWSER, browserInit);
						String browserName = browserInit.substring(0, 1).toUpperCase()
								+ browserInit.substring(1); // change 1st letter to capital
						ssObj1.put(BROWSER, browserName); // to push to db as tag
						String[] val = null;
						if (value.contains("://")) {
							val = value.split(":");
							val[0] = val[0].replace('{', ' ').trim();
							val[1] = val[1] + ":" + val[2];
							val[0] = val[0].replace('"', ' ').trim();
							val[1] = val[1].replace('"', ' ').trim();
							ssObj5.put(val[0], val[1]);
							ssObj2.put(val[0], val[1]);
							ssObj6.put(val[0], val[1]);
						} else {
							val = value.split(":");
							val[0] = val[0].replace('{', ' ').trim();
							val[0] = val[0].replace('"', ' ').trim();

							if (val.length > 1) {
								val[1] = val[1].replace('}', ' ').trim();
								val[1] = val[1].replace('"', ' ').trim();
								if (val[1].matches(NUMBER_REGX)){
									float value1 = Float.parseFloat(val[1]);
									ssObj2.put(val[0], value1);
									ssObj3.put(val[0], value1);
								} else {
									ssObj2.put(val[0], val[1]);
									ssObj4.put(val[0], val[1]);
								}
							}
						}

					}

					String[] arrExcludeAddition_Start = new String[] { CONNECT_START, DOMAIN_LOOKUP_START,
							FETCH_START, REQUEST_START, RESPONSE_START, SECURE_CONNECTION_START, START_TIME,
							REDIRECT_START, TIME_TO_FIRST_BYTE };

					String[] arrExcludeAddition_End = new String[] { CONNECT_END, DOMAIN_LOOKUP_END, REQUEST_END,
							RESPONSE_END, REDIRECT_END };

					// Convert String Array to List
					List<String> listExcludeAddition_Start = Arrays.asList(arrExcludeAddition_Start);
					List<String> listExcludeAddition_End = Arrays.asList(arrExcludeAddition_End);

					ssObj3 = MetricsArithmeticCalculationAction(ssObj3);
					ssObj2 = MetricsArithmeticCalculationAction(ssObj2);

					if (!ssObj3.isEmpty()) {
						for (String key : ssObj3.keySet()) {
							if (!ssObj.containsKey(key)) {
								ssObj.put(key, ssObj3.get(key));
								ssObj6.put(key, ssObj3.get(key));
							} else {
								if (listExcludeAddition_Start.contains(key)) {
									// Replace if the new value is less than the old start value, else skip
									if (Float.parseFloat(ssObj3.get(key).toString()) < Float
											.parseFloat(ssObj.get(key).toString())) {
										ssObj.replace(key, ssObj3.get(key));
										ssObj6.replace(key, ssObj3.get(key));
									}

								} else if (listExcludeAddition_End.contains(key)) {
									// Replace if the new value is greater than the old end value, else skip
									if (Float.parseFloat(ssObj3.get(key).toString()) > Float
											.parseFloat(ssObj.get(key).toString())) {
										ssObj.replace(key, ssObj3.get(key));
										ssObj6.replace(key, ssObj3.get(key));
									}
								} else {
									float value1 = Float.parseFloat(ssObj3.get(key).toString());
									float value2 = Float.parseFloat(ssObj.get(key).toString()) + value1;
									ssObj.replace(key, value2);
									ssObj6.replace(key, value2);
								}
							}
						}
						for (String key : ssObj4.keySet()) {

							if (!ssObj1.containsKey(key)) {
								ssObj1.put(key, ssObj4.get(key).toString());
								ssObj6.put(key, ssObj4.get(key).toString());
							} else {
								ssObj1.replace(key, ssObj4.get(key).toString());
								ssObj6.replace(key, ssObj4.get(key).toString());
							}
						}
						if (!ssObj1.containsKey("name")) {
							ssObj1.put("name", ssObj5.get("name").toString());
							ssObj6.put("name", ssObj5.get("name").toString());
						} else {
							String nameUrl = ssObj1.get("name") + " " + ssObj5.get("name").toString();
							ssObj1.replace("name", nameUrl);
							ssObj6.replace("name", nameUrl);
						}
					}
					if (detailedRawData) {
						ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj2, workBookName, OutputFileLocation);
					}
					// }

					length = Integer.parseInt((String) ((JavascriptExecutor) driver).executeScript(
							PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH));
					// System.out.println(
					// "--------------------------------------> after loop resource count :" +
					// length);
				}

			} catch (Exception e) {
				System.out.println(
						"-----------------------------> Array Index out of bounds excpetion-------------------->");
				System.out.println("Exception is : " + e.getStackTrace());
				// System.out.println("--------------------------------------> Before loop
				// resource count :" + length);
			}

			// }

			ssObj1.put(LABEL, labelName); // To put as tag type
			ssObj1.put(RUN_ID, buildNumber); // runid

			// change 1st letter to capital - for entryType
			String entryType = ssObj1.get(ENTRY_TYPE);
			String entryTypeRevised = entryType.substring(0, 1).toUpperCase() + entryType.substring(1); // change 1st
			String[] hostName = InetAddress.getLocalHost().toString().split("/");
			ssObj1.put(HOST_NAME, hostName[0]);																							// letter
																										// to capital
			ssObj1.replace(ENTRY_TYPE, entryTypeRevised);
			ssObjCalcMetrics = MetricsArithmeticCalculationAction(ssObj);
			ssObjCalcMetrics1 = MetricsArithmeticCalculationAction(ssObj6);
			if (!detailedRawData) {
				for (Map.Entry<String, Object> entry : ssObj.entrySet()) {
					ssObj7.put(entry.getKey(), entry.getValue());
				}
				for (Entry<String, String> entry : ssObj1.entrySet()) {
					ssObj7.put(entry.getKey(), entry.getValue());
				}
				long threadId = Thread.currentThread().getId();
				ssObj7.put(TIMESTAMP,
						InetAddress.getLocalHost() + THREAD + threadId + "_" + formatter.format(new Date()));
				ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj7, workBookName, OutputFileLocation);
			}

			/*
			 * InfluxDB influxDB = InfluxDBFactory.connect("http://172.24.112.219:8086",
			 * "root", "root"); if (influxDB != null) {
			 * System.out.println(INFLUX_SUCCESS_MSG); }
			 * Point point1 = null;
			 * 
			 * point1 = Point.measurement(SAMPLE).time(System.currentTimeMillis(),
			 * TimeUnit.MILLISECONDS).tag(ssObj1) .fields(ssObj).build();
			 * System.out.println(point1);
			 * 
			 * BatchPoints batchPoints = BatchPoints.database(dbName).build();
			 * batchPoints.point(point1); influxDB.write(batchPoints); influxDB.close();
			 */
			if(influxDBCon.equalsIgnoreCase("true")) {
			InfluxDB influxDB = InfluxDBFactory.connect(dbUrl, INFLUXDB_USERNAME, INFLUXDB_PASSWORD);
			if (influxDB != null) {
				System.out.println(INFLUX_SUCCESS_MSG);
			}
			Point point1 = null;

			point1 = Point.measurement(SAMPLE).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS).tag(ssObj1)
					.fields(ssObj).build();
			System.out.println(point1);

			BatchPoints batchPoints = BatchPoints.database(dbName).build();
			batchPoints.point(point1);
			influxDB.write(batchPoints);
			influxDB.close();
			} else 
				System.out.println(INFLUXDB_CONNECTION_MSG);
		} catch (Exception e) {
			System.out.println(ERROR_DETAILS +e.getMessage());
		}
	}

	// *********************************************************************************
	// Method used to get action/resource related performance metrics and push to
	// influx DB - Use when urls are newly generated
	// *********************************************************************************
	public static void actionPerformance1(String dbName, WebDriver driver, String browserInit,List<String> urlList, String labelName,
			String workBookName, String buildNumber, String dbUrl, String OutputFileLocation, String influxDBCon) throws Exception {
		try {
			String name = null;
			cap = ((RemoteWebDriver) driver).getCapabilities();
			Map<String, Object> ssObj7 = new LinkedMap<String, Object>();
			Map<String, Object> ssObj = new HashMap<String, Object>();
			Map<String, String> ssObj1 = new HashMap<String, String>();
			Map<String, Object> ssObj3 = new HashMap<String, Object>();
			Map<String, Object> ssObj4 = new HashMap<String, Object>();
			Map<String, Object> ssObj5 = new HashMap<String, Object>();
			Map<String, Object> ssObjCalcMetrics = new HashMap<String, Object>();
			Map<String, Object> ssObj6 = new LinkedMap<String, Object>(); // For excel with combined value
			Map<String, Object> ssObjCalcMetrics1 = new HashMap<String, Object>();
			String timeStamp = formatter.format(new Date());
			int length = Integer.parseInt((String) ((JavascriptExecutor) driver)
					.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH));
			// for (String url : urlList) {
			// System.out.println("--------------------------------------> Before loop
			// resource count :" + length);
			try {
				for (int i = 0; i <= length - 1; i++) {
					try {
						name = (String) ((JavascriptExecutor) driver)
								.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE + (i) + ENTRIES_NAME);
					} catch (Exception e) {
						System.out.println(
								"-------------------->Name Property not available: am catched ------------------>");
						name = "UNKNOWN";
					}
					// if (name.equals(url)) {
					String navigationEntries = EMPTY_EMPTY;
					if (browserInit.equalsIgnoreCase("ie")) {
						for (String entries : performanceMetricField) {
							navigationEntries = navigationEntries + "," + entries + ":"
									+ (String) ((JavascriptExecutor) driver).executeScript(
											PERFORMANCE_ENTRIES_BY_RESOURCE_JSON
													+ i + "]." + entries + "))");
						}
						for (String entries : stringMetricField) {
							navigationEntries = navigationEntries + "," + entries + ":"
									+ (String) ((JavascriptExecutor) driver).executeScript(
											PERFORMANCE_ENTRIES_BY_RESOURCE_JSON
													+ i + "]." + entries + "))");
						}
						navigationEntries = navigationEntries + INITIATOR_TYPE01 + ":"
								+ (String) ((JavascriptExecutor) driver).executeScript(
										PERFORMANCE_ENTRIES_BY_RESOURCE_JSON + i
												+ INITIATOR_TYPE);
					} else {
						navigationEntries = (String) ((JavascriptExecutor) driver).executeScript(
								PERFORMANCE_ENTRIES_BY_RESOURCE_JSON01 + i + "]))");
					}
					navigationEntries = navigationEntries.replace('"', ' ').trim();
					String[] navigationEntryArray = navigationEntries.split(",");
					Map<String, Object> ssObj2 = new LinkedMap<String, Object>();
					for (String value : navigationEntryArray) {

						ssObj2.put(LABEL, labelName);
						ssObj6.put(LABEL, labelName);
						ssObj2.put(TIMESTAMP, timeStamp);
						ssObj6.put(TIMESTAMP, timeStamp);
						ssObj2.put(BROWSER,
								browserInit.substring(0, 1).toUpperCase() + browserInit.substring(1));
						ssObj6.put(BROWSER, browserInit);
						String browserName = browserInit.substring(0, 1).toUpperCase()
								+ browserInit.substring(1); // change 1st letter to capital
						ssObj1.put(BROWSER, browserName); // to push to db as tag
						String[] val = null;
						if (value.contains("://")) {
							val = value.split(":");
							val[0] = val[0].replace('{', ' ').trim();
							val[1] = val[1] + ":" + val[2]; //+ ":" + val[3];//Need New logic for handling : when url has port number eg http://aspirenav:8086/browse
							val[0] = val[0].replace('"', ' ').trim();
							val[1] = val[1].replace('"', ' ').trim();
							ssObj5.put(val[0], val[1]);
							ssObj2.put(val[0], val[1]);
							ssObj6.put(val[0], val[1]);
						} else {
							val = value.split(":");
							val[0] = val[0].replace('{', ' ').trim();
							val[1] = val[1].replace('}', ' ').trim();
							val[0] = val[0].replace('"', ' ').trim();
							val[1] = val[1].replace('"', ' ').trim();
							if (val[1].matches(NUMBER_REGX))

							{
								float value1 = Float.parseFloat(val[1]);
								ssObj2.put(val[0], value1);
								ssObj3.put(val[0], value1);
							} else {
								ssObj2.put(val[0], val[1]);
								ssObj4.put(val[0], val[1]);
							}
						}

					}

					String[] arrExcludeAddition_Start = new String[] { CONNECT_START, DOMAIN_LOOKUP_START,
							FETCH_START, REQUEST_START, RESPONSE_START, SECURE_CONNECTION_START, START_TIME,
							REDIRECT_START, TIME_TO_FIRST_BYTE };

					String[] arrExcludeAddition_End = new String[] { CONNECT_END, DOMAIN_LOOKUP_END, REQUEST_END,
							RESPONSE_END, REDIRECT_END };

					// Convert String Array to List
					List<String> listExcludeAddition_Start = Arrays.asList(arrExcludeAddition_Start);
					List<String> listExcludeAddition_End = Arrays.asList(arrExcludeAddition_End);

					ssObj3 = MetricsArithmeticCalculationAction(ssObj3);
					ssObj2 = MetricsArithmeticCalculationAction(ssObj2);

					if (!ssObj3.isEmpty()) {
						for (String key : ssObj3.keySet()) {
							if (!ssObj.containsKey(key)) {
								ssObj.put(key, ssObj3.get(key));
								ssObj6.put(key, ssObj3.get(key));
							} else {
								if (listExcludeAddition_Start.contains(key)) {
									// Replace if the new value is less than the old start value, else skip
									if (Float.parseFloat(ssObj3.get(key).toString()) < Float
											.parseFloat(ssObj.get(key).toString())) {
										ssObj.replace(key, ssObj3.get(key));
										ssObj6.replace(key, ssObj3.get(key));
									}

								} else if (listExcludeAddition_End.contains(key)) {
									// Replace if the new value is greater than the old end value, else skip
									if (Float.parseFloat(ssObj3.get(key).toString()) > Float
											.parseFloat(ssObj.get(key).toString())) {
										ssObj.replace(key, ssObj3.get(key));
										ssObj6.replace(key, ssObj3.get(key));
									}
								} else {
									float value1 = Float.parseFloat(ssObj3.get(key).toString());
									float value2 = Float.parseFloat(ssObj.get(key).toString()) + value1;
									ssObj.replace(key, value2);
									ssObj6.replace(key, value2);
								}
							}
						}
						for (String key : ssObj4.keySet()) {

							if (!ssObj1.containsKey(key)) {
								ssObj1.put(key, ssObj4.get(key).toString());
								ssObj6.put(key, ssObj4.get(key).toString());
							} else {
								ssObj1.replace(key, ssObj4.get(key).toString());
								ssObj6.replace(key, ssObj4.get(key).toString());
							}
						}
						if (!ssObj1.containsKey("name")) {
							ssObj1.put("name", ssObj5.get("name").toString());
							ssObj6.put("name", ssObj5.get("name").toString());
						} else {
							String nameUrl = ssObj1.get("name") + " " + ssObj5.get("name").toString();
							ssObj1.replace("name", nameUrl);
							ssObj6.replace("name", nameUrl);
						}
					}
					if (detailedRawData) {
						ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj2, workBookName, OutputFileLocation);
					}
					// }

					length = Integer.parseInt((String) ((JavascriptExecutor) driver).executeScript(
							PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH));
					// System.out.println(
					// "--------------------------------------> after loop resource count :" +
					// length);
				}

			} catch (Exception e) {
				System.out.println(
						"-----------------------------> Array Index out of bounds excpetion-------------------->"
								+ length);
				System.out.println("Exception is : " + e.getStackTrace());
				// System.out.println("--------------------------------------> Before loop
				// resource count :" + length);
			}

			
			// }

			ssObj1.put(LABEL, labelName); // To put as tag type
			ssObj1.put(RUN_ID, buildNumber); // runid

			// change 1st letter to capital - for entryType
			String entryType = ssObj1.get(ENTRY_TYPE);
			String entryTypeRevised = entryType.substring(0, 1).toUpperCase() + entryType.substring(1); // change 1st
			String[] hostName = InetAddress.getLocalHost().toString().split("/");
			ssObj1.put(HOST_NAME, hostName[0]);																						// letter
																						// to capital
			ssObj1.replace(ENTRY_TYPE, entryTypeRevised);
			ssObjCalcMetrics = MetricsArithmeticCalculationAction(ssObj);
			ssObjCalcMetrics1 = MetricsArithmeticCalculationAction(ssObj6);
			if (!detailedRawData) {
				
				for (Map.Entry<String, Object> entry : ssObj.entrySet()) {
					ssObj7.put(entry.getKey(), entry.getValue());
				}
				for (Entry<String, String> entry : ssObj1.entrySet()) {
					ssObj7.put(entry.getKey(), entry.getValue());
				}
				
				long threadId = Thread.currentThread().getId();
				ssObj7.put(TIMESTAMP,
						InetAddress.getLocalHost() + THREAD + threadId + "_" + formatter.format(new Date()));
				ExcelWrite.createWorkBookData(NAVIGATION_TIMING, ssObj7, workBookName, OutputFileLocation);
				
			}

			/*
			 * InfluxDB influxDB = InfluxDBFactory.connect("http://172.24.112.219:8086",
			 * "root", "root"); if (influxDB != null) {
			 * System.out.println(INFLUX_SUCCESS_MSG); }
			 * Point point1 = null;
			 * 
			 * point1 = Point.measurement(SAMPLE).time(System.currentTimeMillis(),
			 * TimeUnit.MILLISECONDS).tag(ssObj1) .fields(ssObj).build();
			 * System.out.println(point1);
			 * 
			 * BatchPoints batchPoints = BatchPoints.database(dbName).build();
			 * batchPoints.point(point1); influxDB.write(batchPoints); influxDB.close();
			 */
			if(influxDBCon.equalsIgnoreCase("true")) {
			InfluxDB influxDB = InfluxDBFactory.connect(dbUrl, INFLUXDB_USERNAME, INFLUXDB_PASSWORD);
			if (influxDB != null) {
				System.out.println(INFLUX_SUCCESS_MSG);
			}
			Point point1 = null;

			point1 = Point.measurement(SAMPLE).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS).tag(ssObj1)
					.fields(ssObj).build();
			System.out.println(point1);

			BatchPoints batchPoints = BatchPoints.database(dbName).build();
			batchPoints.point(point1);
			influxDB.write(batchPoints);
			influxDB.close();
			} else 
				System.out.println(INFLUXDB_CONNECTION_MSG);
			
		} catch (Exception e) {
			System.out.println(ERROR_DETAILS +e.getMessage());
		}
	}

	// *********************************************************************************
	// Method used to calculate the key metrics for navigation from raw data
	// *********************************************************************************
	private static Map<String, Object> MetricsArithmeticCalculationNavigation(Map<String, Object> ssObj) {

		ssObj.put("Redirect", (Float.valueOf((String.valueOf(ssObj.get(REDIRECT_END))))
				- Float.valueOf((String.valueOf(ssObj.get(REDIRECT_START))))));
		ssObj.put("AppCache", (Float.valueOf((String.valueOf(ssObj.get(DOMAIN_LOOKUP_START))))
				- Float.valueOf((String.valueOf(ssObj.get(FETCH_START))))));
		ssObj.put("DNSLookupTime", (Float.valueOf((String.valueOf(ssObj.get(DOMAIN_LOOKUP_END))))
				- Float.valueOf((String.valueOf(ssObj.get(DOMAIN_LOOKUP_START))))));
		ssObj.put("TCP", (Float.valueOf((String.valueOf(ssObj.get(CONNECT_END))))
				- Float.valueOf((String.valueOf(ssObj.get(CONNECT_START))))));
		ssObj.put("Request", (Float.valueOf((String.valueOf(ssObj.get(RESPONSE_START))))
				- Float.valueOf((String.valueOf(ssObj.get(REQUEST_START))))));
		ssObj.put("Response", (Float.valueOf((String.valueOf(ssObj.get(RESPONSE_END))))
				- Float.valueOf((String.valueOf(ssObj.get(RESPONSE_START))))));
		// NA for resource
		ssObj.put("Processing", (Float.valueOf((String.valueOf(ssObj.get("domComplete"))))
				- Float.valueOf((String.valueOf(ssObj.get(DOM_INTERACTIVE)))))); // new domcomplete-domloading //same
		// NA for resource
		ssObj.put("LoadEvent", (Float.valueOf((String.valueOf(ssObj.get(LOAD_EVENT_END))))
				- Float.valueOf((String.valueOf(ssObj.get("loadEventStart"))))));
		// NA for resource
		ssObj.put("TotalTime", (Float.valueOf((String.valueOf(ssObj.get(LOAD_EVENT_END))))
				- Float.valueOf((String.valueOf(ssObj.get(REDIRECT_START))))));
		ssObj.put(TIME_TO_FIRST_BYTE, (Float.valueOf((String.valueOf(ssObj.get(RESPONSE_START)))))); // responsestart
		// NA for resource
		ssObj.put("TimetoInteractive", (Float.valueOf((String.valueOf(ssObj.get(DOM_INTERACTIVE)))))); // dominteractive
		// NA for resource
		ssObj.put("WebpageResponseTime", (Float.valueOf((String.valueOf(ssObj.get("loadEventStart"))))
				- Float.valueOf((String.valueOf(ssObj.get(REDIRECT_START))))));
		// ssObj.put("DOMContentLoadedTime",
		// (Float.valueOf((String.valueOf(ssObj.get("domContentLoadedEventStart"))))));
		// Formula change
		ssObj.put("DOMContentLoadedTime", (Float.valueOf((String.valueOf(ssObj.get("domContentLoadedEventEnd"))))
				- Float.valueOf((String.valueOf(ssObj.get(REDIRECT_START))))));
		// newly added //NA for resource
		ssObj.put("OnLoadTime", (Float.valueOf((String.valueOf(ssObj.get("loadEventStart"))))
				- Float.valueOf((String.valueOf(ssObj.get(REDIRECT_START))))));

		return ssObj;
	}

	// *********************************************************************************
	// Method used to calculate the key metrics for action/resource from raw data
	// *********************************************************************************
	private static Map<String, Object> MetricsArithmeticCalculationAction(Map<String, Object> ssObj) {

		ssObj.put("Redirect", (Float.valueOf((String.valueOf(ssObj.get(REDIRECT_END))))
				- Float.valueOf((String.valueOf(ssObj.get(REDIRECT_START))))));
		ssObj.put("AppCache", (Float.valueOf((String.valueOf(ssObj.get(DOMAIN_LOOKUP_START))))
				- Float.valueOf((String.valueOf(ssObj.get(FETCH_START))))));
		ssObj.put("DNSLookupTime", (Float.valueOf((String.valueOf(ssObj.get(DOMAIN_LOOKUP_END))))
				- Float.valueOf((String.valueOf(ssObj.get(DOMAIN_LOOKUP_START))))));
		ssObj.put("TCP", (Float.valueOf((String.valueOf(ssObj.get(CONNECT_END))))
				- Float.valueOf((String.valueOf(ssObj.get(CONNECT_START))))));
		ssObj.put("Request", (Float.valueOf((String.valueOf(ssObj.get(RESPONSE_START))))
				- Float.valueOf((String.valueOf(ssObj.get(REQUEST_START))))));
		ssObj.put("Response", (Float.valueOf((String.valueOf(ssObj.get(RESPONSE_END))))
				- Float.valueOf((String.valueOf(ssObj.get(RESPONSE_START))))));
		// Using duration as total time for resource
		ssObj.put("TotalTime", (Float.valueOf((String.valueOf(ssObj.get(RESPONSE_END))))
				- Float.valueOf((String.valueOf(ssObj.get(START_TIME))))));

		ssObj.put(TIME_TO_FIRST_BYTE, (Float.valueOf((String.valueOf(ssObj.get(RESPONSE_START))))
				- Float.valueOf((String.valueOf(ssObj.get(REQUEST_START))))));

		return ssObj;
	}

	// *********************************************************************************
	// Method used to get url list for an action/resource
	// *********************************************************************************
	public static List<String> getUrlList(WebDriver driver) {
		List<String> urlList = new ArrayList<String>();
		int length = Integer.parseInt((String) ((JavascriptExecutor) driver)
				.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH));
		for (int i = 0; i <= length - 1; i++) {
			urlList.add((String) ((JavascriptExecutor) driver)
					.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE + (i) + ENTRIES_NAME));
		}
		return urlList;
	}
	
	/**
	 * @param driver
	 * @param perfMetricsCal
	 * @return
	 */
	public static List<String> getUrlList(WebDriver driver, String perfMetricsCal) {
		List<String> urlList = new ArrayList<String>();
		if(perfMetricsCal.equalsIgnoreCase("true") ) {
		int length = Integer.parseInt((String) ((JavascriptExecutor) driver)
				.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE_LENGTH));
		for (int i = 0; i <= length - 1; i++) {
			urlList.add((String) ((JavascriptExecutor) driver)
					.executeScript(PERFORMANCE_ENTRIES_BY_RESOURCE + (i) + ENTRIES_NAME));
		}
		return urlList;
		
		} else 
			return urlList;
	}

	// **************************************************************************
	// Method used to clear all the existing resources of the application loaded
	// **************************************************************************
	public static void clearResources(WebDriver driver) {
		((JavascriptExecutor) driver).executeScript("performance.clearResourceTimings()");
	}

	// *********************************************************************************
	// Main method to call other performance related methods
	// *********************************************************************************
	public static List<String> calculateMeasurement(String dbName, String labelName, boolean isNavigation,
			WebDriver driver, String browserInit,String workBookName, List<String> urlArrayList, String buildNumber, String dbUrl,
			String OutputFileLocation, String influxDB) throws Exception {

		// skip metrics if time is over
		/*
		 * if (((System.currentTimeMillis()-TestSuite.suiteStartTime)/1000) > (new
		 * TestSuite().second+new TestSuite().rampUp)) { System.out.
		 * println("Execution duration completed : Skipping Performance metrics" +
		 * System.currentTimeMillis() + ";"); return getUrlList(driver); }
		 */
		if (apiSwitch.equalsIgnoreCase("true")) {
			if (isNavigation == true) {
				navigationPerformance(dbName, driver,browserInit, workBookName, labelName, buildNumber, dbUrl, OutputFileLocation, influxDB);
			} else {
				List<String> tempArray = getUrlList(driver);
				List<String> newUrl = new ArrayList<String>();
				for (String url : tempArray) {
					if (!urlArrayList.contains(url)) {
						newUrl.add(url);
					}

				}
				// Calculate metrics only if new url is available for resource
				if (newUrl.size() > 0) {
					actionPerformance(dbName, driver,browserInit, newUrl, labelName, workBookName, buildNumber, dbUrl,
							OutputFileLocation, influxDB);
				}
			}

		}
		// Stop all executions once timer is reached
		/*
		 * if (StopExecutionDrivers) { //NA
		 * 
		 * }
		 */
		return getUrlList(driver);
	}

	// *********************************************************************************
	// Main method to call other performance related methods
	// *********************************************************************************
	public static List<String> calculateMeasurement(String dbName, String labelName, boolean isNavigation,
													boolean isNewResource, WebDriver driver,String browserInit, String workBookName, List<String> urlArrayList, String buildNumber,
													String dbUrl, String OutputFileLocation,String perfMetricsCal, String influxDB) throws Exception {
		try {
			// skip metrics if time is over
			/*
			 * if (((System.currentTimeMillis()-TestSuite.suiteStartTime)/1000) > (new
			 * TestSuite().second+new TestSuite().rampUp)) { System.out.
			 * println("Execution duration completed : Skipping Performance metrics" +
			 * System.currentTimeMillis() + ";"); return getUrlList(driver); }
			 * 
			 */
	if(perfMetricsCal.equalsIgnoreCase("true")) {
			if (apiSwitch.equalsIgnoreCase("true")) {
				if (isNavigation == true) {
					navigationPerformance(dbName, driver,browserInit, workBookName, labelName, buildNumber, dbUrl,
							OutputFileLocation, influxDB);
				} else {
					List<String> tempArray = getUrlList(driver);
					if (isNewResource) {
						System.out.println(
								labelName + "-- Treating all resources as new ---------New array length : --------->"
										+ tempArray.size());
						System.out.println("Old array length : --------->" + urlArrayList.size());
						if(tempArray.size()>0)
							actionPerformance1(dbName, driver,browserInit, tempArray, labelName, workBookName, buildNumber, dbUrl,
									OutputFileLocation, influxDB);
						else
							System.out.println(labelName+" To this step not calling action performance since new array length is zero");



					} else {
						System.out
								.println(labelName + "-- Treating new resources are in combination with old--------->");
						List<String> newUrl = new ArrayList<String>();



//                        if (urlArrayList.size() == tempArray.size()) {
//                            for (int i = 0; i < tempArray.size(); i++) {
//                                newUrl.add(tempArray.get(i));
//                            }
//                        }



						for (int i = urlArrayList.size(); i < tempArray.size(); i++) {
							newUrl.add(tempArray.get(i));
						}
						System.out.println(
								labelName + "-- Old array length : " + urlArrayList.size() + "-- New array length : "
										+ tempArray.size() + "-- Diff array length : " + newUrl.size());
						if(newUrl.size()>0)
							actionPerformance2(dbName, driver,browserInit, newUrl, labelName, workBookName, buildNumber, dbUrl,
									OutputFileLocation, influxDB);
						else
							System.out.println(labelName+" To this step not calling action performance since new array length is zero");
					}
					/*
					 * List<String> tempArray = getUrlList(driver); System.out.println(labelName
					 * +"-----------New array length : ------------>"+ tempArray.size() +
					 * "Older array length : --------->"+urlArrayList.size()); List<String> newUrl =
					 * new ArrayList<String>(); for (String url : tempArray) { if
					 * (!tempArray.contains(url)) { newUrl.add(url); } }
					 *
					 * if (newUrl.size() == 0) { if ((tempArray.size()) > (urlArrayList.size())) {
					 * for (int i = urlArrayList.size(); i < tempArray.size(); i++) {
					 * newUrl.add(tempArray.get(i)); } System.out.
					 * println("Duplicated URL difference between older to newer------------------> :"
					 * +newUrl.size()); actionPerformance(dbName, driver, newUrl, labelName,
					 * workBookName, buildNumber); } else { System.out.
					 * println("Missed labels : -----------------------------------------------> "
					 * +labelName); }
					 *
					 * } else { System.out.
					 * println("New URL difference between older to newer------------------> :"
					 * +newUrl.size()); actionPerformance(dbName, driver, newUrl, labelName,
					 * workBookName, buildNumber); }
					 */



				}


			}
			
		} else
			return getUrlList(driver, perfMetricsCal);
			
		} catch (Exception e) {
			throw new Exception("Error while user calculating Jmeter metrics :" + e);
		}
		return getUrlList(driver, perfMetricsCal);
	}
}
