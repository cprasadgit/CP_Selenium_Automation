package com.aspire.utils.mobile;

import java.awt.AWTException;
import java.time.Duration;
import java.util.Arrays;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aspire.utils.Log;

public class UIActions {
	
	
	private static final String HORIZONTAL_LINE = "==========================================================";
	private static final String SUCCESSFULLY_CLICKED_ON = "Successfully clicked on ";
	private static final String ARGUMENT0_CLICK = "arguments[0].click();";
	private static final String SUCCESSFULLY_ENTERED_INTO = " successfully entered into ";
	private static final String DATA = "Data ";
	private static final String ARGUMENTS0_VALUE = "arguments[0]. value='";
	
	/**
	 * Click on an object
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @modified 04-07-2022
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void click(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		WebElement element;
		try {
			if (elementName != null) {
				element = new ObjectRepositoryHandler().getObject(driver, elementName);
				element.click();
				System.out.println(HORIZONTAL_LINE);
				Log.event(SUCCESSFULLY_CLICKED_ON + elementName);
			} else {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
			}
		} catch (Exception e) {
			try {
				element = new ObjectRepositoryHandler().getObject(driver, elementName);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript(ARGUMENT0_CLICK, element);
				System.out.println(HORIZONTAL_LINE);
				Log.event(SUCCESSFULLY_CLICKED_ON + elementName);
			} catch (Exception ex) {
				try {
					element = new ObjectRepositoryHandler().getObject(driver, elementName);
					Actions builder = new Actions(driver);
					Action action = builder.moveToElement(element).click().build();
					action.perform();
					System.out.println(HORIZONTAL_LINE);
					Log.event(SUCCESSFULLY_CLICKED_ON + elementName);
				} catch (Exception exc) {
					System.out.println(HORIZONTAL_LINE);
					Log.fail("Failed to click on the " + elementName);
					throw new MobileExceptionWrapper(exc);
				}
			}
		}
	}

	/**
	 * Click an object based on the given key
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param keyName
	 * @throws AWTException
	 * @throws MobileExceptionWrapper
	 */
	public static void click(WebDriver driver, String elementName, Keys keyName)
			throws AWTException, MobileExceptionWrapper {
		try {
			if (driver != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (element != null) {
					element.sendKeys(keyName);
					System.out.println(HORIZONTAL_LINE);
					System.out.println("Successfully clicked " + keyName.name() + " key on the " + elementName);
				} else {
					throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Click on an object based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @modified 04-07-2022
	 * @param driver
	 * @param tagName
	 * @param direction:  left, right, above, below, near
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void click(WebDriver driver, String tagName, String direction, String elementName)
			throws MobileExceptionWrapper {
		try {
			if (elementName != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				WebElement elementToDoAction = new MobileUtils().getRelativeElement(driver, tagName, direction,
						element);
				elementToDoAction.click();
				System.out.println(HORIZONTAL_LINE);
				System.out.println(SUCCESSFULLY_CLICKED_ON + elementToDoAction);
			} else {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
			}
		} catch (Exception lException) {
			try {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				WebElement elementToDoAction = new MobileUtils().getRelativeElement(driver, tagName, direction,
						element);
				Actions builder = new Actions(driver);
				Action action = builder.moveToElement(elementToDoAction).click().build();
				action.perform();
				System.out.println(HORIZONTAL_LINE);
				System.out.println(SUCCESSFULLY_CLICKED_ON + elementToDoAction);
			} catch (Exception ex) {
				throw new MobileExceptionWrapper(ex);
			}
		}
	}

	/**
	 * Double click on an object
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void doubleClick(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		try {
			if (elementName != null) {
				Actions action = new Actions(driver);
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				action.doubleClick(element).perform();
				System.out.println(HORIZONTAL_LINE);
				System.out.println("Successfully double clicked on " + elementName);
			} else {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
			}
		} catch (Exception e) {
			try {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript(ARGUMENT0_CLICK, element);
				executor.executeScript(ARGUMENT0_CLICK, element);
				System.out.println(HORIZONTAL_LINE);
				System.out.println(SUCCESSFULLY_CLICKED_ON + elementName);
			} catch (Exception ex) {
				throw new MobileExceptionWrapper(ex);
			}
		}
	}

	/**
	 * Multiple click on an object
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param clickCount
	 * @throws MobileExceptionWrapper
	 */
	public static void multiClick(WebDriver driver, String elementName, int clickCount) throws MobileExceptionWrapper {
		try {
			if (elementName != null) {
				DataHandler propertyObj = new DataHandler();
				long timeout = Long
						.parseLong(propertyObj.getProperty(MobileConstants.FRAMEWORK_CONFIG, "SHORT_LOADING"));
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				int i = 0;
				while (i < clickCount) {
					element.click();
					Thread.sleep(1000);
					wait.until(ExpectedConditions.elementToBeClickable(element));
				}
				System.out.println(HORIZONTAL_LINE);
				System.out.println("Successfully multi-clicked on " + elementName);
			} else {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
			}
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e);
		}
	}

	/**
	 * Click on an object based on the X and Y Coordinates of an object
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param xOffset
	 * @param yOffset
	 * @throws MobileExceptionWrapper
	 */
	public static void clickUsingCoordinates(WebDriver driver, int xOffset, int yOffset) throws MobileExceptionWrapper {
		try {
			new MobileUtils().delay(3);
			PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
			Sequence tap = new Sequence(finger, 1);
			tap.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), xOffset, yOffset));
			tap.addAction(finger.createPointerDown(0));
			tap.addAction(finger.createPointerUp(0));
			((RemoteWebDriver) driver).perform(Arrays.asList(tap));
			System.out.println(HORIZONTAL_LINE);
			Log.event(SUCCESSFULLY_CLICKED_ON + xOffset + " and " + yOffset + " locations");
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e);
		}
	}

	/**
	 * Type values to an input field
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementExpression
	 * @param typeValue
	 * @throws MobileExceptionWrapper
	 */
	public static void type(WebDriver driver, String elementName, String typeValue) throws MobileExceptionWrapper {
		try {
			if (driver != null && elementName != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				element.sendKeys(typeValue);
				System.out.println(HORIZONTAL_LINE);
				Log.event(DATA + typeValue + SUCCESSFULLY_ENTERED_INTO + elementName);
			}
		} catch (Exception e) {
			try {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript(ARGUMENTS0_VALUE + typeValue + "';", element);
				System.out.println(HORIZONTAL_LINE);
				Log.event(DATA + typeValue + SUCCESSFULLY_ENTERED_INTO + elementName);
			} catch (Exception ex) {
				System.out.println(HORIZONTAL_LINE);
				Log.fail(DATA + typeValue + " failed to enter into " + elementName);
				throw new MobileExceptionWrapper(ex);
			}
		}
	}

	/**
	 * Type values to an input field based on Keys
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementExpression
	 * @param typeValue
	 * @throws MobileExceptionWrapper
	 */
	public static void type(WebDriver driver, String elementName, Keys typeValue) throws MobileExceptionWrapper {
		try {
			if (driver != null && elementName != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				element.sendKeys(typeValue);
				System.out.println(HORIZONTAL_LINE);
				System.out.println("Key " + typeValue.name() + " applied on " + elementName);
			} else {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
			}
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e);
		}
	}

	/**
	 * Type values to an input field based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction:  left, right, above, below, near
	 * @param elementName
	 * @param inputText
	 * @throws MobileExceptionWrapper
	 */
	public static void type(WebDriver driver, String tagName, String direction, String elementName, String inputText)
			throws MobileExceptionWrapper {
		try {
			if (elementName != null) {
				final WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				WebElement elementToDoAction = new MobileUtils().getRelativeElement(driver, tagName, direction,
						element);
				elementToDoAction.sendKeys(inputText);
				System.out.println(HORIZONTAL_LINE);
				System.out.println(DATA + inputText + SUCCESSFULLY_ENTERED_INTO + elementToDoAction);
			} else {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
			}
		} catch (final Exception lException) {
			try {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				WebElement elementToDoAction = new MobileUtils().getRelativeElement(driver, tagName, direction,
						element);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript(ARGUMENTS0_VALUE + inputText + "';", elementToDoAction);
				System.out.println(HORIZONTAL_LINE);
				System.out.println(DATA + inputText + SUCCESSFULLY_ENTERED_INTO + elementToDoAction);
			} catch (Exception ex) {
				throw new MobileExceptionWrapper(ex);
			}
		}
	}

	/**
	 * Clear an input field and enter values to that input field
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-0-2021
	 * @param driver
	 * @param expressionPath
	 * @param typeValue
	 * @throws MobileExceptionWrapper
	 */
	public static void clearAndType(WebDriver driver, String elementName, String typeValue)
			throws MobileExceptionWrapper {
		try {
			if (elementName != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				element.clear();
				element.sendKeys(typeValue);
				System.out.println(HORIZONTAL_LINE);
				Log.event(DATA + typeValue + SUCCESSFULLY_ENTERED_INTO + elementName);
			} else {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
			}
		} catch (Exception e) {
			try {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				element.clear();
				executor.executeScript(ARGUMENTS0_VALUE + typeValue + "';", element);
				System.out.println(HORIZONTAL_LINE);
				Log.event(DATA + typeValue + SUCCESSFULLY_ENTERED_INTO + elementName);

			} catch (Exception ex) {
				throw new MobileExceptionWrapper(ex);
			}
		}
	}
}