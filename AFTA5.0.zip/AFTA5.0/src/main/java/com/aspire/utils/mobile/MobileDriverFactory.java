package com.aspire.utils.mobile;

import java.io.File;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Reporter;

import com.aspire.utils.CommandPrompt;
import com.aspire.utils.IPropertiesReader;
import com.aspire.utils.Log;
import com.aspire.utils.PropertiesReaderUtil;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

/**
 * AppiumDriverFactory class used to get a app driver instance, depends on the
 * user requirement as app we adding the desiredCapabilities initialized here
 */

public class MobileDriverFactory {

	private static Logger logger = LoggerFactory.getLogger(MobileDriverFactory.class);
	private static IPropertiesReader propertiesReader = PropertiesReaderUtil.getInstance();
	private static String projectName;
	private static boolean runLambdaTestFromLocal;
	private static boolean runMobileApp;
	private static String platform;
	private static String version;
	private static String device;
	private static String appPathForCloudExecution;
	private static boolean runRealDevice;
	private static List<String> udidList;
	private static Map<String, Boolean> deviceBuffer;
	private static Map<String, AppiumDriver> driverBuffer;
	private static final int SECONDS = propertiesReader.maxElementWait();
	private static final int TOTAL_TIMES;
	private static CommandPrompt commandPrompt = new CommandPrompt();

	// cloud executions
//	private static String sauceUserName = null;
//	private static String sauceAuthKey = null;
//	private static String bsUserName = null;
//	private static String bsAuthKey = null;
	private static String lambdaUserName = null;
	private static String lambdaAuthKey = null;
	
	private static final String PLATFORM_NAME = "platformName";
	private static final String PLATFORM_VERSION= "platformVersion";
	private static final String DEVICE_NAME = "deviceName"; 
	
	

	static {
		projectName = StringUtils.isNotBlank(propertiesReader.projectName()) ? propertiesReader.projectName() : null;

		runLambdaTestFromLocal = ObjectUtils.defaultIfNull(propertiesReader.runLambdaTestFromLocal(), false);
		runMobileApp = ObjectUtils.defaultIfNull(propertiesReader.runMobileApp(), false);
		platform = StringUtils.isNotBlank(propertiesReader.platformNameMobile()) ? propertiesReader.platformNameMobile()
				: "platform-not-specified";
		version = StringUtils.isNotBlank(propertiesReader.platformVersion()) ? propertiesReader.platformVersion()
				: "version-not-specified";
		device = StringUtils.isNotBlank(propertiesReader.deviceName()) ? propertiesReader.deviceName()
				: "device-not-specified";
		appPathForCloudExecution = StringUtils.isNotBlank(propertiesReader.appPathForCloudExecution())
				? propertiesReader.appPathForCloudExecution()
				: "appPathForCloudExecution-not-specified";
		runRealDevice = ObjectUtils.defaultIfNull(propertiesReader.runRealDevice(), false);
		TOTAL_TIMES = ObjectUtils.defaultIfNull(propertiesReader.DevicePollingCount(), 3);

		lambdaUserName = StringUtils.isNotBlank(propertiesReader.lambdaUserName()) ? propertiesReader.lambdaUserName()
				: null;
		lambdaAuthKey = StringUtils.isNotBlank(propertiesReader.lambdaAuthKey()) ? propertiesReader.lambdaAuthKey()
				: null;

		driverBuffer = new HashMap<String, AppiumDriver>();
		deviceBuffer = new HashMap<String, Boolean>();

		udidList = new ArrayList<String>(ObjectUtils.defaultIfNull(propertiesReader.udidList(), null));

		if (StringUtils.isNotBlank(propertiesReader.udid()) && !udidList.contains(propertiesReader.udid())) {
			udidList.add(propertiesReader.udid());
		}
		if (StringUtils.isNotBlank(propertiesReader.udid2()) && !udidList.contains(propertiesReader.udid2())) {
			udidList.add(propertiesReader.udid2());
		}

		udidList.forEach(udid -> {
			if (StringUtils.isNotBlank(udid)) {
				deviceBuffer.put(udid, true);
				driverBuffer.put(udid, null);
			}
		});
	}

	/**
	 * To get a new instance of app driver using default parameters
	 * 
	 * @return driver
	 */
	public static AppiumDriver get() {
		AppiumDriver driver = null;
		// Get invoking test name
		String callerMethodName = new Exception().getStackTrace()[1].getMethodName();
		Log.event("TestCaseID:: " + callerMethodName);

		if (runMobileApp == true) {
			if (runLambdaTestFromLocal == true) {
				try {
					driver = getLambdaTestAppiumDriver(callerMethodName);
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return driver;
	}

	/**
	 * To get a new instance of app driver using default parameters
	 * 
	 * @author sanojs
	 * @since 05-09-2023
	 * @param platform
	 * @param device
	 * @param version
	 * @param appPath
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public static AppiumDriver get(String platform, String device, String version, String appPath)
			throws NoSuchAlgorithmException {
		AppiumDriver driver = null;
		// Get invoking test name
		String callerMethodName = new Exception().getStackTrace()[1].getMethodName();
		Log.event("TestCaseID:: " + callerMethodName);

		if (runMobileApp == true) {
			// if (runLambdaTestFromLocal == true) {
			try {
				driver = getLambdaTestAppiumDriver(callerMethodName, platform, device, version, appPath);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// }

		}
		return driver;
	}

	/**
	 * To get a new instance of app driver using a particular udid/devicename from
	 * config.properties file (say udid2/devicename2)
	 * 
	 * @return driver
	 */
	public static AppiumDriver getAnotherDevice() {
		if (StringUtils.isNotBlank(propertiesReader.udid2())) {
			return get(propertiesReader.udid2());
		} else {
			throw new RuntimeException("udid2 is not mentioned in config.properties file");
		}
	}

	/**
	 * To get a new instance of app driver using a particular udid
	 * 
	 * @return driver
	 */
	public static AppiumDriver get(String udid) {
		AppiumDriver driver = null;
		try {
			driver = getAppiumDriver(udid);
		} catch (Exception e) {
			logger.error("Could not create a driver session. Trying again...");
			driver = getAppiumDriver(udid);
		} finally {
			// Update start time of the tests once free slot is assigned - Just
			// for reporting purpose
			try {
				Field f = Reporter.getCurrentTestResult().getClass().getDeclaredField("m_startMillis");
				f.setAccessible(true);
				f.setLong(Reporter.getCurrentTestResult(), Calendar.getInstance().getTime().getTime());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return driver;
	}

	/**
	 * To set desired capabilities using configured parameters
	 * 
	 * @param udid - udid to get a particular device/ blank or null to get any
	 *             available device
	 * @return capabilities
	 */
	private static DesiredCapabilities getDesiredCapabilities(String udid) {
		DesiredCapabilities capabilities = new DesiredCapabilities();

		capabilities.setCapability(PLATFORM_NAME, propertiesReader.platform());
		capabilities.setCapability(PLATFORM_VERSION, propertiesReader.version());

		if (StringUtils.isNotBlank(udid)) {
			if (isDeviceAvailable(udid)) {
				capabilities.setCapability("udid", udid);
				capabilities.setCapability(DEVICE_NAME, propertiesReader.deviceName());
			} else {
				throw new RuntimeException(udid + " not available after waiting for " + TOTAL_TIMES + " minutes");
			}
		} else {
			udid = getAvailableDeviceUDID();
			if (StringUtils.isBlank(udid)) {
				throw new RuntimeException("No device available after waiting for " + TOTAL_TIMES + " minutes");
			}
			capabilities.setCapability("udid", udid);
			capabilities.setCapability(DEVICE_NAME, propertiesReader.deviceName());
		}
		logger.info("Device udid : " + udid);

		if (propertiesReader.platform().equalsIgnoreCase("win")) {
			capabilities.setCapability(PLATFORM_VERSION, udid);
		}

		if ("mobileweb".equalsIgnoreCase(propertiesReader.appType())) {
			capabilities.setCapability("browserName", propertiesReader.browser());
			capabilities.setCapability("autoAcceptAlerts", true);
			capabilities.setCapability("webkitResponseTimeout", 100000);
			if (propertiesReader.useNewWDA() != null) {
				capabilities.setCapability("useNewWDA", propertiesReader.useNewWDA());
			}
			capabilities.setCapability("clearSystemFiles", true);

			if (propertiesReader.startIWDP() != null) {
				capabilities.setCapability("startIWDP", propertiesReader.startIWDP());
			}
			if (StringUtils.isNotBlank(propertiesReader.safariInitialUrl())) {
				capabilities.setCapability("safariInitialUrl", propertiesReader.safariInitialUrl());
			}
		} else if ("Win".equalsIgnoreCase(platform)) {
			capabilities.setCapability("app", propertiesReader.WinAppPackage());
		} else if (StringUtils.isNotBlank(propertiesReader.appPathiOS())) {
			capabilities.setCapability("app", propertiesReader.appPathiOS());
		} else {
			String appPath = getAppAbsoultePath();
			capabilities.setCapability("app", appPath);
		}

		if (propertiesReader.version().contains("11") || propertiesReader.version().contains("10")
				|| propertiesReader.version().contains("12")) {
			capabilities.setCapability("automationName", "XCUITest");
			if (StringUtils.isNotBlank(propertiesReader.xcodeOrgId())) {
				capabilities.setCapability("xcodeOrgId", propertiesReader.xcodeOrgId());
			}
			if (StringUtils.isNotBlank(propertiesReader.xcodeSigningId())) {
				capabilities.setCapability("xcodeSigningId", propertiesReader.xcodeSigningId());
			}
			if (StringUtils.isNotBlank(propertiesReader.RealDeviceLogger())) {
				capabilities.setCapability("realDeviceLogger", propertiesReader.RealDeviceLogger());
			}
			if (StringUtils.isNotBlank(propertiesReader.XcodeConfigFile())) {
				capabilities.setCapability("XcodeConfigFile", propertiesReader.XcodeConfigFile());
			}

		}
//		if (propertiesReader.newCommandTimeout() != null)
//			capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, propertiesReader.newCommandTimeout());
		return capabilities;
	}

	/**
	 * Method to get absolute path of app (ipa or app / apk)
	 * 
	 * @return absolute path of app
	 */
	private static String getAppAbsoultePath() {
		File classpathRoot = new File(System.getProperty("user.dir"));
		logger.info("App path should be:" + classpathRoot + "/app");
		File appDir = new File(classpathRoot, "/app");
		String fileName = "";
		File folder = new File("app");
		File[] listOfFiles = folder.listFiles();
		for (File listFile : listOfFiles) {
			String fileExtension = FilenameUtils.getExtension(listFile.getAbsolutePath());
			if (null != platform && platform.equalsIgnoreCase("iOS")
					&& (fileExtension.equals("ipa") || fileExtension.equals("app"))) {
				fileName = listFile.getName();
				break;
			} else if (null != platform && platform.equalsIgnoreCase("Andriod") && fileExtension.equals("apk")) {
				fileName = listFile.getName();
				break;
			}
		}
		if (null != fileName && !fileName.isEmpty()) {
			File app = new File(appDir, fileName);
			String appName = app.getAbsolutePath();
			return appName;
		}
		return null;
	}

	/**
	 * To wait for given time until a random device becomes available
	 * 
	 * @return udid of the device when it is available
	 */
	private static String getAvailableDeviceUDID() {
		String udid = null;
		int maxTry = 0;
		while (udid == null && maxTry++ < TOTAL_TIMES) {
			clearStaleDriverSessions();
			synchronized (deviceBuffer) {
				for (String deviceudid : deviceBuffer.keySet()) {
					if (deviceBuffer.get(deviceudid)) {
						udid = deviceudid;
						deviceBuffer.put(deviceudid, false);
						break;
					}
				}
			}
			if (udid == null) {
				try {
					logger.info(Reporter.getCurrentTestResult().getName()
							+ " says -> No devices available now. Waiting for 1 minute...");
					TimeUnit.SECONDS.sleep(SECONDS);
				} catch (InterruptedException e) {
					logger.error("Unable to get udid: " + e.getMessage());
				}
			}
		}
		return udid;
	}

	/**
	 * To wait for given time until the device with given udid become available
	 * 
	 * @param udid - udid of the device
	 * @return true when the device is available
	 */
	private static boolean isDeviceAvailable(String udid) {
		boolean isFree = false;
		int maxTry = 0;
		while (!isFree && maxTry++ < TOTAL_TIMES) {
			clearStaleDriverSessions();
			synchronized (deviceBuffer) {
				if (deviceBuffer.get(udid)) {
					deviceBuffer.put(udid, false);
					isFree = true;
				}
			}
			if (!isFree) {
				try {
					logger.info(Reporter.getCurrentTestResult().getName() + " says -> " + udid
							+ " is not available now. Waiting for 1 minute...");
					TimeUnit.SECONDS.sleep(SECONDS);
				} catch (InterruptedException e) {
					logger.error("Unable to get udid: " + e.getMessage());
				}
			}
		}
		return isFree;
	}

	/**
	 * To quit the appium driver and update the device buffer and driver buffer
	 * 
	 * @param driver
	 */
	public static void quitDriver(AppiumDriver driver) {
		if (driver != null) {
			String udid = "";
			if (null != driver.getCapabilities().getCapability("udid")) {
				udid = driver.getCapabilities().getCapability("udid").toString();
				synchronized (deviceBuffer) {
					driver.quit();
					deviceBuffer.put(udid, true);
					driverBuffer.put(udid, null);
				}
			} else {
				udid = driver.getCapabilities().getCapability(PLATFORM_VERSION).toString();
				synchronized (deviceBuffer) {
					driver.quit();
					deviceBuffer.put(udid, true);
					driverBuffer.put(udid, null);
				}
			}
			driver.quit();
		} else {
			logger.error("Driver is null");
		}
	}

	/**
	 * To create an Appium Driver session with given capabilities.
	 * 
	 * @param udid - udid to get a particular device/ blank or null to get any
	 *             available device
	 * @return AppiumDriver instance
	 */
	private static AppiumDriver getAppiumDriver(String udid) {
		AppiumDriver driver = null;
		DesiredCapabilities capabilities = new DesiredCapabilities();
		if (System.getProperty("appium.screenshots.dir") != null) {
			try {
				logger.info("Initialize the Appium driver for AWS");
				driver = new IOSDriver(new URL(propertiesReader.host() + ":" + propertiesReader.port() + "/wd/hub"),
						capabilities);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		} else {
			logger.info("Initialize the Appium driver for local");
			try {
				String appiumURL = "http://" + propertiesReader.host() + ":" + propertiesReader.port() + "/wd/hub";
				capabilities = getDesiredCapabilities(udid);
				udid = capabilities.getCapability("udid").toString();

				switch (platform.toLowerCase()) {
				case "android":
					driver = new AndroidDriver(new URL(appiumURL), capabilities);
					break;
				case "ios":
					driver = new IOSDriver(new URL(appiumURL), capabilities);
					break;
				case "win":
					appiumURL = "http://" + udid + ":" + propertiesReader.port();
					driver = new IOSDriver(new URL(appiumURL), capabilities);
					break;
				default:
					logger.error("Unable to load platform property. Platform is set to " + platform);
					break;
				}

				synchronized (deviceBuffer) {
					deviceBuffer.put(udid, false);
					driverBuffer.put(udid, driver);
				}
			} catch (Exception e) {
				synchronized (deviceBuffer) {
					if (capabilities.getCapability("udid") != null
							&& deviceBuffer.containsKey(capabilities.getCapability("udid").toString())) {
						deviceBuffer.put(capabilities.getCapability("udid").toString(), true);
						driverBuffer.put(capabilities.getCapability("udid").toString(), null);
					}
				}
				logger.error(
						"Unable to create driver session with given URL and DesiredCapabilities : " + e.getMessage());
				throw new RuntimeException(
						"Unable to create driver session with given URL and DesiredCapabilities : " + e.getMessage());
			}
		}
		return driver;
	}

	/**
	 * To clear the stale driver sessions and to free the udid of the devices in the
	 * driverBuffer and the deviceBuffer respectively
	 */
	private static void clearStaleDriverSessions() {
		synchronized (deviceBuffer) {
			for (String udid : deviceBuffer.keySet()) {
				try {
					AppiumDriver driver = driverBuffer.get(udid);
					if (driver != null) {
						driver.getSessionId().toString();

					}
				} catch (Exception e) {
					deviceBuffer.put(udid, true);
					driverBuffer.put(udid, null);
				}
			}
		}
	}

	/**
	 * To get the device name and version (Works only when the iOS device is
	 * connected to the same MAC machine where the code gets executed)
	 * 
	 * @param udid - udid of the device
	 */
	public static String getIOSDeviceInfo(String udid) {
		String deviceNameAndVersion = "";
		try {
			String deviceName = commandPrompt.runCommand("/usr/local/bin/idevicename --udid " + udid)
					.replace("\\W", "_").trim();
			String deviceVersion = commandPrompt
					.runNestedCommand("/usr/local/bin/ideviceinfo --udid " + udid + " | grep ProductVersion")
					.split(":")[1].replace("\n", "").trim();
			deviceNameAndVersion = deviceName + "_" + deviceVersion;
		} catch (Exception e) {
			logger.error("Unable to get device details " + e.getMessage());
		}
		return deviceNameAndVersion;
	}

	private static AppiumDriver getLambdaTestAppiumDriver(String callerMethodName, String platform, String device,
			String version, String appPath) throws MalformedURLException, NoSuchAlgorithmException {
		AppiumDriver driver;
		String gridURL = "@mobile-hub.lambdatest.com/wd/hub";

		DesiredCapabilities capabilities = new DesiredCapabilities();
		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put("w3c", true);
		ltOptions.put("project", projectName);
		ltOptions.put("build", projectName);
		ltOptions.put("name", callerMethodName);
		ltOptions.put(PLATFORM_NAME, platform);
		ltOptions.put(DEVICE_NAME, device);
		ltOptions.put(PLATFORM_VERSION, version);
		ltOptions.put("app", appPath);
		ltOptions.put("isRealMobile", runRealDevice);
		capabilities.setCapability("lt:options", ltOptions);

		String hub = "https://" + lambdaUserName + ":" + lambdaAuthKey + gridURL;
		driver = new AppiumDriver(new URL(hub), capabilities);

		String lambdaSessionId = (((RemoteWebDriver) driver).getSessionId()).toString();

		String lambdaLink = "https://automation.lambdatest.com/logs/?sessionID=" + lambdaSessionId;
		System.out.println(lambdaSessionId);

		String authLambda = getMD5(driver, lambdaUserName + ":" + lambdaAuthKey);

		// logger.debug("LambdaTest link for " + callerMethodName + ":: " + lambdaLink);
		Log.addExecutionEnvironmentToReport(driver, platform + "_" + version + "_" + device);
		Log.addLambdaJobUrlToReport(driver, lambdaLink);

		return driver;
	}

	private static AppiumDriver getLambdaTestAppiumDriver(String callerMethodName) throws MalformedURLException {
		AppiumDriver driver;
		String gridURL = "@mobile-hub.lambdatest.com/wd/hub";

		DesiredCapabilities capabilities = new DesiredCapabilities();
		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put("w3c", true);
		ltOptions.put("project", projectName);
		ltOptions.put("build", projectName);
		ltOptions.put("name", callerMethodName);
		ltOptions.put(PLATFORM_NAME, platform);
		ltOptions.put(DEVICE_NAME, device);
		ltOptions.put(PLATFORM_VERSION, version);
		ltOptions.put("app", appPathForCloudExecution);
		ltOptions.put("isRealMobile", runRealDevice);
		capabilities.setCapability("lt:options", ltOptions);

		String hub = "https://" + lambdaUserName + ":" + lambdaAuthKey + gridURL;
		driver = new AppiumDriver(new URL(hub), capabilities);

		String lambdaSessionId = (((RemoteWebDriver) driver).getSessionId()).toString();

		String lambdaLink = "https://automation.lambdatest.com/logs/?sessionID=" + lambdaSessionId;

		// logger.debug("LambdaTest link for " + callerMethodName + ":: " + lambdaLink);
		Log.addExecutionEnvironmentToReport(driver, platform + "_" + version + "_" + device);
		Log.addLambdaJobUrlToReport(driver, lambdaLink);

		return driver;
	}

	public static String getMD5(RemoteWebDriver driver, String userNameAuth) throws NoSuchAlgorithmException {
		MessageDigest m = MessageDigest.getInstance("MD5");
		m.update(userNameAuth.getBytes(), 0, userNameAuth.length());
		String auth = "MD5: " + new BigInteger(1, m.digest()).toString(16);
		return auth;
	}
}
