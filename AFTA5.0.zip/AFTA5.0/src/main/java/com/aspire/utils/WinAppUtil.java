package com.aspire.utils;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.windows.WindowsDriver;

/**
 * 
 * @author christy.shily
 *
 */

public class WinAppUtil {

	public static WindowsDriver driver;
	static String LOCAL_URL = "http://127.0.0.1:4723";

	/**
	 * This method is used to open WinAppDriver using the code itself instead of
	 * manually opening the WinAppDriver before execution.
	 * 
	 * @param driverPath - Path of WinAppAriver.exe (C:\\Program Files
	 *                   (x86)\\Windows Application Driver\\WinAppDriver.exe)
	 * @throws IOException
	 */
	public static void openWinAppDriver(String driverPath) throws IOException {
		try {
			Desktop desktop = Desktop.getDesktop();
			desktop.open(new File(driverPath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method is used to get Desired Capabilities
	 * 
	 * @param Key   -capabilities -It can be of different types: -Application
	 *              identifier or executable full path :"app" -Application launch
	 *              arguments :"appArguments" -Existing application top level window
	 *              to attach to :"appTopLevelWindow" -Application working directory
	 *              (Classic application only) :"appWorkingDir" -Target platform
	 *              name :"platformName" -Target platform version :"platformVersion"
	 *
	 * @param AUMID - Application User Model ID retrieved from Windows PowerShell
	 *              (command: get-StartApps)
	 * @return desiredCapabilities
	 */
	public static DesiredCapabilities getDesiredCapabilities(String Key, String AUMID) {
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability(Key, AUMID);
		return desiredCapabilities;

	}

	/**
	 * This method is used to open the Application and initialize the local host.
	 * This is used to get the session ID .
	 * 
	 * @param desiredCapabilities
	 * @throws MalformedURLException
	 */
	public static void openApplication(DesiredCapabilities desiredCapabilities) throws MalformedURLException {
		try {
			driver = new WindowsDriver(new URL(LOCAL_URL), desiredCapabilities);
			System.out.println(driver.getSessionId());
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * This method is used to find a Window Element
	 * 
	 * @param by - It is used to locate the element by attribute
	 * @return - This method returns an Web Element
	 */
	public static WebElement findElement(By by) {
		return driver.findElement(by);
	}

	/**
	 * This method is used to find multiple Window Element
	 * 
	 * @param by - It is used to locate the element by attribute
	 * @return - This method returns List
	 */
	public static List findElements(By by) {
		return driver.findElements(by);
	}

	/**
	 * This method is used to click on elements
	 * 
	 * @param by -It is used to locate the element by attribute
	 */
	public static void clickOnElement(By by) {
		try {
			findElement(by).click();
		} catch (NoSuchElementException e) {
			findElement(by).sendKeys(Keys.ENTER);
		}
	}

	/**
	 * This method is used to click on element using sendKeys. This method is used
	 * to send keyboard keys.
	 * 
	 * @param by -It is used to locate the element by attribute
	 */
	public static void clickUsingSendKeys(By by) {
		findElement(by).sendKeys(Keys.ENTER);

	}

	/**
	 * This method is used to send/enter text as input
	 * 
	 * @param by   -It is used to locate the element by attribute
	 * @param text - input that has to be entered in the text box
	 */
	public static void sendText(By by, String text) {
		findElement(by).sendKeys(text);

	}

	/**
	 * This method is used to get text
	 * 
	 * @param by -It is used to locate the element by attribute
	 * @return extractedText
	 */
	public static String getText(By by) {
		String extractedText = findElement(by).getText();
		System.out.println(extractedText);
		return extractedText;
	}

	/**
	 * This method is used to split and trim the extracted text to get the required
	 * text
	 * 
	 * @param by
	 * @param extractedText
	 * @param splitby
	 */

	public static void splitandTrim(By by, String extractedText, String splitby) {
		WinAppUtil.getText(by);
		String[] res = extractedText.split(splitby);
		for (int i = 0; i < res.length; i++) {
			res[i].trim();
		}
	}

	/**
	 * This method is used to close the WinAppDriver after the execution is
	 * completed
	 * 
	 * @throws IOException
	 */

	public static void closeWinAppDriver() throws IOException {
		Runtime.getRuntime().exec("taskkill /F /IM WinAppDriver.exe");
	}

}
