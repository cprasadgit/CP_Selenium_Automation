package com.aspire.utils.testdata;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author christy.shily
 * 
 *         Utility class for interacting with Microsoft Access Database.
 *
 */

public class MSAccessUtil implements IDataReader {
	
	private static String SELECT_QUERY = "SELECT * FROM ";
	
	protected static Connection connection;
	private static final String DB_URL = "jdbc:ucanaccess://D://Aspire//AFTA//Fw//AFTA//src//main//resources//testdata//TestDataAccessDB.accdb";

	/**
	 * 
	 * @throws SQLException
	 */
	public static void setUp() throws SQLException {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		connection = DriverManager.getConnection(DB_URL);
	}

	/**
	 * 
	 * @throws SQLException
	 */
	public void tearDown() throws SQLException {
		if (connection != null) {
			connection.close();
		}
	}

	@Override
	public List<Map<String, String>> fetchSheetData(String sheetName) {
		List<Map<String, String>> data = new ArrayList<>();
		Statement statement = null;
		try {

			statement = connection.createStatement();
			String query = SELECT_QUERY + sheetName;

			ResultSet resultSet = statement.executeQuery(query);
			int columnCount = resultSet.getMetaData().getColumnCount();

			while (resultSet.next()) {
				Map<String, String> rowData = new HashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					String columnName = resultSet.getMetaData().getColumnName(i);
					String columnValue = resultSet.getString(i);
					rowData.put(columnName, columnValue);
				}
				data.add(rowData);
			}

			resultSet.close();
			statement.close();

		} catch (Exception e) {

		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return data;

	}

	@Override
	public Map<String, String> getRowValuesByRowNumber(String sheetName, int rowNum) {
		Map<String, String> rowData = new HashMap<>();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			String query = SELECT_QUERY + sheetName + " WHERE ID = " + rowNum; // Assuming ID is the unique
																					// identifier

			ResultSet resultSet = statement.executeQuery(query);

			if (resultSet.next()) {
				int columnCount = resultSet.getMetaData().getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					String columnName = resultSet.getMetaData().getColumnName(i);
					String columnValue = resultSet.getString(i);
					rowData.put(columnName, columnValue);
				}
			}

			resultSet.close();

		} catch (Exception e) {

		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return rowData;
	}

	@Override
	public Map<String, String> getRowValuesByTcId(String sheetName, String tcID) {
		Map<String, String> rowData = new HashMap<>();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			String query = SELECT_QUERY + sheetName + " WHERE TC_ID = '" + tcID + "'"; // Assuming TC_ID is the
																							// column
																							// name

			ResultSet resultSet = statement.executeQuery(query);

			if (resultSet.next()) {
				int columnCount = resultSet.getMetaData().getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					String columnName = resultSet.getMetaData().getColumnName(i);
					String columnValue = resultSet.getString(i);
					rowData.put(columnName, columnValue);
				}
			}

			resultSet.close();

		} catch (Exception e) {

		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return rowData;

	}

	@Override
	public String getCellValueByTcID(String sheetName, String header, String tcID) {

		String query = "SELECT " + header + " FROM " + sheetName + " WHERE TC_ID = '" + tcID + "'"; // Assuming TC_ID is
		String cellValue = null;
		Statement statement = null;
		try { // the column name
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(query);

			if (resultSet.next()) {
				cellValue = resultSet.getString(header);
			}

			resultSet.close();
		} catch (Exception e) {

		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return cellValue;
	}

	@Override
	public String getCellValueByRowNumber(String sheetName, String header, int rowNum) {

		String query = "SELECT " + header + " FROM " + sheetName + " WHERE ID = " + rowNum; // Assuming ID is the unique
		String cellValue = null;
		Statement statement = null;
		try { // identifier
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(query);

			if (resultSet.next()) {
				cellValue = resultSet.getString(header);
			}

			resultSet.close();
		} catch (Exception e) {

		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return cellValue;

	}

	@Override
	public boolean updateSheetWithData(String sheetName, List<Map<String, String>> newData) {
		String updateQuery = "UPDATE " + sheetName + " SET ";
		PreparedStatement preparedStatement = null;
		try {
			for (String columnName : newData.get(0).keySet()) {
				updateQuery += columnName + " = ?, ";
			}
			updateQuery = updateQuery.substring(0, updateQuery.length() - 2); // Remove the last comma and space
			updateQuery += " WHERE ID = ?"; // Assuming ID is the unique identifier

			preparedStatement = connection.prepareStatement(updateQuery);

			for (Map<String, String> row : newData) {
				int i = 1;
				for (String value : row.values()) {
					preparedStatement.setString(i++, value);
				}
				preparedStatement.setInt(i, Integer.parseInt(row.get("ID"))); // Assuming "ID" is the column name for
																				// the
																				// unique identifier
				preparedStatement.addBatch();
			}

			int[] updateCounts = preparedStatement.executeBatch();

			for (int count : updateCounts) {
				if (count <= 0) {
					return false; // Update failed
				}
			}
		} catch (Exception e) {

		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return true; // Update successful

	}

	@Override
	public boolean addValuesWithFormulas(String sheetName, List<List<Object>> data) {
		String insertQuery = "INSERT INTO " + sheetName + " VALUES (";
		PreparedStatement preparedStatement = null;
		try {
			for (int i = 0; i < data.get(0).size(); i++) {
				insertQuery += "?, ";
			}
			insertQuery = insertQuery.substring(0, insertQuery.length() - 2); // Remove the last comma and space
			insertQuery += ")";

			preparedStatement = connection.prepareStatement(insertQuery);

			for (List<Object> row : data) {
				int i = 1;
				for (Object value : row) {
					preparedStatement.setObject(i++, value);
				}
				preparedStatement.addBatch();
			}

			int[] updateCounts = preparedStatement.executeBatch();

			for (int count : updateCounts) {
				if (count <= 0) {
					return false; // Adding values with formulas failed
				}
			}
		} catch (Exception e) {

		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true; // Adding values with formulas successful

	}

	/**
	 * 
	 * @param sheetName
	 * @param rowData
	 * @return
	 * @throws SQLException
	 */
	protected boolean insertData(String sheetName, Map<String, String> rowData) {
		String insertQuery = "INSERT INTO " + sheetName + " (Column1, Column2, ...) VALUES (?, ?)";
		int updatedCount = 0;
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(insertQuery);

			int i = 1;
			for (String value : rowData.values()) {
				preparedStatement.setString(i++, value);
			}

			updatedCount = preparedStatement.executeUpdate();

		} catch (Exception e) {

		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return updatedCount > 0; // Insert successful if count is greater than 0
	}

	/**
	 * 
	 * @param sheetName
	 * @param tcID
	 * @return updatedCount
	 * @throws SQLException
	 */
	protected boolean deleteData(String sheetName, String tcID) {
		String deleteQuery = "DELETE FROM " + sheetName + " WHERE TC_ID = ?";
		int updatedCount = 0;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
			preparedStatement.setString(1, tcID);

			updatedCount = preparedStatement.executeUpdate();

			preparedStatement.close();
		} catch (Exception e) {

		}
		return updatedCount > 0; // Delete successful if count is greater than 0
	}

	/**
	 * 
	 * @param query
	 * @return updatedCount
	 * @throws SQLException
	 */
	protected boolean executeCustomQuery(String query) {

		int updatedCount = 0;
		Statement statement = null;
		try {
			statement = connection.createStatement();
			updatedCount = statement.executeUpdate(query);

		} catch (Exception e) {

		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return updatedCount > 0; // Operation successful if count is greater than 0
	}

	/**
	 * 
	 * @param procedureName
	 * @param params
	 * @throws SQLException
	 */
	protected void executeStoredProcedure(String procedureName, Object... params) throws SQLException {
		CallableStatement callableStatement = null;
		try {
			String callStatement = "{call " + procedureName + "("
					+ String.join(",", Collections.nCopies(params.length, "?")) + ")}";

			callableStatement = connection.prepareCall(callStatement);
			for (int i = 0; i < params.length; i++) {
				callableStatement.setObject(i + 1, params[i]);
			}

			callableStatement.execute();

		} catch (Exception e) {

		} finally {
			callableStatement.close();
		}
	}

	/**
	 * 
	 * @throws SQLException
	 */
	protected void retrieveDatabaseMetadata() {
		try {
			DatabaseMetaData metadata = connection.getMetaData();
			ResultSet tables = metadata.getTables(null, null, "%", null);

			while (tables.next()) {
				String tableName = tables.getString("TABLE_NAME");
				System.out.println("Table Name: " + tableName);

				ResultSet columns = metadata.getColumns(null, null, tableName, null);
				while (columns.next()) {
					String columnName = columns.getString("COLUMN_NAME");
					String dataType = columns.getString("TYPE_NAME");
					System.out.println("Column Name: " + columnName + ", Data Type: " + dataType);
				}
			}
		} catch (Exception e) {

		}
	}
}
