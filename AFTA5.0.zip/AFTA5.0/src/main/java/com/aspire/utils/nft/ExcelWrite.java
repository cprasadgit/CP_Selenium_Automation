package com.aspire.utils.nft;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.formula.FormulaParseException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbookType;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTAutoFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilterColumn;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilters;

import com.aspire.utils.Log;

import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

public class ExcelWrite {
	static XSSFWorkbook workbook;
	static XSSFCellStyle headerCellStyle;
	
	private static final String BROWSER = "browser";
	private static final String LABEL = "label";
	private static final String ENTRY_TYPE = "entryType";
	private static final String XLSX = ".xlsx";
	
	
	
	// static Properties prop = Utils.getProperty();
	// Dashboard column key values should be matching with 'navigation timing'
	// sheet's column header
	static String[] arrDashColumnsKey = new String[] { LABEL, BROWSER, ENTRY_TYPE, "fullyLoaded",
			"TimetoFirstByte", "FirstPaint", "FirstContentfulPaint", "domInteractive", "DOMContentLoadedTime",
			"domComplete", "OnLoadTime", "transferSize", "90percentile", "95percentile" };
	static String[] NavigationTimingHeader = { LABEL, "timestamp", BROWSER, "name", ENTRY_TYPE, "startTime",
			"duration", "initiatorType", "nextHopProtocol", "workerStart", "redirectStart", "redirectEnd", "fetchStart",
			"domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "secureConnectionStart",
			"requestStart", "responseStart", "responseEnd", "transferSize", "encodedBodySize", "decodedBodySize",
			"serverTiming", "workerTiming", "unloadEventStart", "unloadEventEnd", "domInteractive",
			"domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart", "loadEventEnd",
			"type", "redirectCount", "TCP", "FirstPaint", "Processing", "TotalTime", "DOMContentLoadedTime",
			"OnLoadTime", "AppCache", "LoadEvent", "WebpageResponseTime", "Request", "FirstContentfulPaint", "Redirect",
			"TimetoInteractive", "Response", "DNSLookupTime", "TimetoFirstByte" };

	public synchronized static void createWorkBook(String sheetName, String sheetName2, String workBookName,
			String OutputFileLocation) throws IOException, InvalidFormatException, Exception {
		try {

			workbook = new XSSFWorkbook();
			headerCellStyle = workbook.createCellStyle();

			// Create a Sheet
			XSSFSheet sheet1 = workbook.createSheet(sheetName2);
			XSSFRow startRow = sheet1.createRow(3); // need to set variable
			Cell cellUrl = startRow.createCell(1); // need to set variable
			cellUrl.setCellValue("Test Start Time");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(2); // need to set variable
			Date date = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:sss");
			cellUrl.setCellValue(formatter.format(date));
			cellUrl.setCellStyle(borderStyle());
			startRow = sheet1.createRow(4); // need to set variable
			cellUrl = startRow.createCell(1); // need to set variable
			cellUrl.setCellValue("Test End Time");
			cellUrl.setCellStyle(borderStyle());

			startRow = sheet1.createRow(6);
			cellUrl = startRow.createCell(1);
			cellUrl.setCellValue("Request"); // need to set as array
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(2);
			cellUrl.setCellValue("Browser");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(3);
			cellUrl.setCellValue("Type");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(4);
			cellUrl.setCellValue("No of Request");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(5);
			cellUrl.setCellValue("Fully Loaded(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(6);
			cellUrl.setCellValue("TimeTo FirstByte(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(7);
			cellUrl.setCellValue("First Paint(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(8);
			cellUrl.setCellValue("First Contentful Paint(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(9);
			cellUrl.setCellValue("DOM Interactive(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(10);
			cellUrl.setCellValue("DOM Content Loaded(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(11);
			cellUrl.setCellValue("DOM Complete(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(12);
			cellUrl.setCellValue("OnLoad Time(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(13);
			cellUrl.setCellValue("Transfer Size(byte)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(14);
			cellUrl.setCellValue("90 Percentile(ms)");
			cellUrl.setCellStyle(borderStyle());
			cellUrl = startRow.createCell(15);
			cellUrl.setCellValue("95 Percentile(ms)");
			cellUrl.setCellStyle(borderStyle());

			// Create a Sheet
			XSSFSheet sheet = workbook.createSheet(sheetName);
			// if (sheet.getLastRowNum() == 0) {
			// Create a Row
			XSSFRow headerRow = sheet.createRow(0);
			int celladdress = 0;
			// Create cells
			for (String headervalue : NavigationTimingHeader) {
				XSSFCell cell = headerRow.createCell(celladdress++);
				cell.setCellValue(headervalue);
				CellStyle newStyle = workbook.createCellStyle();
				newStyle.cloneStyleFrom(borderStyle());
				cell.setCellStyle(newStyle);
			}
			// }
			// Write the output to a file
			BufferedOutputStream fileOut = new BufferedOutputStream(
					new FileOutputStream(OutputFileLocation + workBookName + XLSX));
			workbook.write(fileOut);
			// Closing the workbook
			workbook.close();
			fileOut.flush();
			fileOut.close();
		} catch (Exception e) {
			throw new Exception("Error while creating workbook : " + e);
		}

	}

	public synchronized static void createWorkBookData(String sheetName, Map<String, Object> data, String workBookName,
			String OutputFileLocation) throws IOException, Exception {
		BufferedInputStream inputStream=null;
		OPCPackage pkg=null;
		XSSFWorkbook workbook=null;
		try {

			// Create a Workbook
			 inputStream = new BufferedInputStream(
					new FileInputStream(OutputFileLocation + workBookName + XLSX));
			ZipSecureFile.setMinInflateRatio(-1.0d);
			// XSSFWorkbook workbook = XSSFWorkbookFactory.createWorkbook(inputStream);

			pkg = OPCPackage.open(inputStream);
			workbook = new XSSFWorkbook(pkg);

			// Get Sheet at index 0
			// Thread.sleep(1000);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			// Get Row count
			// Thread.sleep(1000);
			int rowCount = sheet.getLastRowNum();

			// Get Header Row
			// Thread.sleep(1000);
			XSSFRow headerRow = sheet.getRow(0);
			int colCount = headerRow.getLastCellNum();

			// Create a Row
			XSSFRow valueRow = sheet.createRow(++rowCount);

			for (Map.Entry datavalue : data.entrySet()) {
				for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
					String header = headerRow.getCell(currentColumn).toString();
					if (datavalue.getKey().toString().equalsIgnoreCase(header)) {
						XSSFCell cell = valueRow.createCell(currentColumn);
						if (datavalue.getValue().toString().matches("^-?(\\d+\\.?\\d*)$|(\\d*\\.?\\d+)$"))

						{
							float value1 = Float.parseFloat(datavalue.getValue().toString());
							cell.setCellValue(value1);
						} else {
							cell.setCellValue(datavalue.getValue().toString());
						}
						CellStyle newStyle = workbook.createCellStyle();
						newStyle.cloneStyleFrom(borderStyle());
						cell.setCellStyle(newStyle);

					}

				}
			}

			
			// Write the output to a file
			BufferedOutputStream fileOut = new BufferedOutputStream(
					new FileOutputStream(OutputFileLocation + workBookName + XLSX));
			workbook.write(fileOut);
			// Closing the workbook
		
			fileOut.flush();
			fileOut.close();
		} catch (Exception e) {
			throw new Exception("Error while creating the workbook : " + e);
		}finally {
			inputStream.close();
			pkg.close();
			workbook.close();
		}

	}

	public static void copyFileUsingApacheCommonsIO(String sourceName, String destName, String OutputFileLocation,
			String perfMetricsCal) throws IOException {
		if (perfMetricsCal.equalsIgnoreCase("true")) {
			File source = new File(OutputFileLocation  + sourceName + XLSX);
			File dest = new File(OutputFileLocation  + destName + XLSX);
			if ((source.length() / 1024) != 0) {
				FileUtils.copyFile(source, dest);
			}
		}
	}

	public synchronized static HashSet<String> getUniqueValueFromSheet(String sheetName, String workBookName,
			String columnName, String OutputFileLocation) throws Exception {
		XSSFWorkbook workbook = null;
		BufferedInputStream inputStream = null;
		// Initialize set to store unique value
		HashSet<String> uniqueSet = new HashSet<String>();
		try {
			// Create a Workbook
			inputStream = new BufferedInputStream(new FileInputStream(OutputFileLocation + workBookName + XLSX));
			ZipSecureFile.setMinInflateRatio(-1.0d);
			// XSSFWorkbook workbook = XSSFWorkbookFactory.createWorkbook(inputStream);

			OPCPackage pkg = OPCPackage.open(inputStream);
			workbook = new XSSFWorkbook(pkg);

			// Get Sheet at index 0
			// Thread.sleep(1500);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			// Get Header Row
			// Thread.sleep(1000);
			XSSFRow headerRow = sheet.getRow(0);
			int colCount = headerRow.getLastCellNum();

			// Expected column row count
			int expectedColumnCount = 0;

			for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
				if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase(columnName)) {
					expectedColumnCount = currentColumn;
					break;
				}
			}

			for (Row r : sheet) {
				for (Cell c : r) {
					// big IF condition to check both columns with value
					if ((c.getColumnIndex() == expectedColumnCount)) {
						Row r1 = (XSSFRow) c.getRow();
						if (r1.getRowNum() != 0) { /* Ignore top row */
							uniqueSet.add(c.getStringCellValue());
						}
					}
				}
			}
		} catch (Exception e) {
			Log.exception(e);
		} finally {
			workbook.close();
			inputStream.close();
		}
		return uniqueSet;
	}

	public synchronized static HashSet<String> getUniqueTransactionForEachBrowser(String sheetName, String workBookName,
			String labelcolumnName, String browsercolumnName, String browserName, String OutputFileLocation)
			throws Exception {
		BufferedInputStream inputStream = null;
		XSSFWorkbook workbook = null;
		// Initialize set to store unique value
		HashSet<String> uniqueSet = new HashSet<String>();
		try {
			// Create a Workbook
			inputStream = new BufferedInputStream(new FileInputStream(OutputFileLocation + workBookName + XLSX));
			ZipSecureFile.setMinInflateRatio(-1.0d);
			// XSSFWorkbook workbook = XSSFWorkbookFactory.createWorkbook(inputStream);

			OPCPackage pkg = OPCPackage.open(inputStream);
			workbook = new XSSFWorkbook(pkg);

			// Get Sheet at index 0
			// Thread.sleep(1000);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			// Get Header Row
			// Thread.sleep(1000);
			XSSFRow headerRow = sheet.getRow(0);
			int colCount = headerRow.getLastCellNum();

			// Expected column row count
			int expectedColumnCount = 0;

			for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
				if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase(labelcolumnName)) {
					expectedColumnCount = currentColumn;
					break;
				}
			}
			int browserColumnCount = 0;

			for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
				if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase(browsercolumnName)) {
					browserColumnCount = currentColumn;
					break;
				}
			}

			for (Row r : sheet) {
				boolean flag = false;
				String transname = "";
				for (Cell c : r) {
					// big IF condition to check both columns with value
					if ((c.getColumnIndex() == expectedColumnCount || c.getColumnIndex() == browserColumnCount)) {
						if (c.getColumnIndex() == expectedColumnCount) {
							transname = c.getStringCellValue();
						}
						if (c.getStringCellValue().equalsIgnoreCase(browserName))
							flag = true;
					}
					if (flag)
					{
						uniqueSet.add(transname);
					}

				}
			}
		} catch (Exception e) {
			Log.exception(e);
		} finally {
			inputStream.close();
			workbook.close();
		}
		

		return uniqueSet;
	}

	static CellStyle borderStyle() throws IOException, Exception {
		try {
			CellStyle style = workbook.createCellStyle();
			style.setBorderBottom(BorderStyle.THIN);
			style.setBottomBorderColor(IndexedColors.BLACK.getIndex());

			style.setBorderLeft(BorderStyle.THIN);
			style.setLeftBorderColor(IndexedColors.BLACK.getIndex());

			style.setBorderRight(BorderStyle.THIN);
			style.setRightBorderColor(IndexedColors.BLACK.getIndex());

			style.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());

			return style;
		} catch (Exception e) {
			throw new Exception("Error while performing border style on cell " + e);
		}

	}

	public synchronized static void filterExcelData(String sheetName, String url, String browserName, String sheetName2,
			String workBookName, ArrayList<String> dashboardColumn, String OutputFileLocation) throws Exception {

		XSSFWorkbook workbook = null;
		BufferedInputStream inputStream = null;
		BufferedOutputStream fileOut = null;
		try {
			// Create a Workbook
			inputStream = new BufferedInputStream(new FileInputStream(OutputFileLocation + workBookName + XLSX));
			ZipSecureFile.setMinInflateRatio(-1.0d);
			// XSSFWorkbook workbook = XSSFWorkbookFactory.createWorkbook(inputStream);

			OPCPackage pkg = OPCPackage.open(inputStream);
			workbook = new XSSFWorkbook(pkg);

			// Get Sheet at index 0
			// Thread.sleep(15000);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			// Thread.sleep(15000);
			int rowCount = sheet.getLastRowNum();
			sheet.setAutoFilter(CellRangeAddress.valueOf("A1:AZ" + rowCount));
			System.out.println("Excel - Row count : " + rowCount);

			// Get Header Row
			// Thread.sleep(15000);
			XSSFRow headerRow = sheet.getRow(0);
			int colCount = headerRow.getLastCellNum();
			System.out.println("Excel - Col count : " + colCount);

			/* Step-1: Get the CTAutoFilter Object */
			CTAutoFilter sheetFilter = sheet.getCTWorksheet().getAutoFilter();

			/* Step -2: Add new Filter Column */
			CTFilterColumn myFilterColumn = sheetFilter.insertNewFilterColumn(0);

			/* Step-3: Set Filter Column ID */
			myFilterColumn.setColId(1L);

			CTFilterColumn myFilterColumn2 = sheetFilter.insertNewFilterColumn(1);
			myFilterColumn2.setColId(0L);

			CTFilters firstColumnFilter = myFilterColumn.addNewFilters();
			CTFilter myFilter1 = firstColumnFilter.addNewFilter();

			CTFilters secondColumnFilter = myFilterColumn2.addNewFilters();
			CTFilter myFilter2 = secondColumnFilter.addNewFilter();

			/* Define Filter Conditions Across both columns */

			myFilter1.setVal(url);
			myFilter2.setVal(browserName);

			/* Add Filter Conditions to List */

			List<String> list1 = new ArrayList<String>();
			list1.add(url);

			List<String> list2 = new ArrayList<String>();
			list2.add(browserName);

			// Expected column row count
			int expectedBrowser = 0, expectedUrl = 0, expectedColumnNo = 0;

			for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
				if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase(BROWSER)) {
					expectedBrowser = currentColumn;
					break;
				}
			}
			for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
				if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase(LABEL)) {
					expectedUrl = currentColumn;
					break;
				}
			}
			for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
				if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase(ENTRY_TYPE)) {
					expectedColumnNo = currentColumn;
					break;
				}
			}

			/* Refresh Records to Match Multiple Filter Conditions */
			XSSFRow r1;
			/* Step-6: Loop through Rows and Apply Filter */
			for (Row r : sheet) {
				for (Cell c : r) {
					// big IF condition to check both columns with value
					if ((c.getColumnIndex() == expectedBrowser && !list2.contains(c.getStringCellValue()))
							|| (c.getColumnIndex() == expectedUrl && !list1.contains(c.getStringCellValue()))) {
						r1 = (XSSFRow) c.getRow();
						if (r1.getRowNum() != 0) { /* Ignore top row */
							/* Hide Row that does not meet Filter Criteria */
							r1.getCTRow().setHidden(true);
						}
					}
				}
			}

			// Create sheet
			XSSFSheet sheet1 = workbook.getSheet(sheetName2);
			int newSheetRowCount = sheet1.getLastRowNum();
			XSSFRow endTimeRow = sheet1.getRow(4);
			Cell cellEndTime = endTimeRow.createCell(2);
			Date date = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:sss");
			cellEndTime.setCellValue(formatter.format(date));
			CellStyle newStyle = workbook.createCellStyle();
			newStyle.cloneStyleFrom(borderStyle());
			cellEndTime.setCellStyle(newStyle);
			XSSFRow startRow = sheet1.createRow(newSheetRowCount + 1);
			Cell cellUrl = startRow.createCell(1);
			cellUrl.setCellValue(url);
			cellUrl.setCellStyle(newStyle);
			Cell cellBrowserName = startRow.createCell(2);
			cellBrowserName.setCellValue(browserName);
			cellBrowserName.setCellStyle(newStyle);
			String entryType = null;
			double noOfRun = 0;
			for (Row row : sheet) {
				if (!row.getZeroHeight()) {
					for (Cell cell : row) {
						r1 = (XSSFRow) cell.getRow();
						if (r1.getRowNum() != 0) {
							if (cell.getColumnIndex() == 4) {
								entryType = cell.getStringCellValue();
								noOfRun = noOfRun + 1;
							}
						}
					}
				}
			}
			Cell cellentryType = startRow.createCell(3);
			cellentryType.setCellValue(entryType);
			cellentryType.setCellStyle(newStyle);
			int expectedName = 0;
			HashSet<String> uniqueSet = new HashSet<String>();
			for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
				if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase("timestamp")) {
					expectedName = currentColumn;
					break;
				}
			}

			for (Row row : sheet) {
				if (!row.getZeroHeight()) {
					for (Cell cell : row) {
						r1 = (XSSFRow) cell.getRow();
						if (r1.getRowNum() != 0) {
							if (cell.getColumnIndex() == expectedName) {
								uniqueSet.add(cell.getStringCellValue());
							}
						}
					}
				}
			}

			Cell cellNoOfRun = startRow.createCell(4);
			cellNoOfRun.setCellValue(uniqueSet.size()); // Set count based on time stamp - will be issue when same time
														// stamp appears during parallel run
			// cellNoOfRun.setCellValue(noOfRun); // Set count based on entries - resource
			// will be affected
			cellNoOfRun.setCellStyle(newStyle);
			int nextCellAddress = 0;
			for (int i = 4; i < dashboardColumn.size(); i++) {
				int excpectedColumnNumber = 0;
				double totalValue = 0;
				for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
					if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase(dashboardColumn.get(i))) {
						excpectedColumnNumber = currentColumn;
						break;
					}
				}
				for (Row row : sheet) {
					if (!row.getZeroHeight()) {
						for (Cell cell : row) {
							r1 = (XSSFRow) cell.getRow();
							if (r1.getRowNum() != 0) {
								if (cell.getColumnIndex() == excpectedColumnNumber) {
									if (cell.getCellType() == CellType.STRING) {
										totalValue = totalValue + Double.parseDouble(cell.getStringCellValue());
									} else {
										totalValue = totalValue + cell.getNumericCellValue();
									}
								}

							}
						}
					}
				}
				nextCellAddress = i + 1;
				cellentryType = startRow.createCell(nextCellAddress);
				cellentryType.setCellValue(totalValue / noOfRun);
				cellentryType.setCellStyle(newStyle);

			}

			for (int currentColumn = 0; currentColumn < colCount; currentColumn++) {
				if (headerRow.getCell(currentColumn).toString().equalsIgnoreCase("TotalTime")) {
					expectedColumnNo = currentColumn;
					break;
				}
			}
			String percentileCellAddress = null;
			int firstEntry = 0;
			for (Row row : sheet) {
				if (!row.getZeroHeight()) {
					for (Cell cell : row) {
						r1 = (XSSFRow) cell.getRow();
						if (r1.getRowNum() != 0) {
							if (cell.getColumnIndex() == expectedColumnNo) {
								if (cell.getCellType() == CellType.NUMERIC) {
									if (firstEntry == 0) {
										percentileCellAddress = "\'" + sheetName + "\'!" + cell.getAddress().toString();
										firstEntry = 1;
									} else {
										percentileCellAddress = percentileCellAddress + "," + "\'" + sheetName + "\'!"
												+ cell.getAddress().toString();
									}

								}
							}

						}
					}
				}
			}
			cellentryType = startRow.createCell(nextCellAddress + 1);
			cellentryType.setCellFormula("PERCENTILE((" + percentileCellAddress + "),0.9)");
			cellentryType.setCellStyle(newStyle);
			cellentryType = startRow.createCell(nextCellAddress + 2);
			cellentryType.setCellFormula("PERCENTILE((" + percentileCellAddress + "),0.95)");
			cellentryType.setCellStyle(newStyle);

			for (Row r : sheet) {
				for (Cell c : r) {
					r1 = (XSSFRow) c.getRow();
					r1.getCTRow().setHidden(false);
				}
			}

			// Write the output to a file
			fileOut = new BufferedOutputStream(new FileOutputStream(OutputFileLocation + workBookName + XLSX));
			workbook.write(fileOut);
			// Closing the workbook
		} catch (Exception e) {
			Log.exception(e);
		} finally {
			workbook.close();
			inputStream.close();
			fileOut.flush();
			fileOut.close();
		}
	}

}
