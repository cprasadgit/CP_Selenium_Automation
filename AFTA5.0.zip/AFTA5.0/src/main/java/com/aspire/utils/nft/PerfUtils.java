package com.aspire.utils.nft;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aspire.utils.Log;
import com.aspire.utils.testdata.WorkBookUtils;

public class PerfUtils {
	
	private static String DOMAIN_LOOKUP_END = "domainLookupEnd";
	private static String CONNECT_START = "connectStart";
	private static String CONNECT_END = "connectEnd";
	private static String REQUEST_START = "requestStart";
	private static String DOMAIN_LOOKUP_START = "domainLookupStart";
	private static String FETCH_START = "fetchStart";
	private static String REDIRECT_END = "redirectEnd";
	private static String REDIRECT_START = "redirectStart";
	private static String DURATION = "duration";
	private static String RESPONSE_END = "responseEnd";
	private static String RESPONSE_START = "responseStart";
	private static String START_TIME = "startTime";
	private static String INITIATOR_TYPE = "initiatorType";
	private static String DOM_CONTENT_LOADED_EVENT_END = "domContentLoadedEventEnd";
	private static String DOM_COMPLETE = "domComplete";
	private static String LOAD_EVENT_START = "loadEventStart";
	private static String DOM_INTERACTIVE = "domInteractive";
	private static String LOAD_EVENT_END = "loadEventEnd";
	private static String ENTRY_TYPE = "entryType";
	private static String TIME_TO_FIRST_BYTE = "TimetoFirstByte";
	private static String REQUEST = "Request";
	private static String TIMESTAMP = "timestamp";
	private static String BROWSER = "Browser";
	private static String LABEL = "label";
	private static String FIRST_PAINT = "FirstPaint";
	private static String TOTAL_TIME = "TotalTime";
	private static String APP_CACHE = "AppCache";
	private static String ON_LOAD_TIME = "OnLoadTime";
	private static String REDIRECT = "Redirect";
	private static String FIRST_CONTENTFUL_PAINT = "FirstContentfulPaint";
	private static String RESPONSE = "Response";
	private static String DNS_LOOKUP_TIME = "DNSLookupTime";
	private static String DB_CONNECTION_CLOSE_MSG = "There is no influx DB is connection established earlier to close";
	private static String PERFORMANCE_ENTRIES_BY_RESOURCE_JSON = "return(JSON.stringify(window.performance.getEntriesByType(\"resource\")[";
	private static String DASHBOARD = "Dashboard";
	
	private static String dbUsername = "influxdb";
	private static String dbPassword = "qEEzTHTv3WOc2VPCh7yS";

	private static SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:sss");
	private static String reportFilePath = System.getProperty("user.dir") + File.separatorChar
			+ "src\\main\\resources\\perfmetrics" + File.separatorChar + "PerfReport.xlsx";

	static boolean apiSwitch = true;

	private static String performanceMetricField[] = { CONNECT_END, CONNECT_START, DOMAIN_LOOKUP_END,
			DOMAIN_LOOKUP_START, DURATION, FETCH_START, REDIRECT_END, REDIRECT_START, REQUEST_START,
			RESPONSE_END, RESPONSE_START, START_TIME };

	private static String navigationMetricField[] = { CONNECT_END, CONNECT_START, DOMAIN_LOOKUP_END,
			DOMAIN_LOOKUP_START, DURATION, FETCH_START, INITIATOR_TYPE, "name", REDIRECT_END, REDIRECT_START,
			REQUEST_START, RESPONSE_END, RESPONSE_START, START_TIME, DOM_COMPLETE, DOM_CONTENT_LOADED_EVENT_END,
			"domContentLoadedEventStart", DOM_INTERACTIVE, "domLoading", LOAD_EVENT_END, LOAD_EVENT_START,
			"navigationStart", "redirectCount", "unloadEventEnd", "unl" + "oadEventStart" };

	private static String stringMetricField[] = { "name", ENTRY_TYPE };

	private static List<String> arrExcludeAddition_Start = List.of(CONNECT_START, DOMAIN_LOOKUP_START, FETCH_START,
			REQUEST_START, RESPONSE_START, "secureConnectionStart", START_TIME, REDIRECT_START, TIME_TO_FIRST_BYTE);

	private static List<String> arrExcludeAddition_End = List.of(CONNECT_END, DOMAIN_LOOKUP_END, "requestEnd",
			RESPONSE_END, REDIRECT_END);

	private static List<Object> dashboardColumnHeaders = List.of(REQUEST, BROWSER, "Type", "No of Request",
			"Fully Loaded(ms)", "Time To FirstByte(ms)", "First Paint(ms)", "First Contentful Paint(ms)",
			"DOM Interactive(ms)", "DOM Content Loaded(ms)", "DOM Complete(ms)", "OnLoad Time(ms)", "Transfer Size(ms)",
			"90 Percentile(ms)", "95 Percentile(ms)");

	private static List<String> navaigationTimingColumnHeaders = List.of(LABEL, TIMESTAMP, "browser", "name",
			ENTRY_TYPE, START_TIME, DURATION, INITIATOR_TYPE, "nextHopProtocol", "workerStart", REDIRECT_START,
			REDIRECT_END, FETCH_START, DOMAIN_LOOKUP_START, DOMAIN_LOOKUP_END, CONNECT_START, CONNECT_END,
			"secureConnectionStart", REQUEST_START, RESPONSE_START, RESPONSE_END, "transferSize", "encodedBodySize",
			"decodedBodySize", "serverTiming", "workerTiming", "unloadEventStart", "unloadEventEnd", DOM_INTERACTIVE,
			"domContentLoadedEventStart", DOM_CONTENT_LOADED_EVENT_END, DOM_COMPLETE, LOAD_EVENT_START, LOAD_EVENT_END,
			"type", "redirectCount", "TCP", FIRST_PAINT, "Processing", TOTAL_TIME, "DOMContentLoadedTime",
			ON_LOAD_TIME, APP_CACHE, "LoadEvent", "WebpageResponseTime", REQUEST, FIRST_CONTENTFUL_PAINT, REDIRECT,
			"TimetoInteractive", RESPONSE, DNS_LOOKUP_TIME, TIME_TO_FIRST_BYTE);

	private static Map<String, String> dashboardMappedValue = new LinkedHashMap<>() {
		{
			put(REQUEST, LABEL);
			put(BROWSER, "browser");
			put("Type", ENTRY_TYPE);
			put("Fully Loaded(ms)", TOTAL_TIME);
			put("Time To FirstByte(ms)", TIME_TO_FIRST_BYTE);
			put("First Paint(ms)", FIRST_PAINT);
			put("First Contentful Paint(ms)", FIRST_CONTENTFUL_PAINT);
			put("DOM Interactive(ms)", DOM_INTERACTIVE);
			put("DOM Content Loaded(ms)", DOM_COMPLETE);
			put("OnLoad Time(ms)", ON_LOAD_TIME);
			put("Transfer Size(ms)", "transferSize");
		}
	};

	public static void getDBConnection(boolean isInfluxDBConnectionRequire, String dbUrl, String measurementName,
			String buildNumber) {
		try {
			if (isInfluxDBConnectionRequire) {
				InfluxDB influxDBS = InfluxDBFactory.connect(dbUrl, dbUsername, dbPassword);
				if (influxDBS != null) {
					Log.message("Successfully connected to influxDB database test for entering start time");
				}
				Query dbquery = new Query("show databases", "");
				QueryResult databaseResultSet = influxDBS.query(dbquery);
				List<List<Object>> dbNames = databaseResultSet.getResults().get(0).getSeries().get(0).getValues();

				if (!IntStream.range(0, dbNames.size())
						.anyMatch(itr -> dbNames.get(itr).toString().equalsIgnoreCase("[" + measurementName + "]"))) {
					Log.message("Database does not Exist hence creating Database with name " + measurementName);
					Query createdatabaseQuery = new Query("create database " + measurementName);
					influxDBS.query(createdatabaseQuery);
				} else {
					Log.message("DB already exists!");
				}
				String QueryString = "select testName From \"StartEndTime\" where RunID='" + buildNumber
						+ "' and type='started'";
				Query query = new Query(QueryString, measurementName);
				QueryResult resultSet = influxDBS.query(query);
				List<List<Object>> runIDs = null;
				try {
					runIDs = resultSet.getResults().get(0).getSeries().get(0).getValues();
					Log.message("start time already exist for runID - " + buildNumber);
					Log.message(runIDs.toString());
				} catch (Exception e) {
					Log.message("start time already not exist for runID - " + buildNumber);
				}
				if (runIDs == null) {
					Log.message("Adding start time for runID - " + buildNumber);
					Point points = Point.measurement("StartEndTime")
							.time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
							.tag(Map.of("testName", "Sample", "timeStamp", String.valueOf(System.currentTimeMillis())))
							.fields(Map.of("RunID", buildNumber, "application", "IntranetSelenium", "type", "started"))
							.build();
					Log.message(points.toString());
					BatchPoints batchPointsS = BatchPoints.database(measurementName).build();
					batchPointsS.point(points);
					influxDBS.write(batchPointsS);
				}
				influxDBS.close();
				Log.message("testinitfuctionEND");
			} else {
				Log.message(DB_CONNECTION_CLOSE_MSG);
			}

		} catch (Exception e) {
			Log.fail("Exception that we caught is: " + e);
		}
	}

	/**
	 * @param driver
	 * @param perfMetricsCal
	 * @return
	 */
	public static List<String> getUrlList(WebDriver driver, boolean perfMetricsCal) {
		List<String> urlList = new ArrayList<>();

		if (perfMetricsCal) {
			int length = Integer.parseInt((String) ((JavascriptExecutor) driver)
					.executeScript("return(JSON.stringify(window.performance.getEntriesByType(\"resource\").length))"));
			IntStream.range(0, length).forEach(itr -> urlList.add((String) ((JavascriptExecutor) driver)
					.executeScript("return(performance.getEntriesByType(\"resource\")[" + (itr) + "].name)")));
			return urlList;
		} else {
			return urlList;
		}
	}

	public static JSONObject calculateMeasurement(String dbName, String labelName, boolean isNavigation,
			boolean isNewResource, WebDriver driver, String browser, List<String> urlArrayList, String buildNumber,
			String dbUrl, boolean perfMetricsCal, boolean influxDB) throws Exception {
		JSONObject response = null;
		try {
			if (perfMetricsCal) {
				if (apiSwitch) {
					if (isNavigation) {
						response = navigationPerformance(driver, browser, labelName, buildNumber, influxDB, dbName,
								dbUrl);
					} else {
						List<String> tempArray = getUrlList(driver, perfMetricsCal);
						if (isNewResource) {
							Log.message(labelName
									+ "-- Treating all resources as new ---------New array length : --------->"
									+ tempArray.size());
							Log.message("Old array length : --------->" + urlArrayList.size());
							if (tempArray.size() > 0)
								response = actionPerformance(driver, browser, labelName, buildNumber, influxDB, dbUrl,
										dbName);
							else
								Log.message(labelName
										+ " To this step not calling action performance since new array length is zero");

						} else {
							Log.message(labelName + "-- Treating new resources are in combination with old--------->");
							List<String> newUrl = new ArrayList<String>();

							for (int i = urlArrayList.size(); i < tempArray.size(); i++) {
								newUrl.add(tempArray.get(i));
							}
							Log.message(labelName + "-- Old array length : " + urlArrayList.size()
									+ "-- New array length : " + tempArray.size() + "-- Diff array length : "
									+ newUrl.size());
							if (newUrl.size() > 0)
								response = actionPerformance(driver, browser, labelName, buildNumber, influxDB, dbUrl,
										dbName);
							else
								Log.message(labelName
										+ " To this step not calling action performance since new array length is zero");
						}

					}

				}

			}

		} catch (Exception e) {
			throw new Exception("Error while user calculating Jmeter metrics :" + e);
		}
		return response;
	}

	public static JSONObject navigationPerformance(WebDriver driver, String browser, String labelName,
			String buildNumber, boolean influxDBCon, String dbName, String dbUrl) throws Exception {
		JSONObject navigationEntries = new JSONObject();
		try {

			Capabilities capabilities = ((RemoteWebDriver) driver).getCapabilities();

			Log.message("Current window url is: " + driver.getCurrentUrl());

			if (browser.equalsIgnoreCase("ie")) {
				for (String entries : navigationMetricField) {
					navigationEntries.put(entries, ((JavascriptExecutor) driver).executeScript(
							"return(JSON.stringify(performance.getEntriesByType(\"navigation\")[0]." + entries + "))")
							.toString());
				}
				for (String entries : stringMetricField) {
					navigationEntries.put(entries, ((JavascriptExecutor) driver).executeScript(
							"return(JSON.stringify(performance.getEntriesByType(\"navigation\")[0]." + entries + "))")
							.toString());
				}
			} else {
				navigationEntries = new JSONObject(((JavascriptExecutor) driver)
						.executeScript("return(JSON.stringify(performance.getEntriesByType(\"navigation\")[0]))")
						.toString());
			}
			try {
				if (browser.equalsIgnoreCase("chrome") || browser.equalsIgnoreCase("edge")) {
					navigationEntries.put(FIRST_PAINT, ((JavascriptExecutor) driver).executeScript(
							"return(JSON.stringify(window.performance.getEntriesByType(\"paint\")[0].startTime+window.performance.getEntriesByType(\"paint\")[0].duration))")
							.toString());
					navigationEntries.put(FIRST_CONTENTFUL_PAINT, ((JavascriptExecutor) driver).executeScript(
							"return(JSON.stringify(window.performance.getEntriesByType(\"paint\")[1].startTime+window.performance.getEntriesByType(\"paint\")[1].duration))")
							.toString());
				}
			} catch (Exception e) {
				Log.failsoft("Getting issue while get the firstpaint and firstContentfulPaint fields");
			}

			Log.message("navigationEntries:" + navigationEntries);

			// For Excel
			navigationEntries.put(LABEL, labelName);
			navigationEntries.put(TIMESTAMP, InetAddress.getLocalHost() + "_Thread" + Thread.currentThread().getId()
					+ "_" + formatter.format(new Date()));
			navigationEntries.put("RunID", buildNumber);
			navigationEntries.put("hostName", InetAddress.getLocalHost().toString().split("/")[0]);

			// Changing first letter to capital
			navigationEntries.put("browser", browser.substring(0, 1).toUpperCase() + browser.substring(1));

			JSONObject navigationEntry = navigationMetricsArithmeticCalculation(navigationEntries);

			if (influxDBCon) {
				InfluxDB influxDB = InfluxDBFactory.connect(dbUrl, dbUsername, dbPassword);
				if (influxDB != null) {
					Log.message("Successfully connected to influxDB database test");
				}
				Point point1 = null;

				point1 = Point.measurement("sample").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
						.tag(IntStream.range(0, navigationEntry.names().length()).boxed().filter(
								itr -> (navigationEntry.get(navigationEntry.names().getString(itr)) instanceof Float))
								.collect(Collectors.toMap(itr -> navigationEntry.names().getString(itr),
										itr -> navigationEntry.get(navigationEntry.names().getString(itr)).toString())))
						.fields(IntStream.range(0, navigationEntry.names().length()).boxed().filter(
								itr -> !(navigationEntry.get(navigationEntry.names().getString(itr)) instanceof Float))
								.collect(Collectors.toMap(itr -> navigationEntry.names().getString(itr),
										itr -> navigationEntry.get(navigationEntry.names().getString(itr)).toString())))
						.build();
				Log.message(point1.toString());

				BatchPoints batchPoints = BatchPoints.database(dbName).build();
				batchPoints.point(point1);
				influxDB.write(batchPoints);
				influxDB.close();
			} else {
				Log.message(DB_CONNECTION_CLOSE_MSG);
			}

		} catch (Exception e) {
			Log.message("Error details : " + e.getMessage());
		}
		return navigationEntries;
	}

	// *********************************************************************************
	// Method used to get action/resource related performance metrics and push to
	// influx DB - Use when urls are newly generated
	// *********************************************************************************
	public static JSONObject actionPerformance(WebDriver driver, String browser, String labelName, String buildNumber,
			boolean influxDBCon, String dbUrl, String dbName) throws Exception {

		try {
			Capabilities capabilities = ((RemoteWebDriver) driver).getCapabilities();
			JSONObject actionEntries = new JSONObject();
			int length = Integer.parseInt(((JavascriptExecutor) driver)
					.executeScript("return(JSON.stringify(window.performance.getEntriesByType(\"resource\").length))")
					.toString());
			try {
				for (int i = 0; i <= length - 1; i++) {

					JSONObject actionEntry = new JSONObject();
					if (browser.equalsIgnoreCase("ie")) {
						for (String entries : performanceMetricField) {
							actionEntry.put(entries,
									((JavascriptExecutor) driver).executeScript(
											PERFORMANCE_ENTRIES_BY_RESOURCE_JSON
													+ i + "]." + entries + "))")
											.toString());
						}
						for (String entries : stringMetricField) {
							actionEntry.put(entries,
									((JavascriptExecutor) driver).executeScript(
											PERFORMANCE_ENTRIES_BY_RESOURCE_JSON
													+ i + "]." + entries + "))")
											.toString());
						}
						actionEntry.put(INITIATOR_TYPE,
								((JavascriptExecutor) driver).executeScript(
										PERFORMANCE_ENTRIES_BY_RESOURCE_JSON + i
												+ "].initiatorType))")
										.toString());
					} else {
						actionEntry = new JSONObject(((JavascriptExecutor) driver)
								.executeScript(
										"return(JSON.stringify(performance.getEntriesByType(\"resource\")[" + i + "]))")
								.toString());
					}

					actionEntry.put(LABEL, labelName);

					actionEntry.put(TIMESTAMP, InetAddress.getLocalHost() + "_Thread" + Thread.currentThread().getId()
							+ "_" + formatter.format(new Date()));
					actionEntry.put("browser", browser.substring(0, 1).toUpperCase() + browser.substring(1));
					actionEntry.put("hostName", InetAddress.getLocalHost().toString().split("/")[0]);

					JSONObject calculatedActionEntry = actionMetricsArithmeticCalculation(actionEntry);

					if (!actionEntries.isEmpty()) {
						JSONArray names = calculatedActionEntry.names();

						IntStream.range(0, names.length()).forEach(itr -> {
							if (arrExcludeAddition_Start.contains(names.getString(itr))) {
								// Replace if the new value is less than the old start value, else skip
								if (calculatedActionEntry.getFloat(names.getString(itr)) < actionEntries
										.getFloat(names.getString(itr))) {
									actionEntries.put(names.getString(itr),
											calculatedActionEntry.getFloat(names.getString(itr)));
								} else {
									actionEntries.put(names.getString(itr),
											actionEntries.getFloat(names.getString(itr)));
								}

							} else if (arrExcludeAddition_End.contains(names.getString(itr))) {
								// Replace if the new value is greater than the old end value, else skip
								if (calculatedActionEntry.getFloat(names.getString(itr)) > actionEntries
										.getFloat(names.getString(itr))) {
									actionEntries.put(names.getString(itr),
											calculatedActionEntry.getFloat(names.getString(itr)));
								} else {
									actionEntries.put(names.getString(itr),
											actionEntries.getFloat(names.getString(itr)));
								}
							} else {

								if (calculatedActionEntry.get(names.getString(itr)) instanceof Float) {
									actionEntries.put(names.getString(itr), actionEntries.getFloat(names.getString(itr))
											+ calculatedActionEntry.getFloat(names.getString(itr)));
								} else if (names.getString(itr).equals("name")) {
									actionEntries.put(names.getString(itr),
											actionEntries.getString(names.getString(itr))
													+ calculatedActionEntry.getString(names.getString(itr)));
								}
							}
						});

					} else {
						JSONArray names = calculatedActionEntry.names();

						IntStream.range(0, names.length()).forEach(itr -> actionEntries.put(names.getString(itr),
								calculatedActionEntry.get(names.getString(itr))));
					}

				}

			} catch (Exception e) {
				Log.failsoft("-----------------------------> Array Index out of bounds excpetion-------------------->"
						+ length);
				Log.failsoft("Exception is : " + e.getStackTrace());
			}

			JSONObject calculatedActionEntries = actionMetricsArithmeticCalculation(actionEntries);

			if (influxDBCon) {
				InfluxDB influxDB = InfluxDBFactory.connect(dbUrl, dbUsername, dbPassword);
				if (influxDB != null) {
					Log.message("Successfully connected to influxDB database test");
				}
				Point point1 = null;

				point1 = Point.measurement("sample").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
						.tag(IntStream.range(0, calculatedActionEntries.names().length()).boxed()
								.filter(itr -> (calculatedActionEntries
										.get(calculatedActionEntries.names().getString(itr)) instanceof Float))
								.collect(Collectors.toMap(itr -> calculatedActionEntries.names().getString(itr),
										itr -> calculatedActionEntries
												.get(calculatedActionEntries.names().getString(itr)).toString())))
						.fields(IntStream.range(0, calculatedActionEntries.names().length()).boxed()
								.filter(itr -> !(calculatedActionEntries
										.get(calculatedActionEntries.names().getString(itr)) instanceof Float))
								.collect(Collectors.toMap(itr -> calculatedActionEntries.names().getString(itr),
										itr -> calculatedActionEntries
												.get(calculatedActionEntries.names().getString(itr)).toString())))
						.build();
				Log.message(point1.toString());

				BatchPoints batchPoints = BatchPoints.database(dbName).build();
				batchPoints.point(point1);
				influxDB.write(batchPoints);
				influxDB.close();
			} else {
				Log.message(DB_CONNECTION_CLOSE_MSG);
			}

			return calculatedActionEntries;
		} catch (Exception e) {
			Log.failsoft("Error details : " + e.getMessage());
			return null;
		}
	}

	private static JSONObject navigationMetricsArithmeticCalculation(JSONObject navigationEntries) {

		navigationEntries.put(REDIRECT, (Float.valueOf((String.valueOf(navigationEntries.get(REDIRECT_END))))
				- Float.valueOf((String.valueOf(navigationEntries.get(REDIRECT_START))))));
		navigationEntries.put(APP_CACHE, (Float.valueOf((String.valueOf(navigationEntries.get(DOMAIN_LOOKUP_START))))
				- Float.valueOf((String.valueOf(navigationEntries.get(FETCH_START))))));
		navigationEntries.put(DNS_LOOKUP_TIME,
				(Float.valueOf((String.valueOf(navigationEntries.get(DOMAIN_LOOKUP_END))))
						- Float.valueOf((String.valueOf(navigationEntries.get(DOMAIN_LOOKUP_START))))));
		navigationEntries.put("TCP", (Float.valueOf((String.valueOf(navigationEntries.get(CONNECT_END))))
				- Float.valueOf((String.valueOf(navigationEntries.get(CONNECT_START))))));
		navigationEntries.put(REQUEST, (Float.valueOf((String.valueOf(navigationEntries.get(RESPONSE_START))))
				- Float.valueOf((String.valueOf(navigationEntries.get(REQUEST_START))))));
		navigationEntries.put(RESPONSE, (Float.valueOf((String.valueOf(navigationEntries.get(RESPONSE_END))))
				- Float.valueOf((String.valueOf(navigationEntries.get(RESPONSE_START))))));
		navigationEntries.put("Processing", (Float.valueOf((String.valueOf(navigationEntries.get(DOM_COMPLETE))))
				- Float.valueOf((String.valueOf(navigationEntries.get(DOM_INTERACTIVE))))));
		navigationEntries.put("LoadEvent", (Float.valueOf((String.valueOf(navigationEntries.get(LOAD_EVENT_END))))
				- Float.valueOf((String.valueOf(navigationEntries.get(LOAD_EVENT_START))))));
		navigationEntries.put(TOTAL_TIME, (Float.valueOf((String.valueOf(navigationEntries.get(LOAD_EVENT_END))))
				- Float.valueOf((String.valueOf(navigationEntries.get(REDIRECT_START))))));
		navigationEntries.put(TIME_TO_FIRST_BYTE,
				(Float.valueOf((String.valueOf(navigationEntries.get(RESPONSE_START)))))); // responsestart
		navigationEntries.put("TimetoInteractive",
				(Float.valueOf((String.valueOf(navigationEntries.get(DOM_INTERACTIVE)))))); // dominteractive
		navigationEntries.put("WebpageResponseTime",
				(Float.valueOf((String.valueOf(navigationEntries.get(LOAD_EVENT_START))))
						- Float.valueOf((String.valueOf(navigationEntries.get(REDIRECT_START))))));
		navigationEntries.put("DOMContentLoadedTime",
				(Float.valueOf((String.valueOf(navigationEntries.get(DOM_CONTENT_LOADED_EVENT_END))))
						- Float.valueOf((String.valueOf(navigationEntries.get(REDIRECT_START))))));
		navigationEntries.put(ON_LOAD_TIME, (Float.valueOf((String.valueOf(navigationEntries.get(LOAD_EVENT_START))))
				- Float.valueOf((String.valueOf(navigationEntries.get(REDIRECT_START))))));

		return navigationEntries;
	}

	private static JSONObject actionMetricsArithmeticCalculation(JSONObject actionEntries) {

		actionEntries.put(REDIRECT, (Float.valueOf((String.valueOf(actionEntries.get(REDIRECT_END))))
				- Float.valueOf((String.valueOf(actionEntries.get(REDIRECT_START))))));
		actionEntries.put(APP_CACHE, (Float.valueOf((String.valueOf(actionEntries.get(DOMAIN_LOOKUP_START))))
				- Float.valueOf((String.valueOf(actionEntries.get(FETCH_START))))));
		actionEntries.put(DNS_LOOKUP_TIME, (Float.valueOf((String.valueOf(actionEntries.get(DOMAIN_LOOKUP_END))))
				- Float.valueOf((String.valueOf(actionEntries.get(DOMAIN_LOOKUP_START))))));
		actionEntries.put("TCP", (Float.valueOf((String.valueOf(actionEntries.get(CONNECT_END))))
				- Float.valueOf((String.valueOf(actionEntries.get(CONNECT_START))))));
		actionEntries.put(REQUEST, (Float.valueOf((String.valueOf(actionEntries.get(RESPONSE_START))))
				- Float.valueOf((String.valueOf(actionEntries.get(REQUEST_START))))));
		actionEntries.put(RESPONSE, (Float.valueOf((String.valueOf(actionEntries.get(RESPONSE_END))))
				- Float.valueOf((String.valueOf(actionEntries.get(RESPONSE_START))))));
		actionEntries.put(TOTAL_TIME, (Float.valueOf((String.valueOf(actionEntries.get(RESPONSE_END))))
				- Float.valueOf((String.valueOf(actionEntries.get(START_TIME))))));
		actionEntries.put(TIME_TO_FIRST_BYTE, (Float.valueOf((String.valueOf(actionEntries.get(RESPONSE_START))))
				- Float.valueOf((String.valueOf(actionEntries.get(REQUEST_START))))));

		return actionEntries;
	}

	public static void createPerfResultSheet(List<JSONObject> responses, Date testStartTime, Date testEndTime)
			throws IOException {

		WorkBookUtils workBook = WorkBookUtils.getWorkBook(new File(reportFilePath));

		generateDashboardSheet(workBook, responses, testStartTime, testEndTime);
		generateNavigationTimingSheet(workBook, responses);
	}

	public static void generateDashboardSheet(WorkBookUtils workBook, List<JSONObject> responses, Date testStartTime,
			Date testEndTime) {
		// Dashboard Sheet
		workBook.addRowValuesToSheet(DASHBOARD, dashboardColumnHeaders, 6, 1);

		// Test start time
		workBook.addRowValuesToSheet(DASHBOARD, List.of("Test Start Time", formatter.format(testStartTime)), 3, 1);

		// Test end time
		workBook.addRowValuesToSheet(DASHBOARD, List.of("Test End Time", formatter.format(testEndTime)), 4, 1);

		responses.forEach(response -> {
			List<Object> dashboard = new ArrayList<>();
			Map<String, Object> map = response.toMap();
			dashboardColumnHeaders.forEach(header -> {
				if (Objects.nonNull(map.get(dashboardMappedValue.get(header.toString()))))
					dashboard.add(map.get(dashboardMappedValue.get(header.toString())).toString());
				else if (header.equals("No of Request"))
					dashboard.add(1);
				else if (header.equals("90 Percentile(ms)") || header.equals("95 Percentile(ms)"))
					dashboard.add(map.get(TOTAL_TIME).toString());
				else
					dashboard.add(0);
			});
			workBook.addRowValuesToSheet(DASHBOARD, dashboard, 7 + responses.indexOf(response), 1);
		});

		workBook.writeToFile();
	}

	public static void generateNavigationTimingSheet(WorkBookUtils workBook, List<JSONObject> responses) {
		// Navigation Timing Sheet
		List<Map<String, String>> perfResults = new ArrayList<>();
		responses.forEach(response -> {
			Map<String, String> perfResult = new LinkedHashMap<>();
			Map<String, Object> map = response.toMap();
			navaigationTimingColumnHeaders.forEach(header -> {
				if (Objects.nonNull(map.get(header)))
					perfResult.put(header, map.get(header).toString());
			});
			perfResults.add(perfResult);
		});
		workBook.updateSheetWithData("Navigation Timing", perfResults);
		workBook.addBorders("Navigation Timing");

	}

}
