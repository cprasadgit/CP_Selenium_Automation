package com.aspire.utils.nft;

import static java.lang.String.format;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.zaproxy.clientapi.core.Alert;
import org.zaproxy.clientapi.core.ApiResponse;
import org.zaproxy.clientapi.core.ApiResponseElement;
import org.zaproxy.clientapi.core.ApiResponseList;
import org.zaproxy.clientapi.core.ClientApi;
import org.zaproxy.clientapi.core.ClientApiException;

import com.aspire.pojo.SecurityTestResult;
import com.aspire.utils.IPropertiesReader;
import com.aspire.utils.PropertiesReaderUtil;
import com.google.common.base.Preconditions;

public class SecurityUtil {
	
	private static String REMOTE_ALLOW_ORIGINS = "--remote-allow-origins=*";

	private static IPropertiesReader propertiesReader = PropertiesReaderUtil.getInstance();
	private static String securityTestReportPath = "\\test-output\\zapReports\\";
	String reportdir = System.getProperty("user.dir") + securityTestReportPath;
	ClientApi clientApi;
	private static List<SecurityTestResult> results = new ArrayList<>();

	public enum DriverType {
		CHROME, EDGE, FIREFOX
	}

	public ClientApi getClientApi() {
		createReportFolder();
		if (clientApi == null)
			clientApi = new ClientApi(propertiesReader.ZAP_PROXY_ADDRESS(), propertiesReader.ZAP_PROXY_PORT(),
					propertiesReader.ZAP_API_KEY());

		return clientApi;
	}

	private void createReportFolder() {
		File file = new File(reportdir);
		if (!file.exists())
			file.mkdirs();
	}

	public static WebDriver setupWebDriver(DriverType driverType, boolean launchAsHeadless) {
		WebDriver driver;
		String proxyServerUrl = propertiesReader.ZAP_PROXY_ADDRESS() + ":" + propertiesReader.ZAP_PROXY_PORT();
		Proxy proxy = new Proxy();
		proxy.setHttpProxy(proxyServerUrl);
		proxy.setSslProxy(proxyServerUrl);

		switch (driverType) {
		case CHROME:
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments(REMOTE_ALLOW_ORIGINS);
			if (launchAsHeadless)
				chromeOptions.addArguments("--headless=new");
			chromeOptions.setAcceptInsecureCerts(true);
			chromeOptions.setProxy(proxy);
			driver = new ChromeDriver(chromeOptions);
			break;
		case EDGE:
			EdgeOptions edgeOptions = new EdgeOptions();
			edgeOptions.addArguments(REMOTE_ALLOW_ORIGINS);
			if (launchAsHeadless)
				edgeOptions.addArguments("--headless=new");
			edgeOptions.setAcceptInsecureCerts(true);
			edgeOptions.setProxy(proxy);
			driver = new EdgeDriver(edgeOptions);
			break;
		case FIREFOX:
			FirefoxOptions firefoxOptions = new FirefoxOptions();
			firefoxOptions.addArguments(REMOTE_ALLOW_ORIGINS);
			firefoxOptions.setAcceptInsecureCerts(true);
			firefoxOptions.setProxy(proxy);
			driver = new FirefoxDriver(firefoxOptions);
			break;
		default:
			throw new IllegalArgumentException("Unsupported driver type: " + driverType);
		}

		return driver;
	}

	public WebDriver setup() {
		WebDriver driver;

		String proxyServerUrl = propertiesReader.ZAP_PROXY_ADDRESS() + ":" + propertiesReader.ZAP_PROXY_PORT();

		Proxy proxy = new Proxy();
		proxy.setHttpProxy(proxyServerUrl); // Specify which proxy to use for HTTP connections.
		proxy.setSslProxy(proxyServerUrl); // Specify which proxy to use for SSL connections(Secured connection).

		ChromeOptions options = new ChromeOptions();
		options.setAcceptInsecureCerts(true); // To accept the certificate ("your connection is not secure")
		options.setProxy(proxy);

		driver = new ChromeDriver(options);

		clientApi = new ClientApi(propertiesReader.ZAP_PROXY_ADDRESS(), propertiesReader.ZAP_PROXY_PORT(),
				propertiesReader.ZAP_API_KEY());

		return driver;

	}

	public void spiderTarget(String targetURL) throws InterruptedException, ClientApiException {
		getClientApi();
		String application_base_url = "https://<application_url>/"; // Example code to start and synchronize the spider
																	// scan.private static void startSpiderScan()
		System.out.println("Spider : {}" + application_base_url);

		// Start spider scan
		ApiResponse apiResponse = clientApi.spider.scan(targetURL, null, null, null, null);
		int progress;

		// Scan response returns scan id to support concurrent scanning.
		String scanId = ((ApiResponseElement) apiResponse).getValue();
		// Poll the status till over.
		do {
			Thread.sleep(5000);
			progress = Integer.parseInt(((ApiResponseElement) clientApi.spider.status(scanId)).getValue());
			System.out.println("Scan progress: {}{}" + progress + "%");
		} while (progress < 100);
		System.out.println("scan complete");
		// Process the spider results if needed
		List<ApiResponse> spiderResults = ((ApiResponseList) clientApi.spider.results(scanId)).getItems();
		System.out.println("spider results {}" + spiderResults);
	}

	public void waitForPassiveScanToComplete() throws ClientApiException {
		getClientApi();
		System.out.println("--- Waiting for passive scan to finish --- ");
		try {
			clientApi.pscan.enableAllScanners(); // enables all passive scanner.

			ApiResponse response = clientApi.pscan.recordsToScan();

			// iterating till pending scan count is 0
			while (!response.toString().equals("0")) {
				response = clientApi.pscan.recordsToScan();
			}
		} catch (ClientApiException e) {
			throw new ClientApiException("Was zap proxy started?", e);
		}
		System.out.println("--- Passive scan finished! ---");
	}

	public void activeScan(String targetURL) throws InterruptedException, ClientApiException {
		getClientApi();
		System.out.println("Active scan: {}" + targetURL);

		// Start active scan
		ApiResponse resp = clientApi.ascan.scan(targetURL, "True", "False", null, null, null);
		int progress;

		// Scan response returns scan id to support concurrent scanning.
		String scanId = ((ApiResponseElement) resp).getValue();

		// Poll the status till over.
		do {
			Thread.sleep(5000);
			progress = Integer.parseInt(((ApiResponseElement) clientApi.ascan.status(scanId)).getValue());
			System.out.println("Scan progress: {}{}" + progress + "%");
		} while (progress < 100);
		System.out.println("Active scan complete");
	}

	public void checkRiskCount(String filterURL) throws ClientApiException {
		System.out.println("Target URL {}" + filterURL);

		int riskCountHigh = 0;
		int riskCountMedium = 0;
		int riskCountLow = 0;
		int riskCountInformational = 0;
		int totalRiskCount;

		List<Alert> alertList = clientApi.getAlerts(filterURL, 0, 9999999);

		System.out.println(alertList.toString());
		for (Alert alert : alertList) {
			String riskName = alert.getRisk().name();
			Alert.Risk risk = alert.getRisk();
			switch (risk) {
			case High:
				riskCountHigh = riskCountHigh + 1;
				break;
			case Medium:
				riskCountMedium = riskCountMedium + 1;
				break;
			case Low:
				riskCountLow = riskCountLow + 1;
				break;
			case Informational:
				riskCountInformational = riskCountInformational + 1;
				break;
			default:
				throw new IllegalStateException(format("Unknown risk level %s", riskName));
			}
		}
		totalRiskCount = riskCountHigh + riskCountMedium + riskCountLow + riskCountInformational;
		System.out.println("Total risk count: {}" + totalRiskCount);
		Preconditions.checkState(totalRiskCount == 0,
				format("Page %s" + "\nHigh Risk count: %s" + "\nMedium Risk count: %s" + "\nLow Risk count: %s"
						+ "\nInformational Risk count: %s" + "\nplease check: %s", filterURL, riskCountHigh,
						riskCountMedium, riskCountLow, riskCountInformational, securityTestReportPath));
	}

	public void reportGeneration(String pageName) {
		/*
		 * If api is null then we can successfully generate the report
		 */
		if (clientApi != null) {

			try {
				ApiResponse response = clientApi.reports.generate(propertiesReader.title(), propertiesReader.template(),
						null, propertiesReader.description(), null, null, null, null, null,
						propertiesReader.reportfilename() + pageName + ".html", null, reportdir, null); // Returns an
																										// API
																										// Response

				System.out.println("ZAP REPORT GENERATED AT THIS LOCATION:" + response.toString());
			} catch (ClientApiException e) {

				e.printStackTrace();
			}
		}
	}

	public void checkRiskCount(String pageName, String filterURL) throws ClientApiException {

		int riskCountHigh = 0;
		int riskCountMedium = 0;
		int riskCountLow = 0;
		int riskCountInformational = 0;

		List<Alert> alertList = clientApi.getAlerts(filterURL, 0, 9999999);
		System.out.println(alertList.toString());
		for (Alert alert : alertList) {
			String riskName = alert.getRisk().name();
			Alert.Risk risk = alert.getRisk();
			switch (risk) {
			case High:
				riskCountHigh = riskCountHigh + 1;
				break;
			case Medium:
				riskCountMedium = riskCountMedium + 1;
				break;
			case Low:
				riskCountLow = riskCountLow + 1;
				break;
			case Informational:
				riskCountInformational = riskCountInformational + 1;
				break;
			default:
				throw new IllegalStateException(format("Unknown risk level %s", riskName));
			}
		}

		SecurityTestResult securityTestResult = new SecurityTestResult(pageName, riskCountHigh, riskCountMedium,
				riskCountLow, riskCountInformational, System.getProperty("user.dir") + securityTestReportPath
						+ propertiesReader.reportfilename() + pageName + ".html");

		results.add(securityTestResult);
	}

	/**
	 * Retrieves the list of security test results.
	 *
	 * @return A list of security test results. This list may be empty if no results
	 *         are available.
	 */
	public static List<SecurityTestResult> getResult() {
		return results;
	}

}
