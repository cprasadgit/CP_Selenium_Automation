package com.aspire.utils.web;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.Platform;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.safari.SafariOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.xml.XmlTest;

import com.aspire.utils.IPropertiesReader;
import com.aspire.utils.Log;
import com.aspire.utils.MobileEmulationUserAgentConfiguration;
import com.aspire.utils.PropertiesReaderUtil;
import com.aspire.utils.StopWatch;
import com.aspire.utils.mobile.MobileDriverFactory;

/**
 * WebdriverFactory class used to get a web driver instance, depends on the user
 * requirement as driverHost, driverPort and browserName we adding the
 * desiredCapabilities and other static action initialized here and some methods
 * used to retrieve the Hub and node information. It also consists page wait
 * load for images/frames/document
 */

public class WebDriverFactory {

	private static final String BROWSER_NAME = "browserName";
	private static final String PLATFORM_NAME = "platformName";
	private static final String HUB_HOST = "hubHost";
	private static final String DEVICE_HOST = "deviceHost";
	private static final String DEVICE_PORT = "devicePort";
	private static final String DISABLE_WEB_SECURITY = "--disable-web-security";
	private static final String HTTP = "http://";
	private static final String MOBILE_EMULATION = "mobileEmulation";
	private static final String RUN_SAUCE_PERFORMANCE = "runSaucePerformance";
	private static final String SELENIUM_DRIVER = "SELENIUM_DRIVER";
	private static final String CHROME = "chrome";
	private static final String RUN_SAUCELAB_FROM_LOCAL = "runSauceLabFromLocal";
	private static final String RUN_AWS = "runAWS";
	private static final String CONFIG_NOT_IMPLEMENTED_TXT = "Given user agent configuration not yet implemented (or) check the parameters(deviceName) value in config.properties: ";
	private static final String HEADLESS_NEW = "--headless=new";
	private static final String IEXPLORER = "iexplorer";
	private static final String FIREFOX = "firefox";
	private static final String EDGE = "edge";
	private static final String SAFARI = "safari";
	private static final String TUNNELL_IDENTIFIER = "tunnelIdentifier";
	private static final String BROWSER_VERSION = "browserVersion";
	private static final String PLATFORM = "platform";
	private static final String SAUCE_OPTIONS = "sauce:options";
	private static final String OS_VERSION = "os_version";
	private static final String PROJECT = "project";
	private static final String BUILD = "build";
	private static final String TUNNEL = "tunnel";
	private static final String LT_OPTIONS = "LT:Options";

	private static Logger logger = LoggerFactory.getLogger(WebDriverFactory.class);
	private static IPropertiesReader propertiesReader = PropertiesReaderUtil.getInstance();
	private static MobileEmulationUserAgentConfiguration mobEmuUA = new MobileEmulationUserAgentConfiguration();

	static String browser = System.getProperty(BROWSER_NAME) != null ? System.getProperty(BROWSER_NAME)
			: propertiesReader.browserName().toLowerCase().trim();
	static String platform = System.getProperty(PLATFORM_NAME) != null ? System.getProperty(PLATFORM_NAME)
			: propertiesReader.platform().toLowerCase().trim();

	static String driverHost;
	static String driverPort;
	static String browserName;
	static String deviceName;
	static URL hubURL;
	static Proxy zapProxy = new Proxy();

	static DesiredCapabilities ieCapabilities1 = new DesiredCapabilities();
	static DesiredCapabilities firefoxCapabilities1 = new DesiredCapabilities();
	static DesiredCapabilities chromeCapabilities1 = new DesiredCapabilities();
	static DesiredCapabilities safariCapabilities1 = new DesiredCapabilities();
	static DesiredCapabilities edgeCapabilities1 = new DesiredCapabilities();
	static ChromeOptions opt = new ChromeOptions();
	public static ExpectedCondition<Boolean> documentLoad;
	public static ExpectedCondition<Boolean> framesLoad;
	public static ExpectedCondition<Boolean> imagesLoad;
	public static int maxPageLoadWait = propertiesReader.maxPageLoadWait() != null ? propertiesReader.maxPageLoadWait()
			: 90;
	public static int maxWindowWait = 90;

	static {
		try {
			documentLoad = new ExpectedCondition<Boolean>() {
				public final Boolean apply(final WebDriver driver) {
					final JavascriptExecutor js = (JavascriptExecutor) driver;
					boolean docReadyState = false;
					try {
						docReadyState = (Boolean) js.executeScript(
								"return (function() { if (document.readyState != 'complete') {  return false; } if (window.jQuery != null && window.jQuery != undefined && window.jQuery.active) { return false;} if (window.jQuery != null && window.jQuery != undefined && window.jQuery.ajax != null && window.jQuery.ajax != undefined && window.jQuery.ajax.active) {return false;}  if (window.angular != null && angular.element(document).injector() != null && angular.element(document).injector().get('$http').pendingRequests.length) return false; return true;})();");
					} catch (WebDriverException e) {
						docReadyState = true;
					}
					return docReadyState;

				}
			};

			imagesLoad = new ExpectedCondition<Boolean>() {
				public final Boolean apply(final WebDriver driver) {
					boolean docReadyState = true;
					try {
						JavascriptExecutor js;
						List<WebElement> images = driver.findElements(By.cssSelector("img[src]"));
						for (int i = 0; i < images.size(); i++) {
							try {
								js = (JavascriptExecutor) driver;
								docReadyState = docReadyState && (Boolean) js.executeScript(
										"return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0",
										images.get(i));
								if (!docReadyState) {
									break;
								}
							} catch (StaleElementReferenceException e) {
								images = driver.findElements(By.cssSelector("img[src]"));
								i--;
								continue;
							} catch (WebDriverException e) {

								// setting the true value if any exception arise
								// Ex:: inside frame or switching to new windows
								// or
								// switching to new frames
								docReadyState = true;
							}
						}
					} catch (WebDriverException e) {
						docReadyState = true;
					}
					return docReadyState;
				}
			};

			framesLoad = new ExpectedCondition<Boolean>() {
				public final Boolean apply(final WebDriver driver) {
					boolean docReadyState = true;
					try {
						JavascriptExecutor js;
						List<WebElement> frames = driver.findElements(By.cssSelector("iframe[style*='hidden']"));
						for (WebElement frame : frames) {
							try {
								driver.switchTo().defaultContent();
								driver.switchTo().frame(frame);
								js = (JavascriptExecutor) driver;
								docReadyState = docReadyState
										&& (Boolean) js.executeScript("return (document.readyState==\"complete\")");
								driver.switchTo().defaultContent();
								if (!docReadyState) {
									break;
								}
							} catch (WebDriverException e) {
								docReadyState = true;
							}
						}
					} catch (WebDriverException e) {
						docReadyState = true;
					} finally {
						driver.switchTo().defaultContent();
					}
					return docReadyState;
				}
			};

			XmlTest test = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest();
			driverHost = System.getProperty(HUB_HOST) != null ? System.getProperty(HUB_HOST)
					: test.getParameter(DEVICE_HOST);
			driverPort = System.getProperty("hubPort") != null ? System.getProperty("hubPort")
					: test.getParameter(DEVICE_PORT);

			opt.addArguments("--ignore-certificate-errors");
			opt.addArguments("--disable-bundled-ppapi-flash");
			opt.addArguments("--disable-extensions");
			opt.addArguments(DISABLE_WEB_SECURITY);
			opt.addArguments("--always-authorize-plugins");
			opt.addArguments("--allow-running-insecure-content");
			opt.addArguments("--test-type");
			opt.addArguments("--enable-npapi");
			// chromeCapabilities1.setCapability(CapabilityType.TAKES_SCREENSHOT, true);

			try {
				hubURL = new URL(HTTP + driverHost + ":" + driverPort + "/wd/hub");
			} catch (MalformedURLException e) {
				// e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Method to get instance of web driver using default parameters
	 * 
	 * @return browserName - Browser name
	 * @throws MalformedURLException
	 */
	public static WebDriver get() throws MalformedURLException {

		// First priority for System Variable
		// Second priority for XML
		// Last priority for Config.properties

		System.out.println(propertiesReader.browserName());
		browserName = (System.getProperty(BROWSER_NAME) != null ? System.getProperty(BROWSER_NAME)
				: !propertiesReader.browserName().toLowerCase().trim().isEmpty()
						? propertiesReader.browserName().toLowerCase().trim()
						: browser + "_" + platform)
				.toLowerCase();

		if (propertiesReader.runMobileWeb() == true)
			return MobileDriverFactory.get();
		else
			return getDriver(browserName, null);
	}

	/**
	 * Method to get instance of web driver using browser details
	 * 
	 * @return driver - WebDriver
	 * @throws MalformedURLException
	 */
	public static WebDriver get(String browserSetup) throws MalformedURLException {
		return getDriver(browserSetup, null);
	}

	/**
	 * To generates an md5 HMAC digest based on the provided key and message.
	 * 
	 * @param keyString - Secret key
	 * @param msg       - The message to be authenticated
	 * @return sEncodedString - the digest
	 */
	public static String newHMACMD5Digest(String keyString, String msg) {
		String sEncodedString = null;
		try {
			SecretKeySpec key = new SecretKeySpec((keyString).getBytes("UTF-8"), "HmacMD5");
			Mac mac = Mac.getInstance("HmacMD5");
			mac.init(key);

			byte[] bytes = mac.doFinal(msg.getBytes("ASCII"));

			StringBuffer hash = new StringBuffer();

			for (int i = 0; i < bytes.length; i++) {
				String hex = Integer.toHexString(0xFF & bytes[i]);
				if (hex.length() == 1) {
					hash.append('0');
				}
				hash.append(hex);
			}
			sEncodedString = hash.toString();
		} catch (UnsupportedEncodingException e) {
		} catch (InvalidKeyException e) {
		} catch (NoSuchAlgorithmException e) {
		}
		return sEncodedString;
	}

	/**
	 * Get the test session Node IP address,port when executing through Grid
	 * 
	 * @param driver : WebDriver
	 * @return nodeIP - Session ID
	 * @throws Exception
	 */
	public static final String getTestSessionNodeIP(final WebDriver driver) throws Exception {
		XmlTest test = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest();
		driverHost = System.getProperty(HUB_HOST) != null ? System.getProperty(HUB_HOST)
				: test.getParameter(DEVICE_HOST);
		driverPort = test.getParameter(DEVICE_PORT);
		HttpHost host = new HttpHost(driverHost, Integer.parseInt(driverPort));
		HttpClient client = HttpClientBuilder.create().build();
		URL testSessionApi = new URL(HTTP + driverHost + ":" + driverPort + "/grid/api/testsession?session="
				+ ((RemoteWebDriver) driver).getSessionId());
		BasicHttpEntityEnclosingRequest r = new BasicHttpEntityEnclosingRequest("POST",
				testSessionApi.toExternalForm());
		HttpResponse response = client.execute(host, r);
		JSONObject object = new JSONObject(EntityUtils.toString(response.getEntity()));
		String nodeIP = object.getString("proxyId").toLowerCase();
		nodeIP = nodeIP.replace(HTTP, "");
		nodeIP = nodeIP.replaceAll(":[0-9]{1,5}", "").trim();
		return nodeIP;
	}

	/**
	 * Get the test session Hub IP address, port when executing through Grid
	 * 
	 * @param driver - WebDriver
	 * @return nodeIP - Session ID
	 * @throws Exception
	 */
	public static final String getHubSession(final WebDriver driver) throws Exception {
		XmlTest test = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest();
		driverHost = System.getProperty(HUB_HOST) != null ? System.getProperty(HUB_HOST)
				: test.getParameter(DEVICE_HOST);
		driverPort = test.getParameter(DEVICE_PORT);
		HttpHost host = new HttpHost(driverHost, Integer.parseInt(driverPort));
		HttpClient client = HttpClientBuilder.create().build();
		URL testSessionApi = new URL(HTTP + driverHost + ":" + driverPort + "/grid/api/testsession?session="
				+ ((RemoteWebDriver) driver).getSessionId());
		BasicHttpEntityEnclosingRequest r = new BasicHttpEntityEnclosingRequest("POST",
				testSessionApi.toExternalForm());
		HttpResponse response = client.execute(host, r);
		JSONObject object = new JSONObject(EntityUtils.toString(response.getEntity()));
		String nodeIP = object.getString("proxyId").toLowerCase();
		nodeIP = nodeIP.replace(HTTP, "");
		nodeIP = nodeIP.replaceAll(":[0-9]{1,5}", "").trim();
		return nodeIP;
	}

	/**
	 * To storing chrome mobile emulation configurations(width, height, pixelRatio)
	 * and returning the capabilities
	 * 
	 * <p>
	 * if required feasible result then set andriodWidth, androidHeight,
	 * androidPixelRatio, iosWidth,androidHeight and iosPixelRatio values in the
	 * config.propeties
	 *
	 * @param deviceName - device name
	 * @param userAgent  - User agent
	 * @return chromeCapabilities
	 */
	public static DesiredCapabilities setChromeUserAgent(String deviceName, String userAgent) {
		Map<String, Object> deviceMetrics = new HashMap<String, Object>();
		Map<String, Object> mobileEmulation = new HashMap<String, Object>();

		int width = 0;
		int height = 0;
		Double pixRatio = null;

		width = Integer.valueOf(mobEmuUA.getDeviceWidth(deviceName));
		height = Integer.valueOf(mobEmuUA.getDeviceHeight(deviceName));
		pixRatio = Double.valueOf(mobEmuUA.getDevicePixelRatio(deviceName));

		deviceMetrics.put("width", width);
		deviceMetrics.put("height", height);
		deviceMetrics.put("pixelRatio", pixRatio);
		mobileEmulation.put("deviceMetrics", deviceMetrics);
		mobileEmulation.put("userAgent", userAgent);
		Log.event("mobileEmulation settings::==> " + mobileEmulation);
		opt.setExperimentalOption(MOBILE_EMULATION, mobileEmulation);
		chromeCapabilities1.setCapability(ChromeOptions.CAPABILITY, opt);
		return chromeCapabilities1;
	}

	/**
	 * To make sure sauce performance is enabled
	 * 
	 * @return
	 */
	public static boolean isSaucePerformanceEnabled() {
		if (System.getProperty(RUN_SAUCE_PERFORMANCE) != null
				&& System.getProperty(RUN_SAUCE_PERFORMANCE).trim().equalsIgnoreCase("true")
						? true
						: System.getenv(RUN_SAUCE_PERFORMANCE) != null
								&& System.getenv(RUN_SAUCE_PERFORMANCE).trim().equalsIgnoreCase("true") ? true
										: propertiesReader.runSaucePerformance() != null
												&& propertiesReader.runSaucePerformance() == true) {
			if ((System.getProperty(SELENIUM_DRIVER) != null
					&& StringUtils.containsIgnoreCase(System.getProperty(SELENIUM_DRIVER), CHROME))
					|| (System.getenv(SELENIUM_DRIVER) != null
							&& StringUtils.containsIgnoreCase(System.getenv(SELENIUM_DRIVER), CHROME))) {
				return true;
			}
		}
		return false;
	}

	/*
	 * generate sauce performance report
	 */
	public static String generateSaucePerformanceReport(final WebDriver driver) {
		String sauceLink = null, sauceUserName = null, sauceAuthKey = null;
		String saucelabsSessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
		sauceUserName = StringUtils.isNotBlank(propertiesReader.sauceUserName()) ? propertiesReader.sauceUserName()
				: null;
		sauceAuthKey = StringUtils.isNotBlank(propertiesReader.sauceAuthKey()) ? propertiesReader.sauceAuthKey() : null;
		sauceLink = "http://saucelabs.com/job-embed/" + saucelabsSessionId + ".js?auth="
				+ newHMACMD5Digest(sauceUserName + ":" + sauceAuthKey, saucelabsSessionId);
		return sauceLink;
	}

	/**
	 * Webdriver to get the web driver with browser name and platform and setting
	 * the desired capabilities for browsers
	 * 
	 * @param browserWithPlatform - Browser With Platform
	 * @param proxy               - Proxy
	 * @return driver - WebDriver Instance
	 * @throws MalformedURLException
	 */
	public static WebDriver getDriver(String browserWithPlatform, Proxy proxy) throws MalformedURLException {
		String browser = null;
		String platform = null;
		String sauceUserName = null;
		String sauceAuthKey = null;
		String bsUserName = null;
		String bsAuthKey = null;
		String lambdaUserName = null;
		String lambdaAuthKey = null;
		WebDriver driver = null;
		String userAgent = null;
		long startTime = StopWatch.startTime();

		// Get invoking test name
		String callerMethodName = new Exception().getStackTrace()[2].getMethodName();
		Log.event("TestCaseID:: " + callerMethodName);

		// driver initialization part
		synchronized (System.class) {
			// From local to sauce lab for browser test

			/*
			 * System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
			 * System.out.println( "^" + System.getProperty(RUN_SAUCELAB_FROM_LOCAL) + " ^ "
			 * + System.getenv(RUN_SAUCELAB_FROM_LOCAL));
			 */

			if (propertiesReader.runLambdaTestFromLocal() != null
					&& propertiesReader.runLambdaTestFromLocal() == true) {

				lambdaUserName = StringUtils.isNotBlank(propertiesReader.lambdaUserName())
						? propertiesReader.lambdaUserName()
						: null;
				lambdaAuthKey = StringUtils.isNotBlank(propertiesReader.lambdaAuthKey())
						? propertiesReader.lambdaAuthKey()
						: null;

				driver = createlambdaTestWebDriver(callerMethodName, lambdaUserName, lambdaAuthKey);
				return driver;
			}

			boolean runScriptsInCloudFromJenkin = System.getProperty(RUN_SAUCELAB_FROM_LOCAL) != null ? true : false;
			boolean runScriptsInAWS = System.getProperty(RUN_AWS) != null ? true : false;
			String cloudDecider = "";
			String configDecider = "";
			if (runScriptsInCloudFromJenkin) {
				// jenkin
				cloudDecider = System.getProperty(RUN_SAUCELAB_FROM_LOCAL).equalsIgnoreCase("true")
						? RUN_SAUCELAB_FROM_LOCAL
						: "runBrowserStackFromLocal";
				System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
				System.out.println("^" + System.getProperty(RUN_SAUCELAB_FROM_LOCAL) + " ^ "
						+ System.getenv(RUN_SAUCELAB_FROM_LOCAL));
			} else if (runScriptsInAWS) {
				cloudDecider = RUN_AWS;
			} else {
				// config
				configDecider = propertiesReader.runSauceLabFromLocal() != null
						&& propertiesReader.runSauceLabFromLocal() == true
								? RUN_SAUCELAB_FROM_LOCAL
								: propertiesReader.runBrowserStackFromLocal() != null
										&& propertiesReader.runBrowserStackFromLocal() == true
												? "runBrowserStackFromLocal"
												: propertiesReader.runAWS() != null && propertiesReader.runAWS() == true
														? RUN_AWS
														: "local";
			}

			sauceUserName = StringUtils.isNotBlank(propertiesReader.sauceUserName()) ? propertiesReader.sauceUserName()
					: null;
			sauceAuthKey = StringUtils.isNotBlank(propertiesReader.sauceAuthKey()) ? propertiesReader.sauceAuthKey()
					: null;

			bsUserName = StringUtils.isNotBlank(propertiesReader.bsUserName()) ? propertiesReader.bsUserName() : null;
			bsAuthKey = StringUtils.isNotBlank(propertiesReader.bsAuthKey()) ? propertiesReader.bsAuthKey() : null;

			switch (cloudDecider.toUpperCase()) {
			case "RUNSAUCELABFROMLOCAL":
				driver = createSaucelabsWebDriver(callerMethodName, sauceUserName, sauceAuthKey);
				return driver;

			case "RUNBROWSERSTACKFROMLOCAL":
				driver = createBrowserStackWebDriver(callerMethodName, bsUserName, bsAuthKey);
				return driver;

			default:
				break;
			}

			switch (configDecider.toUpperCase()) {
			case "RUNSAUCELABFROMLOCAL":
				driver = createSaucelabsWebDriver(callerMethodName, sauceUserName, sauceAuthKey);
				return driver;

			case "RUNBROWSERSTACKFROMLOCAL":
				driver = createBrowserStackWebDriver(callerMethodName, bsUserName, bsAuthKey);
				return driver;
			default:
				break;
			}

			/*
			 * if (cloudDecider.equalsIgnoreCase(RUN_SAUCELAB_FROM_LOCAL)) { driver =
			 * createSaucelabsWebDriver(callerMethodName, sauceUserName, sauceAuthKey);
			 * return driver; } else if
			 * (cloudDecider.equalsIgnoreCase("runBrowserStackFromLocal")) { driver =
			 * createBrowserStackWebDriver(callerMethodName, bsUserName, bsAuthKey); return
			 * driver; } else if (configDecider.equalsIgnoreCase(RUN_SAUCELAB_FROM_LOCAL)) {
			 * driver = createSaucelabsWebDriver(callerMethodName, sauceUserName,
			 * sauceAuthKey); return driver; } else if
			 * (configDecider.equalsIgnoreCase("runBrowserStackFromLocal")) { driver =
			 * createBrowserStackWebDriver(callerMethodName, bsUserName, bsAuthKey); return
			 * driver; }
			 */
			/*
			 * if (configProperty.hasProperty(RUN_SAUCELAB_FROM_LOCAL) &&
			 * configProperty.getProperty(RUN_SAUCELAB_FROM_LOCAL).trim().equalsIgnoreCase(
			 * "true")) {
			 * 
			 * driver = createSaucelabsWebDriver(callerMethodName, sauceUserName,
			 * sauceAuthKey); return driver; }
			 * 
			 * // From local to sauce lab for browser test else if
			 * (configProperty.hasProperty("runBrowserStackFromLocal") &&
			 * configProperty.getProperty("runBrowserStackFromLocal").trim().
			 * equalsIgnoreCase("true")) {
			 * 
			 * driver = createBrowserStackWebDriver(callerMethodName, bsUserName,
			 * bsAuthKey); return driver; }
			 */
		}
		// To support local to local execution by grid configuration
		if (browserWithPlatform.contains("_")) {
			browser = browserWithPlatform.split("_")[0].toLowerCase().trim();
			platform = browserWithPlatform.split("_")[1].toUpperCase().trim();
			if (propertiesReader.runSauceLabFromLocal() != null && propertiesReader.runSauceLabFromLocal() == false) {
				platform = platform.split(" ")[0];
			}

		} else {
			platform = "ANY";
			browser = browserWithPlatform;
		}

		try {
			boolean headless = propertiesReader.headless() != null ? propertiesReader.headless() : false;

			if (CHROME.equalsIgnoreCase(browser)) {
				ChromeOptions chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--remote-allow-origins=*");

				if (propertiesReader.runUserAgentDeviceTest() != null
						&& propertiesReader.runUserAgentDeviceTest() == true) {
					deviceName = StringUtils.isNotBlank(propertiesReader.deviceName()) ? propertiesReader.deviceName()
							: null;
					// userAgent = mobEmuUA.getUserAgent(deviceName);
					// if (userAgent != null && deviceName != null) {
					// driver = new RemoteWebDriver(hubURL, setChromeUserAgent(deviceName,
					// userAgent));
					if (deviceName != null) {
						Map<String, String> mobileEmulation = new HashMap<>();
						mobileEmulation.put("deviceName", deviceName);
						chromeOptions.setExperimentalOption(MOBILE_EMULATION, mobileEmulation);

						driver = new ChromeDriver(chromeOptions);
					} else {
						logger.error(CONFIG_NOT_IMPLEMENTED_TXT + deviceName);
					}
				} else {
					chromeOptions.addArguments("--start-maximized");
					chromeOptions.addArguments(DISABLE_WEB_SECURITY);
					chromeOptions.addArguments("--remote-allow-origins=*");
					// chromeOpt.setExperimentalOption("w3c", true);
					Map<String, Object> prefs = new HashMap<String, Object>();
					prefs.put("credentials_enable_service", false);
					prefs.put("profile.password_manager_enabled", false);
					chromeOptions.setExperimentalOption("prefs", prefs);

					if (headless)
						chromeOptions.addArguments(HEADLESS_NEW);

					chromeCapabilities1.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
					chromeCapabilities1.setPlatform(Platform.fromString(platform));
					if (proxy != null)
						chromeCapabilities1.setCapability(CapabilityType.PROXY, proxy);

					// driver = new RemoteWebDriver(hubURL, chromeCapabilities1);

					driver = new ChromeDriver(chromeOptions);
					driver.manage().window().maximize();
				}
			} else if (IEXPLORER.equalsIgnoreCase(browser)) {
				ieCapabilities1.setCapability("enablePersistentHover", false);
				ieCapabilities1.setCapability("ignoreZoomSetting", true);
				ieCapabilities1.setCapability("nativeEvents", false);
				ieCapabilities1.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						true);
				ieCapabilities1.setBrowserName("internet explorer");
				ieCapabilities1.setPlatform(Platform.fromString(platform));

				if (proxy != null)
					ieCapabilities1.setCapability(CapabilityType.PROXY, proxy);

				driver = new RemoteWebDriver(hubURL, ieCapabilities1);
			} else if (browser.toLowerCase().contains("edge")) {
				EdgeOptions edgeOptions = new EdgeOptions();

				if (propertiesReader.runUserAgentDeviceTest() != null
						&& propertiesReader.runUserAgentDeviceTest() == true) {
					deviceName = StringUtils.isNotBlank(propertiesReader.deviceName()) ? propertiesReader.deviceName()
							: null;
					// userAgent = mobEmuUA.getUserAgent(deviceName);
					// if (userAgent != null && deviceName != null) {
					// driver = new RemoteWebDriver(hubURL, setChromeUserAgent(deviceName,
					// userAgent));
					if (deviceName != null) {
						Map<String, String> mobileEmulation = new HashMap<>();
						mobileEmulation.put("deviceName", deviceName);
						edgeOptions.setExperimentalOption(MOBILE_EMULATION, mobileEmulation);

						driver = new EdgeDriver(edgeOptions);
					} else {
						logger.error(CONFIG_NOT_IMPLEMENTED_TXT + deviceName);
					}
				} else {
					if (headless)
						edgeOptions.addArguments(HEADLESS_NEW);
					edgeCapabilities1.setPlatform(Platform.fromString(platform));
					edgeCapabilities1.setBrowserName("MicrosoftEdge");
					// driver = new RemoteWebDriver(hubURL, edgeCapabilities1);

					edgeOptions.addArguments("InPrivate");
					driver = new EdgeDriver(edgeOptions);
					driver.manage().window().maximize();
				}
			} else if (browser.toLowerCase().contains(FIREFOX)) {

				FirefoxOptions firefoxOptions = new FirefoxOptions();
				firefoxOptions.addArguments("--start-maximized");
				firefoxOptions.addArguments(DISABLE_WEB_SECURITY);
				// firefoxOptions.addArguments("--remote-allow-origins=*");

				if (headless)
					firefoxOptions.addArguments(HEADLESS_NEW);

				driver = new FirefoxDriver(firefoxOptions);
				driver.manage().window().maximize();
			} else if (SAFARI.contains(browser.split("\\&")[0])) {
				if (propertiesReader.runUserAgentDeviceTest() != null
						&& propertiesReader.runUserAgentDeviceTest() == true) {
					deviceName = StringUtils.isNotBlank(propertiesReader.deviceName()) ? propertiesReader.deviceName()
							: null;
					userAgent = mobEmuUA.getUserAgent(deviceName);
					if (userAgent != null && deviceName != null) {
						driver = new RemoteWebDriver(hubURL, setChromeUserAgent(deviceName, userAgent));
					} else {
						logger.error(CONFIG_NOT_IMPLEMENTED_TXT + deviceName);
					}
				} else {
					safariCapabilities1.setCapability("prerun",
							"https://gist.githubusercontent.com/saucyallison/3a73a4e0736e556c990d/raw/d26b0195d48b404628fc12342cb97f1fc5ff58ec/disable_fraud.sh");
					driver = new RemoteWebDriver(hubURL, safariCapabilities1);
				}
				// To run a ZAP TC's use Browser opt as zap
			} else {
				synchronized (WebDriverFactory.class) {
					FirefoxOptions foptions = new FirefoxOptions();
					if (headless)
						foptions.addArguments(HEADLESS_NEW);
					firefoxCapabilities1.setCapability("unexpectedAlertBehaviour", "ignore");
					firefoxCapabilities1.setPlatform(Platform.fromString(platform));
					firefoxCapabilities1.merge(foptions);
					driver = new RemoteWebDriver(hubURL, firefoxCapabilities1);
				}
			}
			// driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(maxPageLoadWait, TimeUnit.SECONDS);
			Assert.assertNotNull(driver,
					"Driver did not intialize...\n Please check if hub is running / configuration settings are corect.");

		} catch (UnreachableBrowserException e) {
			e.printStackTrace();
			throw new SkipException("Hub is not started or down.");
		} catch (WebDriverException e) {

			try {
				if (driver != null) {
					driver.quit();
				}
			} catch (Exception e1) {
				e.printStackTrace();
			}

			if (e.getMessage().toLowerCase().contains("error forwarding the new session empty pool of vm for setup")) {
				throw new SkipException("Node is not started or down.");
			} else if (e.getMessage().toLowerCase()
					.contains("error forwarding the new session empty pool of vm for setup")
					|| e.getMessage().toLowerCase().contains("cannot get automation extension")
					|| e.getMessage().toLowerCase().contains("chrome not reachable")) {
				Log.message("&emsp;<b> --- Re-tried as browser crashed </b>");
				try {
					driver.quit();
				} catch (WebDriverException e1) {
					e.printStackTrace();
				}
				driver = get();
			} else {
				throw e;
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Exception encountered in getDriver Method." + e.getMessage().toString());
		} finally {
			// ************************************************************************************************************
			// * Update start time of the tests once free slot is assigned by
			// RemoteWebDriver - Just for reporting purpose
			// *************************************************************************************************************/
			try {
				Field f = Reporter.getCurrentTestResult().getClass().getDeclaredField("m_startMillis");
				f.setAccessible(true);
				f.setLong(Reporter.getCurrentTestResult(), Calendar.getInstance().getTime().getTime());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		Log.event("Driver::initialize::Get", StopWatch.elapsedTime(startTime));
		try {
			browserWithPlatform = browserWithPlatform.split(" ")[0];
		} catch (Exception e) {
			// TODO: handle exception
		}
		Log.addExecutionEnvironmentToReport(driver, browserWithPlatform);
		return driver;
	}

	public static DesiredCapabilities getUserAgentDesiredCapabilities(DesiredCapabilities caps, String deviceName,
			String userAgent, Boolean sauceConnect, String tunnelIdentifier) {

		Map<String, Object> deviceMetrics = new HashMap<String, Object>();
		Map<String, Object> mobileEmulation = new HashMap<String, Object>();

		int width = 0;
		int height = 0;
		Double pixRatio = null;

		width = Integer.valueOf(mobEmuUA.getDeviceWidth(deviceName));
		height = Integer.valueOf(mobEmuUA.getDeviceHeight(deviceName));
		pixRatio = Double.valueOf(mobEmuUA.getDevicePixelRatio(deviceName));

		deviceMetrics.put("width", width);
		deviceMetrics.put("height", height);
		deviceMetrics.put("pixelRatio", pixRatio);
		mobileEmulation.put("deviceMetrics", deviceMetrics);
		mobileEmulation.put("userAgent", userAgent);
		Log.event("mobileEmulation settings::==> " + mobileEmulation);

		ChromeOptions opt = new ChromeOptions();
		opt.setExperimentalOption(MOBILE_EMULATION, mobileEmulation);
		if (sauceConnect) {
			opt.setCapability(TUNNELL_IDENTIFIER, tunnelIdentifier);
		}
		caps.setCapability(ChromeOptions.CAPABILITY, opt);
		return caps;
	}

	public static WebDriver createSaucelabsWebDriver(String testName, String sauceUserName, String sauceAuthKey)
			throws MalformedURLException {
		// right now we only support sauce labs

		WebDriver driver = null;
		String userAgent = null;

		DesiredCapabilities sauceDesiredCapabilities = new DesiredCapabilities();

		String screenResolution = StringUtils.isNotBlank(propertiesReader.screenResolution())
				? propertiesReader.screenResolution()
				: null;
		String seleniumVersion = StringUtils.isNotBlank(propertiesReader.seleniumVersion())
				? propertiesReader.seleniumVersion()
				: null;
		String iedriverVersion = StringUtils.isNotBlank(propertiesReader.iedriverVersion())
				? propertiesReader.iedriverVersion()
				: null;
		String chromedriverVersion = StringUtils.isNotBlank(propertiesReader.chromedriverVersion())
				? propertiesReader.chromedriverVersion()
				: null;
		String maxTestDuration = StringUtils.isNotBlank(propertiesReader.maxTestDuration())
				? propertiesReader.maxTestDuration()
				: null;
		String commandTimeout = StringUtils.isNotBlank(propertiesReader.commandTimeout())
				? propertiesReader.commandTimeout()
				: null;
		String idleTimeout = StringUtils.isNotBlank(propertiesReader.idleTimeout()) ? propertiesReader.idleTimeout()
				: null;

		/*
		 * String browserName = configProperty.hasProperty(BROWSER_NAME) ?
		 * configProperty.getProperty(BROWSER_NAME) : null;
		 */

		// String browserName =
		// Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest()
		// .getParameter(BROWSER_NAME);

		/*
		 * String browserName = configProperty.hasProperty(BROWSER_NAME) ?
		 * configProperty.getProperty(BROWSER_NAME) : null;
		 * 
		 * String browserVersion = configProperty.hasProperty(BROWSER_VERSION) ?
		 * configProperty.getProperty(BROWSER_VERSION) : null;
		 * System.out.println(browserVersion); String platformName =
		 * configProperty.hasProperty(PLATFORM) ? configProperty.getProperty(PLATFORM) :
		 * null;
		 */

		String browserName = System.getProperty(BROWSER_NAME) != null ? System.getProperty(BROWSER_NAME)
				: propertiesReader.browserName().toLowerCase().trim();

		String browserVersion = System.getProperty(BROWSER_VERSION) != null ? System.getProperty(BROWSER_VERSION)
				: propertiesReader.browserVersion().toLowerCase().trim();

		String platformName = System.getProperty(PLATFORM) != null ? System.getProperty(PLATFORM)
				: propertiesReader.platform().toLowerCase().trim();

		boolean sauceConnect = propertiesReader.sauceConnect() != null ? propertiesReader.sauceConnect() : null;
		String tunnelIdentifier = StringUtils.isNotBlank(propertiesReader.tunnelIdentifier())
				? propertiesReader.tunnelIdentifier()
				: "";

		MutableCapabilities sauceOptions = new MutableCapabilities();
		sauceOptions.setCapability("screenResolution", screenResolution);
		sauceOptions.setCapability("name", testName);
		sauceOptions.setCapability("seleniumVersion", seleniumVersion);
		sauceOptions.setCapability("iedriverVersion", iedriverVersion);
		sauceOptions.setCapability("chromedriverVersion", chromedriverVersion);
		sauceOptions.setCapability("maxDuration", maxTestDuration);
		sauceOptions.setCapability("commandTimeout", commandTimeout);
		sauceOptions.setCapability("idleTimeout", idleTimeout);
		sauceOptions.setCapability("recordScreenshots", true);
		sauceOptions.setCapability("recordVideo", true);
		sauceOptions.setCapability("videoUploadOnPass", true);
//		sauceOptions.setCapability(TUNNELL_IDENTIFIER, "4da3544cf3684feca84ecac76b6fbbe3");
		if (WebDriverFactory.isSaucePerformanceEnabled()) {
			sauceDesiredCapabilities.setCapability("extendedDebugging", true);
			sauceDesiredCapabilities.setCapability("capturePerformance", true);
		}

		if (browserName.toLowerCase().contains(CHROME)) {
			ChromeOptions browserOptions = new ChromeOptions();
			browserOptions.setCapability(BROWSER_NAME, browserName);
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability(PLATFORM_NAME, platformName);
			if (sauceConnect) {
				browserOptions.setCapability(TUNNELL_IDENTIFIER, tunnelIdentifier);
			}
			// browserOptions.setExperimentalOption("w3c", true);
			browserOptions.setCapability(SAUCE_OPTIONS, sauceOptions);
			sauceDesiredCapabilities.setCapability(ChromeOptions.CAPABILITY, browserOptions);
		} else if (browserName.toLowerCase().contains(FIREFOX)) {
			FirefoxOptions browserOptions = new FirefoxOptions();
			browserOptions.setCapability(BROWSER_NAME, browserName);
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability(PLATFORM_NAME, platformName);
			if (sauceConnect) {
				browserOptions.setCapability(TUNNELL_IDENTIFIER, tunnelIdentifier);
			}
			browserOptions.setCapability(SAUCE_OPTIONS, sauceOptions);
			sauceDesiredCapabilities.setCapability(FirefoxOptions.FIREFOX_OPTIONS, browserOptions);
		} else if (browserName.toLowerCase().contains(IEXPLORER)) {
			InternetExplorerOptions browserOptions = new InternetExplorerOptions();
			browserOptions.setCapability(BROWSER_NAME, "Internet Explorer");
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability(PLATFORM_NAME, platformName);
			if (sauceConnect) {
				browserOptions.setCapability(TUNNELL_IDENTIFIER, tunnelIdentifier);
			}
			browserOptions.setCapability(SAUCE_OPTIONS, sauceOptions);
			sauceDesiredCapabilities.merge(browserOptions);
		} else if (browserName.toLowerCase().contains("edge")) {
			EdgeOptions browserOptions = new EdgeOptions();
			// browserOptions.setCapability(BROWSER_NAME, "MicrosoftEdge");
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability(PLATFORM_NAME, platformName);
			browserOptions.setCapability(SAUCE_OPTIONS, sauceOptions);
			if (sauceConnect) {
				browserOptions.setCapability(TUNNELL_IDENTIFIER, tunnelIdentifier);
			}
			sauceDesiredCapabilities.merge(browserOptions);
		} else if (browserName.toLowerCase().contains(SAFARI)) {
			screenResolution = "1920x1440";
			sauceOptions.setCapability("screenResolution", screenResolution);
			SafariOptions browserOptions = new SafariOptions();
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability(PLATFORM_NAME, platformName);
			if (sauceConnect) {
				browserOptions.setCapability(TUNNELL_IDENTIFIER, tunnelIdentifier);
			}
			browserOptions.setCapability(SAUCE_OPTIONS, sauceOptions);
			sauceDesiredCapabilities.merge(browserOptions);
		}

		if (propertiesReader.runUserAgentDeviceTest() == true) {
			deviceName = StringUtils.isNotBlank(propertiesReader.deviceName()) ? propertiesReader.deviceName() : null;
			userAgent = mobEmuUA.getUserAgent(deviceName) != null ? mobEmuUA.getUserAgent(deviceName) : null;

			if (deviceName != null && userAgent != null) {
				driver = new RemoteWebDriver(
						new URL(HTTP + sauceUserName + ":" + sauceAuthKey + "@ondemand.saucelabs.com:80/wd/hub"),
						getUserAgentDesiredCapabilities(sauceDesiredCapabilities, deviceName, userAgent, sauceConnect,
								tunnelIdentifier));

			} else {
				logger.error(
						"Invalid mobile emulation configuration, check theparameters(deviceName) value: " + deviceName);
			}
		} else {
			driver = new RemoteWebDriver(
					new URL(HTTP + sauceUserName + ":" + sauceAuthKey + "@ondemand.saucelabs.com:80/wd/hub"),
					sauceDesiredCapabilities);
			driver.manage().window().maximize();
		}

		String saucelabsSessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
		String sauceLink = "http://saucelabs.com/jobs/" + saucelabsSessionId + "?auth=" + newHMACMD5Digest(
				System.getenv("SAUCE_USER_NAME") + ":" + System.getenv("SAUCE_API_KEY"), saucelabsSessionId);
		logger.debug("Saucelab link for " + testName + ":: " + sauceLink);
		Log.addExecutionEnvironmentToReport(driver, browserName + "_" + platformName);
		Log.addSauceJobUrlToReport(driver, sauceLink);
		// Log.addTestRunMachineInfo(driver, sauceLink);
		return driver;
	}

	public static WebDriver createBrowserStackWebDriver(String testName, String bsUserName, String bsAuthKey)
			throws MalformedURLException {
		/*
		 * String browserName = configProperty.hasProperty(BROWSER_NAME) ?
		 * configProperty.getProperty(BROWSER_NAME) : null;
		 * 
		 * String browserVersion = configProperty.hasProperty(BROWSER_VERSION) ?
		 * configProperty.getProperty(BROWSER_VERSION) : null;
		 * System.out.println(browserVersion); String platformName =
		 * configProperty.hasProperty(PLATFORM) ? configProperty.getProperty(PLATFORM) :
		 * null;
		 */

		String browserName = System.getProperty(BROWSER_NAME) != null ? System.getProperty(BROWSER_NAME)
				: propertiesReader.browserName().toLowerCase().trim();

		String browserVersion = System.getProperty(BROWSER_VERSION) != null ? System.getProperty(BROWSER_VERSION)
				: propertiesReader.browserVersion().toLowerCase().trim();

		String platformName = System.getProperty(PLATFORM) != null ? System.getProperty(PLATFORM)
				: propertiesReader.platform().trim();

		String platformVersion = null;
		try {
			String[] splited;
			if (platformName.startsWith("OS X")) {
				// splited = platformName.split("OS X");
				platformVersion = platformName.replace("OS X ", "");
				platformName = "OS X";
			} else {
				splited = platformName.split("\\s+");
				platformName = splited[0];
				platformVersion = splited[1];
			}
		} catch (Exception e) {
			Log.message("Error setting up BrowserStack OS platform " + e.getMessage());
		}

		WebDriver driver = null;
		final String URL = "https://" + bsUserName + ":" + bsAuthKey + "@hub-cloud.browserstack.com/wd/hub";
		DesiredCapabilities bsDesiredCapabilities = new DesiredCapabilities();
		// bsDesiredCapabilities.setCapability("browserstack.debug", "true");

		if (browserName.toLowerCase().contains(CHROME)) {
			ChromeOptions browserOptions = new ChromeOptions();
			browserOptions.setCapability(BROWSER_NAME, browserName);
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability("os", platformName);
			browserOptions.setCapability(OS_VERSION, platformVersion);

			bsDesiredCapabilities.setCapability(ChromeOptions.CAPABILITY, browserOptions);
		} else if (browserName.toLowerCase().contains(FIREFOX)) {
			FirefoxOptions browserOptions = new FirefoxOptions();
			browserOptions.setCapability(BROWSER_NAME, browserName);
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability("os", platformName);
			browserOptions.setCapability(OS_VERSION, platformVersion);

			bsDesiredCapabilities.setCapability(ChromeOptions.CAPABILITY, browserOptions);
		} else if (browserName.toLowerCase().contains(IEXPLORER)) {
			InternetExplorerOptions browserOptions = new InternetExplorerOptions();
			browserOptions.setCapability(BROWSER_NAME, browserName);
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability("os", platformName);
			browserOptions.setCapability(OS_VERSION, platformVersion);

			bsDesiredCapabilities.setCapability(ChromeOptions.CAPABILITY, browserOptions);
		} else if (browserName.toLowerCase().contains("edge")) {
			EdgeOptions browserOptions = new EdgeOptions();
			browserOptions.setCapability(BROWSER_NAME, browserName);
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability("os", platformName);
			browserOptions.setCapability("osVersion", platformVersion);

			bsDesiredCapabilities.setCapability(ChromeOptions.CAPABILITY, browserOptions);
		} else if (browserName.toLowerCase().contains(SAFARI)) {
			SafariOptions browserOptions = new SafariOptions();
			browserOptions.setCapability(BROWSER_NAME, browserName);
			browserOptions.setCapability(BROWSER_VERSION, browserVersion);
			browserOptions.setCapability("os", platformName);
			browserOptions.setCapability(OS_VERSION, platformVersion);

			bsDesiredCapabilities.setCapability(ChromeOptions.CAPABILITY, browserOptions);
		}

		// Creatng URL object
		URL browserStackUrl = new URL(URL);
		// Create object of driver. We execute scripts remotely. So we use
		// RemoteWebDriver
		// There are many constructors to remotewebdriver
		// To pass URL object and Capabilities object, use the below mentioned
		// constructor
		// RemoteWebDriver(URL remoteAddress, Capabilities desiredCapabilities)
		try {
			driver = new RemoteWebDriver(browserStackUrl, bsDesiredCapabilities);
			driver.manage().window().maximize();
			System.out.println("BS driver created");
			String bsSessionId = (((RemoteWebDriver) driver).getSessionId()).toString();
			String bsLink = "http://saucelabs.com/jobs/" + bsSessionId + "?auth=" + newHMACMD5Digest(
					System.getenv("SAUCE_USER_NAME") + ":" + System.getenv("SAUCE_API_KEY"), bsSessionId);
			logger.debug("BroswerStack link for " + testName + ":: " + bsLink);
			Log.addExecutionEnvironmentToReport(driver, browserName + "_" + platformName);
			Log.addSauceJobUrlToReport(driver, bsLink);

		} catch (Exception e) {
			System.out.println("BS setup un-" + bsUserName + "- pwd- " + bsAuthKey + e.getMessage());
		}
		return driver;
	}

	public static WebDriver createlambdaTestWebDriver(String testName, String lambdaUserName, String lambdaAuthKey)
			throws MalformedURLException {

		WebDriver driver = null;
		String userAgent = null;

		DesiredCapabilities lambdaDesiredCapabilities = new DesiredCapabilities();

		// String browserName =
		// Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest()
		// .getParameter(BROWSER_NAME);

		String browserName = System.getenv("LT_BROWSER_NAME") != null ? System.getenv("LT_BROWSER_NAME")
				: StringUtils.isNotBlank(propertiesReader.browserName()) ? propertiesReader.browserName() : null;

		String browserVersion = System.getenv("LT_BROWSER_VERSION") != null ? System.getenv("LT_BROWSER_VERSION")
				: StringUtils.isNotBlank(propertiesReader.browserVersion()) ? propertiesReader.browserVersion() : null;

		System.out.println(browserVersion);

		String platformName = System.getenv("LT_PLATFORM") != null ? System.getenv("LT_PLATFORM")
				: StringUtils.isNotBlank(propertiesReader.platform()) ? propertiesReader.platform() : null;

		boolean lambdaConnect = propertiesReader.lambdaConnect() != null ? propertiesReader.lambdaConnect() : null;
		String tunnelIdentifier = StringUtils.isNotBlank(propertiesReader.tunnelIdentifier())
				? propertiesReader.tunnelIdentifier()
				: "";

		String projectName = System.getenv("LT_BUILD_NAME") != null ? System.getenv("LT_BUILD_NAME")
				: StringUtils.isNotBlank(propertiesReader.projectName()) ? propertiesReader.projectName() : null;

		String resolution = System.getenv("LT_RESOLUTION") != null ? System.getenv("LT_RESOLUTION")
				: StringUtils.isNotBlank(propertiesReader.resolution()) ? propertiesReader.resolution() : null;

		Boolean autoHealOnLT = propertiesReader.autoHeal();

		AbstractDriverOptions browserOptions = null;

		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put(PROJECT, projectName);
		ltOptions.put("w3c", true);
		ltOptions.put(BUILD, projectName);
		ltOptions.put("name", testName);
		ltOptions.put("selenium_version", propertiesReader.seleniumVersion());
		ltOptions.put("autoHeal", autoHealOnLT);

		if (browserName.toLowerCase().contains(CHROME)) {
			browserOptions = new ChromeOptions();
			browserOptions.setPlatformName(platformName);
			browserOptions.setBrowserVersion(browserVersion);

			if (lambdaConnect) {
				browserOptions.setCapability(TUNNEL, true);
				browserOptions.setCapability(TUNNELL_IDENTIFIER, tunnelIdentifier);
			}

			browserOptions.setCapability(LT_OPTIONS, ltOptions);

		} else if (browserName.toLowerCase().contains(FIREFOX)) {
			browserOptions = new FirefoxOptions();
			browserOptions.setPlatformName(platformName);
			browserOptions.setBrowserVersion(browserVersion);

			browserOptions.setCapability(LT_OPTIONS, ltOptions);
		} else if (browserName.toLowerCase().contains(EDGE)) {
			browserOptions = new EdgeOptions();
			browserOptions.setPlatformName(platformName);
			browserOptions.setBrowserVersion(browserVersion);

			browserOptions.setCapability(LT_OPTIONS, ltOptions);
		} else if (browserName.toLowerCase().contains(SAFARI)) {
			browserOptions = new SafariOptions();
			browserOptions.setPlatformName(platformName);
			browserOptions.setBrowserVersion(browserVersion);

			browserOptions.setCapability(LT_OPTIONS, ltOptions);
		}

		driver = new RemoteWebDriver(
				new URL("https://" + lambdaUserName + ":" + lambdaAuthKey + "@hub.lambdatest.com/wd/hub"),
				browserOptions);
		driver.manage().window().maximize();

		String lambdaSessionId = (((RemoteWebDriver) driver).getSessionId()).toString();

		String lambdaLink = "https://automation.lambdatest.com/logs/?sessionID=" + lambdaSessionId;

		logger.debug("LambdaTest link for " + testName + ":: " + lambdaLink);
		Log.addExecutionEnvironmentToReport(driver, browserName + "_" + platformName);
		Log.addLambdaJobUrlToReport(driver, lambdaLink);
		return driver;
	}

	public static void lambdaTestStatusUpdate(WebDriver driver) {
		if (Reporter.getOutput(Reporter.getCurrentTestResult()).toString().contains("FAILSOFT")) {
			((JavascriptExecutor) driver).executeScript("lambda-status=failed");
		} else if (Reporter.getOutput(Reporter.getCurrentTestResult()).toString().contains("FAIL")) {
			((JavascriptExecutor) driver).executeScript("lambda-status=failed");
		} else {
			((JavascriptExecutor) driver).executeScript("lambda-status=passed");
		}
	}
} // WebDriverFactory
