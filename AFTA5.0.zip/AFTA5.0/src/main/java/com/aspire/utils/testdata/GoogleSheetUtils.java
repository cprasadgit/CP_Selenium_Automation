package com.aspire.utils.testdata;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.IntStream;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.BatchUpdateValuesRequest;
import com.google.api.services.sheets.v4.model.BatchUpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;

/**
 * Utility class for interacting with Google Sheets using Google Sheets API v4.
 */
public class GoogleSheetUtils implements IDataReader {

	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS);
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

	// Default Value
	private static String applicationName = "Google Sheet";

	private static Sheets sheetService;

	private String spreadSheetId;

	/**
	 * Private constructor for creating an instance of GoogleSheetUtils. Use the
	 * provided factory methods to create instances.
	 *
	 * @param spreadSheetId   The ID of the Google Sheets spreadsheet.
	 * @param applicationName The name of the application using the utility.
	 */
	private GoogleSheetUtils(String spreadSheetId, String applicationName) {
		this.spreadSheetId = spreadSheetId;
		GoogleSheetUtils.applicationName = applicationName;
	}

	private GoogleSheetUtils(String spreadSheetId) {
		this.spreadSheetId = spreadSheetId;
	}

	private GoogleSheetUtils() {

	}

	/**
	 * Creates a new instance of GoogleSheetUtils and initializes the Google Sheets
	 * service.
	 *
	 * @param credentialResourcePath The path to the credentials resource file for
	 *                               Google Sheets API.
	 * @param spreadSheetId          The ID of the Google Sheets spreadsheet.
	 * @return An instance of GoogleSheetUtils.
	 * @throws IOException              If an I/O error occurs while reading the
	 *                                  credentials resource file.
	 * @throws GeneralSecurityException If a security-related error occurs while
	 *                                  creating the credentials.
	 */
	public static GoogleSheetUtils createSheetsService(String credentialResourcePath, String spreadSheetId) {
		GoogleSheetUtils googlSheetUtil = null;
		try {
			HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
			GoogleCredential credential = GoogleCredential
					.fromStream(GoogleSheetUtils.class.getResourceAsStream(credentialResourcePath))
					.createScoped(SCOPES);
			googlSheetUtil = new GoogleSheetUtils(spreadSheetId);
			try {
				sheetService = new Sheets.Builder(httpTransport, JSON_FACTORY, credential)
						.setApplicationName(applicationName).build();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {

		}
		return googlSheetUtil;
	}

	/**
	 * Creates a new instance of GoogleSheetUtils and initializes the Google Sheets
	 * service.
	 *
	 * @param credentialResourcePath The path to the credentials resource file for
	 *                               Google Sheets API.
	 * @param spreadSheetId          The ID of the Google Sheets spreadsheet.
	 * @param applicationName        The name of the application using the utility.
	 * @return An instance of GoogleSheetUtils.
	 * @throws IOException              If an I/O error occurs while reading the
	 *                                  credentials resource file.
	 * @throws GeneralSecurityException If a security-related error occurs while
	 *                                  creating the credentials.
	 */
	public static GoogleSheetUtils createSheetsService(String credentialResourcePath, String spreadSheetId,
			String applicationName) throws IOException, GeneralSecurityException {
		HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
		GoogleCredential credential = GoogleCredential
				.fromStream(GoogleSheetUtils.class.getResourceAsStream(credentialResourcePath)).createScoped(SCOPES);
		GoogleSheetUtils googlSheetUtil = new GoogleSheetUtils(spreadSheetId, applicationName);
		try {
			sheetService = new Sheets.Builder(httpTransport, JSON_FACTORY, credential)
					.setApplicationName(applicationName).build();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return googlSheetUtil;
	}

	@Override
	public List<Map<String, String>> fetchSheetData(String sheetName) {
		ValueRange response = null;
		try {
			response = sheetService.spreadsheets().values().get(spreadSheetId, sheetName).execute();
		} catch (IOException e) {
			e.printStackTrace();
		}
		List<Map<String, String>> values = new ArrayList<>();

		List<List<Object>> valueList = response.getValues();

		List<Object> headers = valueList.get(0);

		IntStream.range(1, valueList.size()).forEach(rowIndex -> {
			Map<String, String> rowValue = new LinkedHashMap<>();
			IntStream.range(0, valueList.get(rowIndex).size()).forEach(colIndex -> {
				rowValue.put(headers.get(colIndex).toString(), valueList.get(rowIndex).get(colIndex).toString());
			});

			values.add(rowValue);
		});
		return values;
	}

	@Override
	public Map<String, String> getRowValuesByRowNumber(String sheetName, int rowNum) {
		return fetchSheetData(sheetName).get(rowNum - 1);
	}

	@Override
	public Map<String, String> getRowValuesByTcId(String sheetName, String tcID) {
		Optional<Map<String, String>> rowData = fetchSheetData(sheetName).stream()
				.filter(row -> row.entrySet().stream().anyMatch(entry -> entry.getValue().equalsIgnoreCase(tcID)))
				.findFirst();
		if (rowData.isPresent()) {
			return rowData.get();
		} else {
			return null;
		}

	}

	@Override
	public String getCellValueByTcID(String sheetName, String header, String tcID) {
		return getRowValuesByTcId(sheetName, tcID).get(header);
	}

	@Override
	public String getCellValueByRowNumber(String sheetName, String header, int rowNum) {
		return getRowValuesByRowNumber(sheetName, rowNum).get(header);
	}

	@Override
	public boolean updateSheetWithData(String sheetName, List<Map<String, String>> data) {
		try {

			List<List<Object>> allSheetData = new ArrayList<>();
			Object[] headersArray = data.get(0).keySet().toArray();
			List<Object> headersList = Arrays.asList(headersArray);
			allSheetData.add(headersList);

			IntStream.range(1, data.size()).forEach(rowCount -> {
				List<Object> rowData = new ArrayList<>();
				IntStream.range(0, headersList.size()).forEach(colCount -> {
					rowData.add(data.get(rowCount).get(headersArray[colCount]));
				});
				allSheetData.add(rowData);
			});

			List<ValueRange> sheetData = Arrays
					.asList(new ValueRange().setRange(sheetName + "!A1").setValues(allSheetData));
			BatchUpdateValuesResponse execute = sheetService.spreadsheets().values().batchUpdate(spreadSheetId,
					new BatchUpdateValuesRequest().setValueInputOption("RAW").setData(sheetData)).execute();

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean addValuesWithFormulas(String sheetName, List<List<Object>> data) {
		try {
			List<ValueRange> sheetData = Arrays.asList(new ValueRange().setRange(sheetName + "!A1").setValues(data));
			sheetService.spreadsheets().values()
					.batchUpdate(spreadSheetId,
							new BatchUpdateValuesRequest().setValueInputOption("USER_ENTERED").setData(sheetData))
					.execute();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
