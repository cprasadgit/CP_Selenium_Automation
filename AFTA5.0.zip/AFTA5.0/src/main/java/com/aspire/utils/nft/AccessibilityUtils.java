package com.aspire.utils.nft;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import com.aspire.pojo.AllyTestResult;
import com.aspire.pojo.Root;
import com.deque.axe.AXE;
import com.deque.axe.AXE.Builder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.GsonBuilder;

/**
 * This class provides utility methods to perform accessibility testing using
 * the AXE library.
 * 
 * @author bharathi.murugan
 */
public class AccessibilityUtils {

	private Builder builder;
	private JSONObject jsonReport;
	private static final URL scriptURL = AccessibilityUtils.class.getResource("/axe.min.js");
	private static Map<String, JSONObject> results = new LinkedHashMap<>();
	private static String accessbilityTestReportPath = "\\test-output\\accessibilityTestReports\\";
	private static String reportdir = System.getProperty("user.dir") + accessbilityTestReportPath;

	/**
	 * Private constructor to prevent direct instantiation without WebDriver.
	 */
	@SuppressWarnings("unused")
	private AccessibilityUtils() {

	}

	/**
	 * Constructor to initialize AccessibilityUtils with a WebDriver.
	 *
	 * @param driver The WebDriver instance used to analyze the web page for
	 *               accessibility issues.
	 */
	public AccessibilityUtils(WebDriver driver) {
		this.builder = new AXE.Builder(driver, scriptURL);
		createReportFolder();
	}

	private void createReportFolder() {
		File file = new File(reportdir);
		if (!file.exists())
			file.mkdirs();
	}

	/**
	 * Perform full page accessibility scan.
	 * 
	 * @return The updated AccessibilityUtils instance.
	 */
	public AccessibilityUtils performFullPageAccessibilityScan(String pageName) {
		this.jsonReport = this.builder.analyze();
		results.put(pageName, jsonReport);
		return this;
	}

	/**
	 * Perform accessibility scan for a given WebElement.
	 *
	 * @param element The WebElement to be analyzed for accessibility issues.
	 * @return The updated AccessibilityUtils instance.
	 */
	public AccessibilityUtils performAccessibilityScanForElement(WebElement element) {
		this.jsonReport = this.builder.analyze(element);
		return this;
	}

	/**
	 * Exclude an element from accessibility testing.
	 *
	 * @param selector The selector of the element to be excluded.
	 * @return The updated AccessibilityUtils instance.
	 */
	public AccessibilityUtils excludeElementFromAccessibilityTesting(String selector) {
		this.builder.exclude(selector);
		return this;
	}

	/**
	 * Include an element for accessibility testing.
	 *
	 * @param selector The selector of the element to be included.
	 * @return The updated AccessibilityUtils instance.
	 */
	public AccessibilityUtils includeElementForAccessibilityTesting(String selector) {
		this.builder.include(selector);
		return this;
	}

	/**
	 * Display the accessibility report. If there are no violations found, the test
	 * is considered passed, otherwise, it is failed.
	 */
	public void displayAccessibilityReport() {
		JSONArray violations = this.jsonReport.getJSONArray("violations");
		if (violations.length() == 0) {
			System.out.println("There are no violations in the given page");
			Assert.assertTrue(true, "No violations found. Hence the test case is Passed!");
		} else {
			System.out.println(AXE.report(violations));
			Reporter.log("Accessibility_Violations_Report: " + AXE.report(violations));
			Assert.assertTrue(false, "Found violations. Hence the test case is failed!");
		}
	}

	/**
	 * Retrieves the list of accessibility test results.
	 *
	 * @return A list of accessibility test results. This list may be empty if no
	 *         results are available.
	 */
	public static List<AllyTestResult> getResult() throws JsonMappingException, JsonProcessingException {

		List<AllyTestResult> resultList = new ArrayList<>();
		results.entrySet().stream().forEach(entry -> {

			try {
				File jsonFile = new File(reportdir + entry.getKey() + ".json");
				if (!jsonFile.exists()) {
					jsonFile.createNewFile();
				}
				new ObjectMapper().writeValue(jsonFile, entry.getValue().toString());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("JSON object written to file successfully.");

			resultList.add(new AllyTestResult(entry.getKey(),
					new GsonBuilder().serializeNulls().create().fromJson(entry.getValue().toString(), Root.class),
					reportdir + entry.getKey() + ".json"));
		});
		return resultList;
	}
}