package com.aspire.utils.mobile;

@SuppressWarnings("serial")
public class MobileExceptionWrapper extends Exception {
	/**
	 * User defined exception constructor with message
	 * 
	 * @author sanoj.swaminathan
	 * @since 18-04-2020
	 * @param message
	 */
	public MobileExceptionWrapper(String message) {
		super(message);
	}

	/**
	 * User defined exception constructor with message and cause of exception
	 * 
	 * @author sanoj.swaminathan
	 * @since 18-04-2020
	 * @param message
	 * @param cause
	 * @throws MobileExceptionWrapper
	 */
	public MobileExceptionWrapper(String message, Throwable cause) throws MobileExceptionWrapper {
		super(message, cause);
	}

	/**
	 * User defined exception constructor with cause of exception
	 * 
	 * @author sanoj.swaminathan
	 * @since 18-04-2020
	 * @param cause
	 * @throws MobileExceptionWrapper
	 */
	public MobileExceptionWrapper(Throwable cause) throws MobileExceptionWrapper {
		super(cause);
	}
}
