package com.aspire.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.testng.log4testng.Logger;

import com.assertthat.selenium_shutterbug.core.Capture;
import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.epam.healenium.SelfHealingDriver;

/**
 * ScreenshotManager to take screenshots using logger class
 *
 */
public class ScreenshotManager {
	private static final Logger logger = Logger.getLogger(ScreenshotManager.class);
	private static IPropertiesReader propertiesReader = PropertiesReaderUtil.getInstance();

	public static void takeScreenshot(SelfHealingDriver driver, String filepath, String fileName) {
		//WebDriver webDriver = driver;// driver.getDelegate();
		WebDriver webDriver = driver.getDelegate();
		File screenshot = null;

		if (webDriver instanceof TakesScreenshot) {
			if (propertiesReader.fullPageScreenshot() != null && propertiesReader.fullPageScreenshot() == true) {
				fileName = fileName.split("\\.")[0];
				Shutterbug.shootPage(webDriver, Capture.FULL_SCROLL).withName(fileName).save(filepath);
				logger.debug("screenshot taken and stored at " + filepath + fileName);
			} else {
				screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
				try {
					File destFile = new File(filepath + fileName);
					destFile.getParentFile().mkdirs();
					FileUtils.copyFile(screenshot, destFile);
					screenshot.delete(); // it will delete the previous screenshots
					logger.debug("screenshot taken and stored at " + destFile.getAbsolutePath());
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
		} else {
			WebDriver augmentedDriver = new Augmenter().augment(webDriver);
			screenshot = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
		}

	}
}