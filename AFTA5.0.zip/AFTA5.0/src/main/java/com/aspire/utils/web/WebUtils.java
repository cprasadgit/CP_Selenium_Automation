package com.aspire.utils.web;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aspire.utils.IPropertiesReader;
import com.aspire.utils.Log;
import com.aspire.utils.PropertiesReaderUtil;
import com.epam.healenium.SelfHealingDriver;

public class WebUtils {
	
	private static final String NOT_FOUND_IN_PAGE =  " not found in page!!";
	private static final String CLICK_STALE_ELEMENT_EXCEPTION = "click - Stale element exception ";
	private static final String FAILED_TO_CLICK_ON = "Failed to click on ";
	private static final String IS_DISABLED = " is disabled";
	private static final String IS_DISPLAYED = " is displayed";
	private static final String IS_NOT_DISPLAYED = " is not displayed";
	private static final String IS_NOT_SELECTED = " is not Selected";

	private static IPropertiesReader propertyReader = PropertiesReaderUtil.getInstance();

	public static String SCROLL_TO_MIDDLE = "middle";
	public static String SCROLL_TO_BOTTOM = "bottom";

	/**
	 * Used to click on the webelement
	 * 
	 * @param driver
	 * @param btn                - Element to be clicked
	 * @param elementDescription - Description of the element
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void click(SelfHealingDriver driver, WebElement btn, String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		boolean staleElementException = false;

		do {
			if (!WaitUtils.waitForElement(driver, btn, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			try {
				WaitUtils.waitForElementToBeClickable(driver, btn, elementDescription, timeout);
				btn.click();
				break;
			} catch (NoSuchElementException e) {
				Log.fail(FAILED_TO_CLICK_ON + elementDescription + " " + e, driver);
			} catch (ElementClickInterceptedException e2) {
				Actions actions = new Actions(driver);
				actions.moveToElement(btn).pause(1000).click().build().perform();
			} catch (StaleElementReferenceException e1) {
				Log.event(CLICK_STALE_ELEMENT_EXCEPTION + elementDescription);
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);

	}

	/**
	 * Used to click on the webelement
	 * 
	 * @param driver
	 * @param btn                - Element to be clicked
	 * @param elementDescription - Description of the element
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void clickByActionsClass(SelfHealingDriver driver, WebElement btn, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		Actions actions = new Actions(driver);
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			if (!WaitUtils.waitForElement(driver, btn, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			try {
				WaitUtils.waitForElementToBeClickable(driver, btn, elementDescription, timeout);
				actions.moveToElement(btn).pause(1000).click().perform();
				break;
			} catch (NoSuchElementException e) {
				Log.fail(FAILED_TO_CLICK_ON + elementDescription + " " + e, driver);
			} catch (ElementClickInterceptedException e2) {

				actions.moveToElement(btn).pause(1000).click().build().perform();
			} catch (StaleElementReferenceException e1) {
				Log.event(CLICK_STALE_ELEMENT_EXCEPTION + elementDescription);
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);

	}

	@Deprecated
	public static void clear(SelfHealingDriver driver, WebElement txtField, String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();

		if (!WaitUtils.waitForElement(driver, txtField, timeout))
			throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
		try {
			txtField.clear();
			Log.event("cleared on " + elementDescription);
		} catch (NoSuchElementException e) {
			Log.fail("Failed to clear on " + elementDescription + " " + e, driver);
		}
	}

	/**
	 * Used to time on the web element
	 * 
	 * @param driver
	 * @param txt                - text field in which text to be entered
	 * @param textToType         - text to be entered
	 * @param elementDescription - Description of the element
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void type(SelfHealingDriver driver, WebElement txt, String textToType, String elementDescription,
			int... timeOutArray) {

		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			if (!WaitUtils.waitForElement(driver, txt, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			{
				try {
					txt.clear();
					txt.sendKeys(textToType);
					Log.event("Entered value " + textToType + " in" + elementDescription);
					break;
				} catch (NoSuchElementException e) {
					Log.fail("Failed to enter value " + textToType + " in " + elementDescription + " " + e, driver);
				} catch (ElementNotInteractableException e) {
					JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
					jsExecutor.executeScript("arguments[0].value='" + textToType + "';", txt);
					Log.event("type - Element Not Interactable exception");
				} catch (StaleElementReferenceException e1) {
					Log.event("type - Stale element exception");
					staleElementException = true;
				}
				retryCount++;
			}
		} while (retryCount == 1 && staleElementException);

	}

	/**
	 * Set text for textbox using JS
	 */
	public static void typeUsingJS(SelfHealingDriver driver, WebElement txt, String textToType, String elementDescription,
			int... timeOutArray) {

		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			if (!WaitUtils.waitForElement(driver, txt, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			{
				try {
					JavascriptExecutor jse = (JavascriptExecutor) driver;
					jse.executeScript("arguments[0].value=arguments[1];", txt, textToType);
					Log.event("Entered value " + textToType + " in" + elementDescription);
					break;
				} catch (NoSuchElementException e) {
					Log.fail("Failed to enter value " + textToType + " in " + elementDescription + " " + e, driver);
				} catch (ElementNotInteractableException e) {
					JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
					jsExecutor.executeScript("arguments[0].value='" + textToType + "';", txt);
					Log.event("type - Element Not Interactable exception");
				} catch (StaleElementReferenceException e1) {
					Log.event("type - Stale element exception");
					staleElementException = true;
				}
				retryCount++;
			}
		} while (retryCount == 1 && staleElementException);

	}

	/**
	 * Used to verify given element is enabled or not
	 * 
	 * @param driver
	 * @param webElement         - Element to be checked
	 * @param elementDescription - Description
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static boolean verifyElementIsDisplayed(SelfHealingDriver driver, WebElement webElement, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			if (!WaitUtils.waitForElement(driver, webElement, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);

			Log.assertThat(webElement.isDisplayed(), elementDescription + IS_DISABLED,
					elementDescription + IS_DISPLAYED, driver);

		} catch (NoSuchElementException e) {
			Log.fail(elementDescription + IS_NOT_DISPLAYED + e, driver);
		}
		return webElement.isEnabled();
	}

	/**
	 * Used to verify given element is enabled or not
	 * 
	 * @param driver
	 * @param webElement         - Element to be checked
	 * @param elementDescription - Description
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static boolean verifyElementIsEnabled(SelfHealingDriver driver, WebElement webElement, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			if (!WaitUtils.waitForElement(driver, webElement, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);

			Log.assertThat(webElement.isEnabled(), elementDescription + IS_DISABLED,
					elementDescription + " is enabled", driver);

		} catch (NoSuchElementException e) {
			Log.fail(elementDescription + " is not disabled" + e, driver);
		}
		return webElement.isEnabled();
	}

	/**
	 * Used to verify given element is disabled or not
	 * 
	 * @param driver
	 * @param webElement         - Element to be checked
	 * @param elementDescription - Description
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void verifyElementIsDisabled(SelfHealingDriver driver, WebElement webElement, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			if (!WaitUtils.waitForElement(driver, webElement, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);

			Log.assertThat(!webElement.isEnabled(), elementDescription + IS_DISABLED,
					elementDescription + " is enabled", driver);

		} catch (NoSuchElementException e) {
			Log.fail(elementDescription + " is not disabled" + e, driver);
		}
	}

	public static void verifyElementTextIsDisplayed(SelfHealingDriver driver, WebElement webElement, String expectedText,
			String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			if (!WaitUtils.waitForElement(driver, webElement, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			Log.assertThat(webElement.getText().equals(expectedText), elementDescription + IS_DISPLAYED,
					elementDescription + IS_NOT_DISPLAYED, driver);

		} catch (NoSuchElementException e) {
			Log.fail(elementDescription + IS_NOT_DISPLAYED + e, driver);
		}

	}

	public static void verifyRGBColourOfElement(SelfHealingDriver driver, WebElement webElement, String expectedHex,
			String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			if (!WaitUtils.waitForElement(driver, webElement, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			String cssValue = webElement.getCssValue("color");
			String asHex = Color.fromString(cssValue).asHex();
			Log.assertThat(asHex.equals(expectedHex), elementDescription + " is ", elementDescription + " is matching",
					driver);

		} catch (NoSuchElementException e) {
			Log.fail(elementDescription + " is not matching" + e, driver);
		}

	}

	public static void verifyElementDisplayed(SelfHealingDriver driver, WebElement webElement, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			if (!WaitUtils.waitForElement(driver, webElement, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			Log.assertThat(webElement.isDisplayed(), elementDescription + IS_DISPLAYED,
					elementDescription + IS_NOT_DISPLAYED, driver);
		} catch (NoSuchElementException e) {
			Log.fail(elementDescription + IS_NOT_DISPLAYED + e, driver);
		}
	}

	public static void verifyElementNotDisplayed(SelfHealingDriver driver, WebElement webElement, WebElement targetElement,
			String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			if (!WaitUtils.waitForElement(driver, webElement, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			Log.assertThat(!webElement.isDisplayed(), elementDescription + IS_DISPLAYED,
					elementDescription + IS_NOT_DISPLAYED, driver);

		} catch (NoSuchElementException e) {
			Log.fail(elementDescription + IS_NOT_DISPLAYED + e, driver);
		}

	}

	/**
	 * Used to scroll down to particular element
	 * 
	 * @param element - Element to be scrolled To
	 * @param driver
	 */
	public static void scrollToViewElement(WebElement element, SelfHealingDriver driver) {
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			try {
				Actions actions = new Actions(driver);
				actions.moveToElement(element).pause(500).build().perform();
				break;
			} catch (ElementNotInteractableException e) {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
			} catch (StaleElementReferenceException e) {
				Log.event("Scroll to View Element - StaleElement Exception ");
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);

	}

	private static WebDriver getWebDriver(SelfHealingDriver driver) {
		//WebDriver webDriver = driver;// (WebDriver) driver.getDelegate();
		WebDriver webDriver =(WebDriver) driver.getDelegate();
		return webDriver;

	}

	/**
	 * Used to click on the webelement
	 * 
	 * @param driver
	 * @param btn                - Element to be clicked
	 * @param elementDescription - Description of the element
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void clickJS(SelfHealingDriver driver, WebElement btn, String elementDescription, int... timeOutArray) {

		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();

		if (!WaitUtils.waitForElement(driver, btn, timeout))
			throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
			Log.event("Clicked on " + elementDescription);
		} catch (NoSuchElementException e) {
			Log.fail(FAILED_TO_CLICK_ON + elementDescription + " " + e, driver);
		}
	}

	/**
	 * @author anitha.raphel Used to select drop down option using Select class and
	 *         SelectByVisibleText method and verify the selected Text
	 * @param driver
	 * @param webElement
	 * @param optnSelect
	 * @param elementDescription
	 * @param timeOutArray
	 * @throws Exception
	 */
	@Deprecated
	public static void selectDropDownByVisibleText(SelfHealingDriver driver, WebElement webElement, String optnSelect,
			String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			try {
				if (!WaitUtils.waitForElement(driver, webElement, timeout))
					throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
				Select select = new Select(webElement);
				select.selectByVisibleText(optnSelect);
			} catch (NoSuchElementException e) {
				Log.fail(elementDescription + IS_NOT_SELECTED + e, driver);
			} catch (StaleElementReferenceException e1) {
				Log.event("selectDropDownByVisibleText - Stale element exception");
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);
	}

	/**
	 * @author magesh.nagamani Used to select drop down option using Select class
	 *         and SelectByIndex method and verify the selected Text
	 * @param driver
	 * @param webElement
	 * @param optnSelect
	 * @param elementDescription
	 * @param timeOutArray
	 * @throws Exception
	 */
	@Deprecated
	public static void selectDropDownByIndex(SelfHealingDriver driver, WebElement webElement, int indexToSelect,
			String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			try {
				if (!WaitUtils.waitForElement(driver, webElement, timeout))
					throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
				scrollToViewElement(webElement, driver);
				Select select = new Select(webElement);
				select.selectByIndex(indexToSelect);
			} catch (NoSuchElementException e) {
				Log.fail(elementDescription + IS_NOT_SELECTED + e, driver);
			} catch (StaleElementReferenceException e1) {
				Log.event("selectDropDownByIndex - Stale element exception");
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);
	}

	/**
	 * @author magesh.nagamani Used to get selected option from dropdown
	 * @param driver
	 * @param webElement
	 * @param optnSelect
	 * @param elementDescription
	 * @param timeOutArray
	 * @return
	 * @throws Exception
	 */
	public static String getSelectedOptionFromDropdown(SelfHealingDriver driver, WebElement webElement) {
		String returnValue = null;
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			try {
				Select select = new Select(webElement);
				returnValue = select.getFirstSelectedOption().getText();
			} catch (NoSuchElementException e) {
				Log.fail(webElement + IS_NOT_SELECTED + e, driver);
			} catch (StaleElementReferenceException e1) {
				Log.event("getSelectedOptionFromDropdown - Stale element exception");
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);
		return returnValue;
	}

	/**
	 * @author siva.panjanathan Used to confirm the alert
	 * @param driver
	 * @param elementDescription - Description of the element
	 * @throws InterruptedException
	 */
	public static void confirmAlert(SelfHealingDriver driver, String elementDescription, int... timeOutArray)
			throws InterruptedException {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();
			Log.event(elementDescription + "is performed");
		} catch (NoAlertPresentException e) {
			Log.fail(elementDescription + "is not performed" + e, driver);
		} catch (UnhandledAlertException e) {
			Log.fail(elementDescription + "is not performed" + e, driver);
		} catch (TimeoutException e) {
			Log.event("Alert is not displayed");
		}
	}

	/**
	 * Wait for page load using document ready state
	 * 
	 * @param driver
	 * @param maxWaitArray
	 */
	public static void waitForPageLoad(SelfHealingDriver driver, int... maxWaitArray) {
		int maxWait = maxWaitArray.length > 0 ? maxWaitArray[0] : propertyReader.maxElementWait();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(maxWait));
		wait.until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
				.executeScript("return document.readyState").equals("complete"));
		Log.event("Page load completed");
	}

	/**
	 * Press tab using actions key
	 * 
	 * @param driver
	 * @param element
	 */
	public static void enterTab(SelfHealingDriver driver, WebElement element) {
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			try {
				Actions actions = new Actions(driver);
				actions.moveToElement(element).sendKeys(Keys.TAB).pause(1000).build().perform();
				Log.event("Tab key is pressed");
			} catch (StaleElementReferenceException e) {
				Log.event("Tab key - Stale element exception ");
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);
	}

	/**
	 * @author anitha.raphel Used to get the confirm alert Text
	 * @param driver
	 * @param elementDescription - Description of the element
	 * @throws InterruptedException
	 */
	public static void getconfirmAlertText(SelfHealingDriver driver, String expectedAlertText, String elementDescription,
			int... timeOutArray) throws InterruptedException {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			System.out.println("AlertText:" + alertText);
			Log.assertThat(alertText.equalsIgnoreCase(expectedAlertText),
					elementDescription + " is Displayed as expected !!",
					elementDescription + " is not Displayed as expected ", driver);
			alert.accept();
		} catch (NoAlertPresentException e) {
			Log.fail(elementDescription + "is not Displayed" + e, driver);
		} catch (UnhandledAlertException e) {
			Log.fail(elementDescription + "is not Displayed" + e, driver);
		}
	}

	/**
	 * Used to click on the webelement
	 * 
	 * @param driver
	 * @param btn                - Element to be clicked
	 * @param elementDescription - Description of the element
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void moveToElementAndclick(SelfHealingDriver driver, WebElement btn, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		boolean staleElementException = false;
		do {
			if (!WaitUtils.waitForElement(driver, btn, timeout))
				throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
			try {
				Actions actions = new Actions(driver);
				actions.moveToElement(btn).pause(1000).click().build().perform();
				break;
			} catch (NoSuchElementException e) {
				Log.fail(FAILED_TO_CLICK_ON + elementDescription + " " + e, driver);
			} catch (StaleElementReferenceException e1) {
				Log.event(CLICK_STALE_ELEMENT_EXCEPTION + elementDescription);
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);

	}

	/**
	 * @author siva.panjanathan get element text
	 * @param driver
	 * @param element
	 * @param elementDescription
	 * @param timeOutArray
	 * @return
	 */
	public static String getText(SelfHealingDriver driver, WebElement element, String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		String text = "";
		if (!WaitUtils.waitForElement(driver, element, timeout))
			throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
		try {
			text = element.getText();
			if (!text.isEmpty()) {
				Log.event(" Succesfully fetched data from " + elementDescription);
			} else {
				Log.fail("String is empty failed to fetch the data from Element" + element);
			}
		} catch (NoSuchElementException e) {
			Log.fail("Failed to move to " + elementDescription + " " + e);
		}
		return text;
	}

	/**
	 * @author magesh.nagamani get element attribute
	 * @param driver
	 * @param element
	 * @param elementDescription
	 * @param timeOutArray
	 * @return
	 */
	public static String getAttribute(SelfHealingDriver driver, WebElement element, String attributeToGet,
			String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		String text = "";
		if (!WaitUtils.waitForElement(driver, element, timeout))
			throw new NoSuchElementException(elementDescription + NOT_FOUND_IN_PAGE);
		try {
			text = element.getAttribute(attributeToGet).trim();
			if (!text.isEmpty()) {
				Log.event(" Succesfully fetched attribute from " + elementDescription);
			} else {
				Log.fail("String is empty failed to fetch the data from Element" + element);
			}
		} catch (NoSuchElementException e) {
			Log.fail("No such element- " + elementDescription + " " + e);
		}
		return text;
	}

	public static void waitForAjax(SelfHealingDriver driver) {
		try {
			while (true) {
				Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor) getWebDriver(driver))
						.executeScript("return jQuery.active == 0");
				if (ajaxIsComplete) {
					Log.event("AJAX call completed");
					;
					break;
				}
				Thread.sleep(150);
			}
		} catch (Exception e) {

		}
	}

	/**
	 * Switch to second window
	 * 
	 * @author magesh.nagamani
	 * @since 24-01-2023
	 */
	public static void switchToSecondTab(SelfHealingDriver driver) {
		// It will return the parent window name as a String
		String parent = driver.getWindowHandle();
		Set<String> s = driver.getWindowHandles();

		// Now iterate using Iterator
		Iterator<String> I1 = s.iterator();

		while (I1.hasNext()) {

			String child_window = I1.next();

			if (!parent.equals(child_window))
				driver.switchTo().window(child_window);
		}
	}

	/**
	 * Switch back to the default page
	 * 
	 * @author magesh.nagamani
	 * @since 24-01-2023
	 */
	public static void switchToDefaultContent(SelfHealingDriver driver) {

		// close current window
		driver.close();

		// switch to default content
		// driver.switchTo().defaultContent();

		Set<String> s = driver.getWindowHandles();

		// Now iterate using Iterator
		Iterator<String> I1 = s.iterator();

		while (I1.hasNext()) {

			String child_window = I1.next();
			driver.switchTo().window(child_window);
		}
	}

	/***
	 * Scroll the given element into view port
	 * 
	 * @author magesh.nagamani
	 * @param driver
	 * @param element
	 */
	public static void scrollWebElementToView(SelfHealingDriver driver, WebElement element, String... scrollPosition) {
		if (scrollPosition.length == 0)
			((JavascriptExecutor) getWebDriver(driver)).executeScript("arguments[0].scrollIntoView(true);", element);
		else if (scrollPosition[0].equals(SCROLL_TO_BOTTOM))
			((JavascriptExecutor) getWebDriver(driver)).executeScript("arguments[0].scrollIntoView(false);", element);
		else if (scrollPosition[0].equals(SCROLL_TO_MIDDLE)) {
			((JavascriptExecutor) getWebDriver(driver)).executeScript("arguments[0].scrollIntoView({block: 'center'});",
					element);
		}
	}

	

}
