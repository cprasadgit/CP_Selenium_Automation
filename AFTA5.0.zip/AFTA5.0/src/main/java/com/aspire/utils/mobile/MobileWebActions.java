package com.aspire.utils.mobile;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

public class MobileWebActions {
	
	private static final String FRAME = "frame";
	private static final String IFRAME= "iframe";
	private static final String CLASS = "class";
	
	/**
	 * This method is used to load the browser URL
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param Url
	 * @throws MobileExceptionWrapper
	 */
	public void loadWebApplication(final WebDriver driver, final String Url) throws MobileExceptionWrapper {
		try {
			if (driver != null) {
				if (new MobileValidations().isMobileWeb(driver)) {
					driver.get(Url);
				}
			} else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(MobileConstants.EXCEPTION_MESSAGE_FOR_LOAD_URL);
		}
	}

	/**
	 * This methods load a new web page in the current browser window.
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param Url
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public void navigateToWebApplication(final WebDriver driver, final String Url) throws MobileExceptionWrapper {
		try {
			if (driver != null) {
				if (new MobileValidations().isMobileWeb(driver))
					driver.navigate().to(Url);
			} else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(MobileConstants.EXCEPTION_MESSAGE_FOR_LOAD_URL);
		}
	}

	/**
	 * This method is used to get the current loaded URL in web applications
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return currentURL
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public String getCurrentUrl(final WebDriver driver) throws MobileExceptionWrapper {
		String currentURL = "";
		try {
			if (driver != null) {
				currentURL = driver.getCurrentUrl();
			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return currentURL;
	}

	/**
	 * This method is used to get the title of the loaded web applications
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return title
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public String getTitle(final WebDriver driver) throws MobileExceptionWrapper {
		String title = "";
		try {
			if (driver != null) {
				title = driver.getTitle();
			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return title;
	}

	/**
	 * Method to get the current session ID of the browser
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public String getWebDriverSessionId(WebDriver driver) throws MobileExceptionWrapper {
		String browserSessionID;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			browserSessionID = ((RemoteWebDriver) driver).getSessionId().toString();
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return browserSessionID;
	}

	/**
	 * Method to get current browser language
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public String getBrowserCurrentLanguage(WebDriver driver) throws MobileExceptionWrapper {
		String language = "";
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			language = (String) ((JavascriptExecutor) driver).executeScript("return window.navigator.language");
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return language;
	}

	/**
	 * Method to get the attribute value of web element - specific to mobile web
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param elementName
	 * @param attributeValue
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public String getAttributeValue(final WebDriver driver, final String elementName, final String attributeName)
			throws MobileExceptionWrapper {
		String value = null;
		try {
			if (driver != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (element != null) {
					if (driver instanceof SafariDriver) {
						value = element.getAttribute(attributeName).replace("", "");
					} else {
						value = element.getAttribute(attributeName);
					}
				} else {
					throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return value;
	}

	/**
	 * It closes the browser window on which the focus is set
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public void closeBrowser(final WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver != null)
				driver.close();
			else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * 
	 * This method accepts the alert thereby clicking on the OK button
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public void acceptAlert(final WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver != null) {
				Thread.sleep(1000);
				final Alert alert = driver.switchTo().alert();
				alert.accept();
			} else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * 
	 * This method dismiss the alert thereby clicking on the cancel button.
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public void dismissAlert(final WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver != null) {
				Thread.sleep(2000);
				final Alert alert = driver.switchTo().alert();
				alert.dismiss();
			} else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * 
	 * This method return the text that visible in an alert
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return alertText
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public String getAlertText(final WebDriver driver) throws MobileExceptionWrapper {
		String alertText = "";
		try {
			if (driver != null) {
				Thread.sleep(2000);
				final Alert alert = driver.switchTo().alert();
				alertText = alert.getText();
			} else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return alertText;
	}

	/**
	 * 
	 * This method used to refresh the loaded web page
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public void refreshWebPage(final WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver != null)
				driver.navigate().refresh();
			else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to refresh the page and wait for sometime based on the timeout.
	 * Applicable for mobile web
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param waitTimeInSeconds
	 * @throws InterruptedException
	 * @throws MobileExceptionWrapper
	 */
	public void webPageRefreshAndWait(final WebDriver driver, final long waitTimeInSeconds)
			throws InterruptedException, MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			driver.navigate().refresh();
			Thread.sleep(waitTimeInSeconds * 1000);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to get web page load time in seconds
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param Url
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public int getWebPageLoadTime(final WebDriver driver, final String Url) throws MobileExceptionWrapper {
		long totalTime;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			final long start = System.currentTimeMillis();
			loadWebApplication(driver, Url);
			final long finish = System.currentTimeMillis();
			totalTime = (finish - start) / 1000;
			System.out.println("Total Time for page load - " + totalTime);

		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return (int) totalTime;
	}

	/**
	 * Method to get page load time of current page and value return in seconds
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public int getWebPageLoadTime(final WebDriver driver) throws MobileExceptionWrapper {
		long totalTime;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			final long start = System.currentTimeMillis();
			loadWebApplication(driver, getCurrentUrl(driver));
			final long finish = System.currentTimeMillis();
			totalTime = (finish - start) / 1000;
			System.out.println("Total Time for page load - " + totalTime);

		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return (int) totalTime;
	}

	/**
	 * Method to go back the previous page and wait for sometime based on the
	 * timeout. Applicable for mobile web
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param waitTimeInSeconds
	 * @throws InterruptedException
	 * @throws MobileExceptionWrapper
	 */
	public void goBackAndWait(final WebDriver driver, final long waitTimeInSeconds)
			throws InterruptedException, MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			driver.navigate().back();
			Thread.sleep(waitTimeInSeconds * 1000);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * 
	 * 
	 * This method helps to get the frame details: first index is number of frames,
	 * second index is frame id, third index is frame name and fourth index is class
	 * name of the frame - Method specific to mobile web application
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 * 
	 */

	public ArrayList<String> getFrameDetails(final WebDriver driver) throws MobileExceptionWrapper {

		final ArrayList<String> elementtext = new ArrayList<String>();
		List<WebElement> elements;
		if (driver != null) {
			if (driver.getPageSource().contains(IFRAME) || driver.getPageSource().contains(FRAME)) {
				elements = driver.findElements(By.tagName(IFRAME));
				if (elements.size() == 0) {
					elements = driver.findElements(By.tagName(FRAME));
				}
				for (final WebElement el : elements) {
					if (el.getAttribute("id") != null && !el.getAttribute("id").equals(""))
						elementtext.add(el.getAttribute("id"));

					if (el.getAttribute("name") != null && !el.getAttribute("name").equals(""))
						elementtext.add(el.getAttribute("name"));

					if (el.getAttribute(CLASS) != null && !el.getAttribute(CLASS).equals(""))
						elementtext.add(el.getAttribute(CLASS));
				}
			} else {
				new Exception(MobileConstants.FRAME_MISSING);
			}
		} else {
			throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		}

		return elementtext;
	}

	/**
	 * 
	 * 
	 * This method helps to switch to frame based on the frame index - Method
	 * specific to mobile web application
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param index
	 * @return isswitchToFrame
	 * @throws MobileExceptionWrapper
	 */

	public boolean switchToFrame(final WebDriver driver, final int index) throws MobileExceptionWrapper {
		boolean isswitchToFrame = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (!driver.getPageSource().contains(IFRAME) || !driver.getPageSource().contains(FRAME)) {
				throw new MobileExceptionWrapper(MobileConstants.FRAME_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.FRAME_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null && driver.getPageSource().contains(IFRAME)) {
				driver.switchTo().frame(index);
				isswitchToFrame = true;
			}
		} catch (Exception lException) {
			lException = new Exception("Frame not available at index " + index);
			throw new MobileExceptionWrapper(lException);
		}
		return isswitchToFrame;
	}

	/**
	 * 
	 * 
	 * This method helps to switch to frame based on the frame name - Method
	 * specific to mobile web application
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param frameName
	 * @return isswitchToFrame
	 * @throws MobileExceptionWrapper
	 */

	public boolean switchToFrameByName(final WebDriver driver, final String frameName) throws MobileExceptionWrapper {
		boolean isswitchToFrame = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				if (driver.getPageSource().contains(IFRAME) || driver.getPageSource().contains(FRAME)) {
					driver.switchTo().frame(frameName);
					isswitchToFrame = true;
				}
			}
		} catch (final Exception lException) {

			throw new MobileExceptionWrapper(lException);
		}
		return isswitchToFrame;

	}

	/**
	 * 
	 * 
	 * This method helps to switch to frame based on the element locator in string
	 * format - Method specific to Web application
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @return isswitchToFrame
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public boolean switchToFrame(final WebDriver driver, final String elementName) throws MobileExceptionWrapper {
		boolean isswitchToFrame = false;
		try {
			if (driver != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (element != null) {
					if (driver.getPageSource().contains(FRAME)) {
						driver.switchTo().frame(element);
						isswitchToFrame = true;
					}
				} else
					throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");

			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return isswitchToFrame;
	}

	/**
	 * 
	 * 
	 * This method helps to switch to parent frame when once done operation inside a
	 * frame - Method specific to mobile web Application
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return isswitchToParanetFrame
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public boolean switchToParentFrame(final WebDriver driver) throws MobileExceptionWrapper {
		boolean isswitchToParanetFrame = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (!driver.getPageSource().contains(IFRAME) || !driver.getPageSource().contains(FRAME)) {
				throw new MobileExceptionWrapper(MobileConstants.FRAME_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.FRAME_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {

			if ((new MobileValidations().isMobileWeb(driver) && !(driver instanceof SafariDriver))) {
				driver.switchTo().window(driver.getWindowHandle());
				isswitchToParanetFrame = true;
			}
			if (driver instanceof SafariDriver) {
				driver.switchTo().window(driver.getWindowHandle());
				isswitchToParanetFrame = true;
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return isswitchToParanetFrame;
	}

	/**
	 * 
	 * 
	 * Selects either the first frame on the page, or the main document when a page
	 * contains iframes - Method specific to Web Application
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return isswitchToDefaultContent
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public boolean switchToDefaultContent(final WebDriver driver) throws MobileExceptionWrapper {

		boolean isswitchToDefaultContent = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (!driver.getPageSource().contains(IFRAME) || !driver.getPageSource().contains(FRAME)) {
				throw new MobileExceptionWrapper(MobileConstants.FRAME_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.FRAME_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				driver.switchTo().defaultContent();
				isswitchToDefaultContent = true;
			}

		} catch (final Exception lException) {

			throw new MobileExceptionWrapper(lException);
		}
		return isswitchToDefaultContent;

	}

	/**
	 * 
	 * 
	 * This method helps to retrieve all cookies names
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return elementtext
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public ArrayList<String> getAllCookies(final WebDriver driver) throws MobileExceptionWrapper {
		final ArrayList<String> elementtext = new ArrayList<>();
		try {
			if (driver != null) {
				final Set<Cookie> cookies = driver.manage().getCookies();
				final Iterator<Cookie> itr = cookies.iterator();
				while (itr.hasNext()) {
					final Cookie c = itr.next();
					elementtext.add(c.getName());
				}
			} else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(MobileConstants.COOKIES_EXCEPTION);
		}
		return elementtext;
	}

	/**
	 * 
	 * 
	 * Delete the named cookie from the current domain. This is equivalent to
	 * setting the named cookie's expiry date to sometime in the past - Applicable
	 * for mobile web applications
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param cookieName
	 * @return isCookieDeleted
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public boolean deleteCookie(final WebDriver driver, final String cookieName) throws MobileExceptionWrapper {
		boolean isCookieDeleted = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				if (new MobileValidations().isMobileWeb(driver)) {
					driver.manage().deleteCookieNamed(cookieName);
					Thread.sleep(3000);
					isCookieDeleted = true;
				}
			}

		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(MobileConstants.COOKIES_EXCEPTION);
		}
		return isCookieDeleted;
	}

	/**
	 * 
	 * 
	 * This method will delete all the cookies for the current domain.
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return isCookieDeleted
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public boolean deleteAllCookies(final WebDriver driver) throws MobileExceptionWrapper {
		boolean isCookieDeleted = false;
		try {
			if (driver != null) {
				driver.manage().deleteAllCookies();
				Thread.sleep(5000);
				isCookieDeleted = true;
			} else
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);

		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return isCookieDeleted;
	}

	/**
	 * 
	 * 
	 * To add a specific cookie into cookies. If the cookie's domain name is left
	 * blank, it is assumed that the cookie is meant for the domain of the current
	 * document
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param cookieName
	 * @param cookieValue
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public void addCookie(final WebDriver driver, final String cookieName, final String cookieValue)
			throws MobileExceptionWrapper {
		try {
			if (driver != null) {
				if (new MobileValidations().isMobileWeb(driver)) {
					final Cookie name = new Cookie(cookieName, cookieValue);
					driver.manage().addCookie(name);
				} else
					throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * This method used to wait for Ajax call to finish.
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param timeoutinseconds
	 * @throws MobileExceptionWrapper
	 * 
	 */
	public void waitForAllAjaxCalls(final WebDriver driver, final int timeoutinseconds) throws MobileExceptionWrapper {
		int second = 0;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}

		while (second < timeoutinseconds) {
			second++;
			if (new MobileValidations().isAjaxNotActive(driver)) {
				break;
			}
			driver.manage().timeouts().implicitlyWait(Duration.ofMillis(1000));
		}

		if (second >= timeoutinseconds) {
			try {
				throw new MobileExceptionWrapper(MobileConstants.EXCEPTION_MESSAGE_WAITFOR_AJAXCALL);
			} catch (final MobileExceptionWrapper e) {

				throw new MobileExceptionWrapper(e);
			}
		}
	}
}
