package com.aspire.utils.nft;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.aspire.pojo.AllyTestResult;
import com.aspire.pojo.PerformanceTestResult;
import com.aspire.pojo.SecurityTestResult;
import com.aspire.utils.testdata.WorkBookUtils;

public class ReportConfiguration {

	/**
	 * To generate the report for Accessbility and security testing
	 * 
	 * @throws IOException
	 * @throws URISyntaxException
	 * 
	 */
	public static void generateReport() throws IOException, URISyntaxException {

		List<AllyTestResult> accessibiltyResultList = AccessibilityUtils.getResult();

		List<SecurityTestResult> securityTestResults = SecurityUtil.getResult();

		// Performance Test Reults
		List<PerformanceTestResult> performanceTestResult = new ArrayList<>();
		try {
			performanceTestResult = generatePerformanceReport();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Initialize the TemplateEngine
		TemplateEngine templateEngine = ThymeleafConfiguration.createTemplateEngine();

		// Create a context and add data to it
		Context context = new Context();
		context.setVariable("accessibilityResultList", accessibiltyResultList);
		context.setVariable("securityTestResultList", securityTestResults);
		context.setVariable("performanceTestResultList", performanceTestResult);

		// Render the template
		String htmlContent = templateEngine.process("TestResultTemplate.html", context);

		// Create the directory if it doesn't exist
		File directory = new File("test-output");
		if (!directory.exists()) {
			directory.mkdirs();
		}

		String filePath = "test-output/NFT_Report.html";

		// Write the HTML content to the file
		try (FileWriter fileWriter = new FileWriter(filePath)) {
			fileWriter.write(htmlContent);
			System.out.println("Accessibility, Security and Performance report generated and saved successfully.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static List<PerformanceTestResult> generatePerformanceReport() throws IOException, URISyntaxException {

		URL res = ReportConfiguration.class.getClassLoader()
				.getResource(PerformanceTestResult.filePath + "/" + PerformanceTestResult.fileName);
		File file = Paths.get(res.toURI()).toFile();

		// String path = ReportConfiguration.class.getClassLoader()
		// .getResource(PerformanceTestResult.filePath + "/" +
		// PerformanceTestResult.fileName).getPath();
		// String path =
		// Resources.getResource(PerformanceTestResult.filePath).getFile();
		WorkBookUtils workBook = WorkBookUtils.getWorkBook(file);
		List<Map<String, String>> tableContent = workBook.getTableContent("Dashboard", 7);
		List<PerformanceTestResult> results = new ArrayList<>();
		tableContent.forEach(row -> {
			try {
				results.add(new PerformanceTestResult(row));
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

		return results;

	}
}
