package com.aspire.utils;

import com.github.javafaker.Faker;

public class FakeDataProvider {
	static Faker faker = null;

	private static Faker getFakerInstance() {
		if (faker == null)
			faker = new Faker();

		return faker;
	}

	public static String getAddress() {
		return getFakerInstance().address().toString();
	}
	
	public static String getUserName() {
		return getFakerInstance().name().username();
	}
	
	public static String getPostCodeAddress() {
		return getFakerInstance().address().zipCode();
	}

	public static String getName() {
		return getFakerInstance().name().fullName();
	}

	public static String getFirstName() {
		return getFakerInstance().name().firstName();
	}

	public static String getLastName() {
		return getFakerInstance().name().lastName();
	}

	public static String getCompanyName() {
		return getFakerInstance().company().name();
	}

	public static String getMobileNumber() {
		return getFakerInstance().number().digits(10);
	}

	public static String getRandomString() {
		return getFakerInstance().educator().university() + "2";
	}

	public static String getEmailAddress() {
		return getFakerInstance().internet().safeEmailAddress();
	}

	public static String getPhoneNumber() {
		return getFakerInstance().phoneNumber().phoneNumber();
	}

	public static String getJobTitle() {
		return getFakerInstance().company().profession();
	}

	public static String getRandomDateOfMonth() {
		return getFakerInstance().date().birthday(1, 31).toString();
	}

	public static String getRandomMonth() {
		return getFakerInstance().date().birthday(1, 12).toString();
	}

	public static String getRandomYear() {
		return getFakerInstance().date().birthday(1990, 2023).toString();
	}
}
