package com.aspire.utils.mobile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.xml.sax.SAXException;

public class MobileValidations {
	
	private static final String PLATFORM_NAME = "platformName";
	private static final String BROWSER_NAME = "browserName";

	/**
	 * Method to verify whether running platform is Android native or not
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static boolean isNativeAndroid(final WebDriver driver) throws MobileExceptionWrapper {
		boolean isAndroid = false;
		if (!isMobileWeb(driver)) {
			final String platform = MobileUtils.getCapabilities(driver).getCapability(PLATFORM_NAME).toString();
			if (platform.equalsIgnoreCase("Android") || platform.equalsIgnoreCase("LINUX")) {
				isAndroid = true;
			} else {
				isAndroid = false;
			}
		}
		return isAndroid;
	}

	/**
	 * Method to verify whether running platform is iOS native or not
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static boolean isNativeiOS(final WebDriver driver) throws MobileExceptionWrapper {
		boolean isiOS = false;
		if (!isMobileWeb(driver)) {
			final String platform = MobileUtils.getCapabilities(driver).getCapability(PLATFORM_NAME).toString();
			if (!platform.equalsIgnoreCase("LINUX")) {
				isiOS = true;
			} else {
				isiOS = false;
			}
		}
		return isiOS;
	}

	/**
	 * To check the execution platform is mobile web or not
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static boolean isMobileWeb(final WebDriver driver) throws MobileExceptionWrapper {
		boolean capFlagCheck = false;
		final Capabilities cap = MobileUtils.getCapabilities(driver);
		if (cap.getCapability("udid") != null) {
			if (cap.getCapability(BROWSER_NAME) != null) {
				if (cap.getCapability(BROWSER_NAME).toString().equalsIgnoreCase("chrome")
						|| cap.getCapability(BROWSER_NAME).toString().equalsIgnoreCase("safari")) {
					capFlagCheck = true;
				} else {
					capFlagCheck = false;
				}
			}
		}
		return capFlagCheck;
	}

	/**
	 * This method checks the virtual keyboard is active or not, currently it works
	 * only for Android platform
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2023
	 * @return isKeyboardPresent
	 * @param driver
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public static boolean verifyKeyboardPresent(WebDriver driver, String messageOnFailure) throws Exception {
		boolean isKeyboardPresent = false;
		String DeviceUDID = MobileUtils.getCapabilities(driver).getCapability("udid").toString();
		String platformName = MobileUtils.getCapabilities(driver).getCapability(PLATFORM_NAME).toString();
		try {
			if (driver != null) {
				if (platformName.equalsIgnoreCase("android")) {
					String checkkeyboard = "adb -s " + DeviceUDID + " shell dumpsys input_method | grep mInputShown";
					Process pb = Runtime.getRuntime().exec(checkkeyboard);

					BufferedReader in = new BufferedReader(new InputStreamReader(pb.getInputStream()));
					String temp = null;
					List<String> line = new ArrayList<String>();
					while ((temp = in.readLine()) != null) {
						line.add(temp);
					}
					if (line.get(0).contains("mInputShown=true") == true) {
						isKeyboardPresent = true;
					} else {
						isKeyboardPresent = false;
					}
				}
				Assert.assertTrue(isKeyboardPresent, messageOnFailure);
			}
		} catch (Exception e) {
			Assert.assertTrue(isKeyboardPresent, messageOnFailure);
		}
		return isKeyboardPresent;
	}

	/**
	 * 
	 * This method returns WiFi status - Applicable for Mobile Native Android
	 * Applications
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2023
	 * @param driver
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public static boolean verifyWiFiAvailable(WebDriver driver, String messageOnFailure) throws Exception {
		boolean isWiFiAvailable = false;

		String DeviceUDID = MobileUtils.getCapabilities(driver).getCapability("udid").toString();
		String platformName = MobileUtils.getCapabilities(driver).getCapability(PLATFORM_NAME).toString();
		try {
			if (driver != null) {
				if (platformName.equalsIgnoreCase("android")) {
					Process togetWiFiStatus = Runtime.getRuntime()
							.exec("adb -s " + DeviceUDID + " shell dumpsys wifi | grep Wi-Fi");
					togetWiFiStatus.waitFor();
					BufferedReader outputreader = new BufferedReader(
							new InputStreamReader(togetWiFiStatus.getInputStream()));
					String singleLine;
					while ((singleLine = outputreader.readLine()) != null) {
						if (singleLine.contains("Wi-Fi is enabled")) {
							isWiFiAvailable = true;
							break;
						} else if (singleLine.contains("Wi-Fi is disabled")) {
							isWiFiAvailable = false;
							break;
						}
					}
					Assert.assertTrue(isWiFiAvailable, messageOnFailure);
				}
			}
		} catch (Exception e) {
			Assert.assertTrue(isWiFiAvailable, messageOnFailure);
		}
		return isWiFiAvailable;
	}

	/**
	 * Verify the visibility of an element on the page
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementVisible(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean isElementVisible = false;
		try {
			WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
			if (element != null) {
				isElementVisible = true;
			} else {
				isElementVisible = false;
			}
			Assert.assertTrue(isElementVisible, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(isElementVisible, messageOnFailure);
		}
	}

	/**
	 * Verify that the object is visible based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction:left,  right, above, below, near
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementVisible(WebDriver driver, String tagName, String direction, String elementName,
			String messageOnFailure) throws MobileExceptionWrapper {
		boolean elementVisible = false;
		try {
			WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
			WebElement elementToDoAction = new MobileUtils().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isDisplayed()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(elementVisible, messageOnFailure);
		}
	}

	/**
	 * Verify the visibility of an element is not on the page
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementNotVisible(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean elementNotPresent = false;
		try {
			WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
			if (element != null) {
				elementNotPresent = true;
			} else {
				elementNotPresent = false;
			}
			Assert.assertFalse(elementNotPresent, messageOnFailure);
		} catch (Exception e) {
			Assert.assertFalse(elementNotPresent, messageOnFailure);
		}
	}

	/**
	 * Verify that the the element is displayed on the page
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementDisplayed(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean elementVisible = false;
		try {
			if (new ObjectRepositoryHandler().getObject(driver, elementName).isDisplayed()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(elementVisible, messageOnFailure);
		}
	}

	/**
	 * Verify that the element is not displayed on the page
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementNotDisplayed(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean elementNotVisible = false;
		try {
			if (new ObjectRepositoryHandler().getObject(driver, elementName).isDisplayed()) {
				elementNotVisible = true;
			} else {
				elementNotVisible = false;
			}
			Assert.assertFalse(elementNotVisible, messageOnFailure);
		} catch (Exception e) {
			Assert.assertFalse(elementNotVisible, messageOnFailure);
		}
	}

	/**
	 * Verify that the element is enabled
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementEnabled(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean elementEnabled = false;
		try {
			if (new ObjectRepositoryHandler().getObject(driver, elementName).isEnabled()) {
				elementEnabled = true;
			} else {
				elementEnabled = false;
			}
			Assert.assertTrue(elementEnabled, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(elementEnabled, messageOnFailure);
		}
	}

	/**
	 * Verify that the object is enabled based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction:left,  right, above, below, near
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementEnabled(WebDriver driver, String tagName, String direction, String elementName,
			String messageOnFailure) throws MobileExceptionWrapper {
		boolean elementVisible = false;
		try {
			WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
			WebElement elementToDoAction = new MobileUtils().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isEnabled()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(elementVisible, messageOnFailure);
		}
	}

	/**
	 * Verify that the element is not enabled
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementNotEnabled(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean elementNotEnabled = false;
		try {
			if (new ObjectRepositoryHandler().getObject(driver, elementName).isEnabled()) {
				elementNotEnabled = true;
			} else {
				elementNotEnabled = false;
			}
			Assert.assertFalse(elementNotEnabled, messageOnFailure);
		} catch (Exception e) {
			Assert.assertFalse(elementNotEnabled, messageOnFailure);
		}
	}

	/**
	 * Verify that the element is selected
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementSelected(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean elementSelected = false;
		try {
			if (new ObjectRepositoryHandler().getObject(driver, elementName).isSelected()) {
				elementSelected = true;
			} else {
				elementSelected = false;
			}
			Assert.assertTrue(elementSelected, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(elementSelected, messageOnFailure);
		}
	}

	/**
	 * Verify that the object is selected based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction:left,  right, above, below, near
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementSelected(WebDriver driver, String tagName, String direction, String elementName,
			String messageOnFailure) throws MobileExceptionWrapper {
		boolean elementVisible = false;
		try {
			WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
			WebElement elementToDoAction = new MobileUtils().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isSelected()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(elementVisible, messageOnFailure);
		}
	}

	/**
	 * Verify that the element is not selected
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementNotSelected(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean elementNotSelected = false;
		try {
			if (new ObjectRepositoryHandler().getObject(driver, elementName).isSelected()) {
				elementNotSelected = true;
			} else {
				elementNotSelected = false;
			}
			Assert.assertFalse(elementNotSelected, messageOnFailure);
		} catch (Exception e) {
			Assert.assertFalse(elementNotSelected, messageOnFailure);
		}
	}

	/**
	 * Verify that the checkbox selected for mobile web application
	 * 
	 * @author sanoj.swaminathan
	 * @since 05/18/2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyCheckboxSelected(WebDriver driver, String elementName, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean isCheckboxSelected = false;
		try {
			if (driver != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (element != null) {
					if (element.getAttribute("checked") != null) {
						if (element.getAttribute("checked").equals("true")) {
							isCheckboxSelected = true;
						}
					} else {
						isCheckboxSelected = false;
					}
					Assert.assertTrue(isCheckboxSelected, messageOnFailure);
				}
			}
		} catch (Exception e) {
			Assert.assertTrue(isCheckboxSelected, messageOnFailure);
		}
	}

	/**
	 * Verify that the element text or label is visible
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementText(WebDriver driver, String elementName, String expectedText,
			String messageOnFailure) throws MobileExceptionWrapper {
		boolean textVerified = false;
		try {
			WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
			String actualText = element.getText();
			if (actualText.contentEquals(expectedText)) {
				textVerified = true;
			} else {
				textVerified = false;
			}
			Assert.assertTrue(textVerified, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(textVerified, messageOnFailure);
		}
	}

	/**
	 * Verify that the element contains text or label
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param expectedText
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementTextContains(WebDriver driver, String elementName, String expectedText,
			String messageOnFailure) throws MobileExceptionWrapper {
		boolean textContains = false;
		try {
			WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
			String actualText = element.getText();
			if (actualText.contains(expectedText)) {
				textContains = true;
			} else {
				textContains = false;
			}
			Assert.assertTrue(textContains, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(textContains, messageOnFailure);
		}
	}

	/**
	 * Verify that the element attribute has text or label visible for mobile web
	 * application
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param attributeName
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyElementAttributeHasText(WebDriver driver, String elementName, String attributeName,
			String expectedText, String messageOnFailure) throws MobileExceptionWrapper {
		boolean textVerified = false;
		try {
			WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
			String actualAttributeValue = element.getAttribute(attributeName);
			if (actualAttributeValue.contentEquals(expectedText)) {
				textVerified = true;
			} else {
				textVerified = false;
			}
			Assert.assertTrue(textVerified, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(textVerified, messageOnFailure);
		}
	}

	/**
	 * Verify that the URL contains text or label for mobile web application
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyURLContainsText(WebDriver driver, String expectedText, String messageOnFailure)
			throws MobileExceptionWrapper {
		boolean urlConatinsText = false;
		try {
			String actualURL = driver.getCurrentUrl();
			if (actualURL.contains(expectedText)) {
				urlConatinsText = true;
			} else {
				urlConatinsText = false;
			}
			Assert.assertTrue(urlConatinsText, messageOnFailure);
		} catch (Exception e) {
			Assert.assertTrue(urlConatinsText, messageOnFailure);
		}
	}

	/**
	 * This method will determine if Ajax exists or not on Web Page - applicable for
	 * mobile web
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return
	 * @throws MobileExceptionWrapper
	 * 
	 */
	public static boolean isAjaxNotActive(final WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		return (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0", " ");
	}

	/**
	 * This method used to retrieve the value from the HTML table - applicable for
	 * Mobile Web
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param value
	 * @return
	 * @throws MobileExceptionWrapper
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */

	public static boolean verifyDataInTable(final WebDriver driver, final String elementName, final String value)
			throws MobileExceptionWrapper, ParserConfigurationException, SAXException, IOException {

		boolean isDataPresent = false;
		WebElement table_element;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
		if (element != null) {
			table_element = element;
		} else {
			throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
		}

		final List<WebElement> tr_collection = table_element.findElements(By.xpath("//tbody/tr"));
		List<WebElement> td_collection;

		for (final WebElement trElement : tr_collection) {
			td_collection = trElement.findElements(By.xpath("td"));
			for (final WebElement tdElement : td_collection) {
				new Actions(driver).moveToElement(tdElement).build().perform();
				if (value.equals(tdElement.getText())) {
					isDataPresent = true;
					break;
				}
			}
		}
		Assert.assertTrue(isDataPresent);
		return isDataPresent;
	}

	/**
	 * 
	 * This method used to verify drop-down list values by passing input data as an
	 * array - applicable for Mobile Web
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param optionName
	 * @param stringValues
	 * @throws MobileExceptionWrapper
	 * @return
	 * 
	 */
	public static boolean verifyValuesInDropdown(final WebDriver driver, final String elementName,
			final String optionName, final String[] stringValues) throws MobileExceptionWrapper {
		boolean isValuePresent = false;
		try {
			if (driver != null) {
				WebElement elementr = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (elementr != null) {
					final List<WebElement> listOfElements = elementr.findElements(By.tagName(optionName));
					final List<String> list = new ArrayList<String>();
					for (final String strValue : stringValues) {
						boolean bflag = false;
						for (final WebElement element : listOfElements) {
							final String elementValue = element.getText();
							if (strValue.equals(elementValue)) {
								bflag = true;
								break;
							}
						}
						if (!bflag)
							list.add(strValue);
					}
					if (list.size() > 0) {
						isValuePresent = false;
					} else {
						isValuePresent = true;
					}
				} else {
					throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}
		Assert.assertTrue(isValuePresent);
		return isValuePresent;
	}

	/**
	 * 
	 * This method used to verify drop-down list value by passing input data as
	 * string - applicable for Mobile Web
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param optionName
	 * @param stringValue
	 * @throws MobileExceptionWrapper
	 * @return
	 * 
	 */
	public static boolean verifyValueInDropdown(final WebDriver driver, final String elementName,
			final String optionName, final String stringValue) throws MobileExceptionWrapper {
		boolean isValuePresent = false;
		try {
			if (driver != null) {
				WebElement elementLocator = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (elementLocator != null) {
					final List<WebElement> listOfElements = elementLocator.findElements(By.tagName(optionName));
					for (final WebElement element : listOfElements) {
						final String elementValue = element.getText();
						if (elementValue.equals(stringValue)) {
							isValuePresent = true;
							break;
						} else {
							isValuePresent = false;
						}
					}
				} else {
					throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}
		Assert.assertTrue(isValuePresent);
		return isValuePresent;
	}

	/**
	 * Verify whether the actual and expected results are equal or not, based on
	 * that it will show the message that given as parameter
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param actual
	 * @param expected
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyEquals(String actual, String expected, String messageOnFailure)
			throws MobileExceptionWrapper {
		try {
			Assert.assertEquals((String) actual, (String) expected, (String) messageOnFailure);
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Verify whether the actual and expected results are equal or not for boolean,
	 * based on that it will show the message that given as parameter
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param actual
	 * @param expected
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyEquals(boolean actual, boolean expected, String messageOnFailure)
			throws MobileExceptionWrapper {
		try {
			Assert.assertEquals((boolean) actual, (boolean) expected, (String) messageOnFailure);
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Verify whether the actual and expected results are not equal or not for
	 * String, based on that it will show the message that given as parameter
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param actual
	 * @param expected
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyNotEquals(String actual, String expected, String messageOnFailure)
			throws MobileExceptionWrapper {
		try {
			Assert.assertNotEquals((String) actual, (String) expected, (String) messageOnFailure);
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Verify whether the actual and expected results are equal or not for boolean,
	 * based on that it will show the message that given as parameter
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param actual
	 * @param expected
	 * @param messageOnFailure
	 * @throws MobileExceptionWrapper
	 */
	public static void verifyNotEquals(boolean actual, boolean expected, String messageOnFailure)
			throws MobileExceptionWrapper {
		try {
			Assert.assertNotEquals((boolean) actual, (boolean) expected, (String) messageOnFailure);
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}
	}

}
