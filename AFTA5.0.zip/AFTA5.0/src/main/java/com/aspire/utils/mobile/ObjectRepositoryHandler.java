package com.aspire.utils.mobile;

import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aspire.utils.Log;

import io.appium.java_client.AppiumBy;

public class ObjectRepositoryHandler {
	public ObjectRepositoryHandler() throws MobileExceptionWrapper {
		super();
	}

	MobileUtils utilityActionHelper = new MobileUtils();
	MobileValidations validationActionHelper = new MobileValidations();
	private static final Properties properties_android;
	private static final Properties properties_iOS;
	private static final Properties properties_mobile_web;
	private static final Properties properties_desktop;
	
	private static final String PROPERTIES = ".properties";
	private static final String INDEX = "index";
	private static final String WINDOW_SCROLL_TO = "window.scrollTo(";
	private static final String CONTAINS_TEXT_XPATH = "//*[contains(@text, '";
	private static final String CONTAINS_CONTENT_DESC = "') or contains(@content-desc, '";
	private static final String MOBILE_WEB = "mobile_web";
	private static final String PLATFORM_NAME = "platformName";
	private static final String DECOR= " >>> ";
	private static final String SHORT_LOADING = "SHORT_LOADING";

	/**
	 * This constructor creates property instances using different element property
	 * files
	 * 
	 * @author sanoj.swaminathan
	 * @since 14-03-2023
	 * 
	 * @Exception FileNotFoundException, IOException
	 * 
	 */
	static {
		properties_android = new Properties();
		properties_iOS = new Properties();
		properties_mobile_web = new Properties();
		properties_desktop = new Properties();
		InputStream inputStream_android = null;
		InputStream inputStream_iOS = null;
		InputStream inputStream_mobile_web = null;
		InputStream inputStream_desktop = null;

		try {
			ClassLoader classLoader = ObjectRepositoryHandler.class.getClassLoader();
			inputStream_android = classLoader
					.getResourceAsStream(MobileConstants.ANDROID_OBJECT_REPO + PROPERTIES);
			properties_android.load(inputStream_android);

			inputStream_iOS = classLoader.getResourceAsStream(MobileConstants.IOS_OBJECT_REPO + PROPERTIES);
			properties_iOS.load(inputStream_iOS);

			inputStream_mobile_web = classLoader
					.getResourceAsStream(MobileConstants.MOBILE_WEB_OBJECT_REPO + PROPERTIES);
			properties_mobile_web.load(inputStream_mobile_web);

			inputStream_desktop = classLoader
					.getResourceAsStream(MobileConstants.DESKTOP_OBJECT_REPO + PROPERTIES);
			properties_desktop.load(inputStream_desktop);

		} catch (IOException | NullPointerException e) {
			System.out.println(MobileConstants.OBJECT_REPO_FILES_MISSING);
			System.exit(0);
			try {
				throw new MobileExceptionWrapper(e);
			} catch (MobileExceptionWrapper e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				inputStream_mobile_web.close();
				inputStream_android.close();
				inputStream_iOS.close();
				inputStream_desktop.close();
			} catch (IOException e) {
			}
		}
	}

	/**
	 * Method to check visibility of an element with multiple element locators and
	 * get object
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-04-2020
	 * @param driver
	 * @param elementName
	 * @return
	 * @throws MobileExceptionWrapper
	 */

	public WebElement getObject(final WebDriver driver, final String elementName) throws MobileExceptionWrapper {
		WebElement element = null;
		boolean status = false;
		try {
			final HashMap<String, String> locator = readObjectRepository(driver, elementName);
			if (!locator.isEmpty()) {
				if (validationActionHelper.isNativeiOS(driver)) {
					final String index = locator.get(INDEX);
					int indexKey = -1;
					try {
						indexKey = index == null ? indexKey : Integer.parseInt(index);
					} catch (final Exception e) {
						e.printStackTrace();
					}
					for (final Map.Entry<String, String> entry : locator.entrySet()) {
						final String identifier = entry.getKey();
						final String value = entry.getValue();
						if (value != null && !value.isEmpty()) {
							switch (identifier.toLowerCase(Locale.ENGLISH)) {
							case "x":
								element = waitForElementLocator(driver, By.xpath(value));
								if (element != null) {
									status = true;
								}
								break;

							case "i":
								element = waitForElementLocator(driver, By.id(value));
								if (element != null) {
									status = true;
								}
								break;

							case "ai":
								element = waitForElementLocator(driver, AppiumBy.accessibilityId(value));
								if (element != null) {
									status = true;
								}
								break;

							case "n":
								element = waitForElementLocator(driver, By.name(value));
								if (element != null) {
									status = true;
								}
								break;

							case "cn":
								if (indexKey < 0) {
									element = waitForElementLocator(driver, By.className(value));
								} else {
									element = ((WebElement) driver.findElements(By.className(value)).get(indexKey));
								}
								if (element != null) {
									status = true;
								}
								break;
							default :
								break;
							}
						}
						if (status) {
							if (validationActionHelper.isMobileWeb(driver)) {
								((JavascriptExecutor) driver).executeScript(WINDOW_SCROLL_TO + element.getLocation().x
										+ "," + element.getLocation().y + ")");
							}
							return element;
						}
					}

				} else {
					final String index = locator.get(INDEX);
					int indexKey = -1;
					try {
						indexKey = index == null ? indexKey : Integer.parseInt(index);
					} catch (final Exception e) {
						e.printStackTrace();
					}
					for (final Map.Entry<String, String> entry : locator.entrySet()) {
						final String identifier = entry.getKey();
						final String value = entry.getValue();
						if (value != null && !value.isEmpty()) {
							switch (identifier.toLowerCase(Locale.ENGLISH)) {

							case "x":
								element = waitForElementLocator(driver, By.xpath(value));
								if (element != null) {
									status = true;
								}
								break;

							case "i":
								element = waitForElementLocator(driver, By.id(value));
								if (element != null) {
									status = true;
								}
								break;

							case "ai":
								element = waitForElementLocator(driver, AppiumBy.accessibilityId(value));
								if (element != null) {
									status = true;
								}
								break;

							case "n":
								if (validationActionHelper.isNativeAndroid(driver)) {
									element = waitForElementLocator(driver, By.xpath((CONTAINS_TEXT_XPATH + value
											+ CONTAINS_CONTENT_DESC + value + "')]")));
									if (element != null) {
										status = true;
									}
								} else {
									element = waitForElementLocator(driver, By.name(value));
									if (element != null) {
										status = true;
									}
								}
								break;

							case "plt":
								element = waitForElementLocator(driver, By.partialLinkText(value));
								if (element != null) {
									status = true;
								}
								break;

							case "lt":
								element = waitForElementLocator(driver, By.linkText(value));
								if (element != null) {
									status = true;
								}
								break;

							case "tn":
								element = waitForElementLocator(driver, By.tagName(value));
								if (element != null) {
									status = true;
								}
								break;

							case "cs":
								element = waitForElementLocator(driver, By.cssSelector(value));
								if (element != null) {
									status = true;
								}
								break;

							case "cn":
								if (indexKey < 0) {
									element = waitForElementLocator(driver, By.className(value));
								} else {
									element = ((WebElement) driver.findElements(By.className(value)).get(indexKey));
								}
								if (element != null) {
									status = true;
								}
								break;
							default :
								break;
							}
						}
						if (status) {
							if (validationActionHelper.isMobileWeb(driver)) {
								((JavascriptExecutor) driver).executeScript(WINDOW_SCROLL_TO + element.getLocation().x
										+ "," + element.getLocation().y + ")");
							}
							return element;
						}
					}
				}
			} else {
				element = waitForElement(driver, elementName);
				return element;
			}
		} catch (final MobileExceptionWrapper e) {

		}
		return null;
	}

	/**
	 * Method to check visibility of an element with multiple element locators and
	 * get object
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-04-2020
	 * @param driver
	 * @param elementName
	 * @return
	 * @throws MobileExceptionWrapper
	 */

	public By getObject(final String elementName, final WebDriver driver) throws MobileExceptionWrapper {
		By getLoc = null;
		try {
			final HashMap<String, String> locator = readObjectRepository(driver, elementName);
			if (!locator.isEmpty()) {
				if (validationActionHelper.isNativeiOS(driver)) {
					boolean status = false;
					for (final Map.Entry<String, String> entry : locator.entrySet()) {
						final String identifier = entry.getKey();
						final String value = entry.getValue();
						if (value != null && !value.isEmpty()) {
							switch (identifier.toLowerCase(Locale.ENGLISH)) {

							case "x":
								if (utilityActionHelper.waitForElement(driver, By.xpath(value))) {
									status = true;
									getLoc = By.xpath(value);
								}
								break;

							case "i":
								if (utilityActionHelper.waitForElement(driver, By.id(value))) {
									status = true;
									getLoc = By.id(value);
								}
								break;

							case "ai":
								if (utilityActionHelper.waitForElement(driver, AppiumBy.accessibilityId(value))) {
									status = true;
									getLoc = AppiumBy.accessibilityId(value);
								}
								break;

							case "n":
								if (utilityActionHelper.waitForElement(driver, By.name(value))) {
									status = true;
									getLoc = By.name(value);
								}
								break;

							case "cn":
								if (utilityActionHelper.waitForElement(driver, By.className(value))) {
									status = true;
									getLoc = By.className(value);
								}
								break;
							default :
								break;
							
							}
						}
						if (status) {
							if (validationActionHelper.isMobileWeb(driver)) {
								((JavascriptExecutor) driver)
										.executeScript(WINDOW_SCROLL_TO + driver.findElement(getLoc).getLocation().x
												+ "," + driver.findElement(getLoc).getLocation().y + ")");
							}
							return getLoc;
						}
					}

				} else {
					boolean flag = false;
					final String index = locator.get(INDEX);

					int indexKey = -1;
					try {
						indexKey = index == null ? indexKey : Integer.parseInt(index);
					} catch (final Exception e) {
						e.printStackTrace();
					}
					for (final Map.Entry<String, String> entry : locator.entrySet()) {
						final String identifier = entry.getKey();
						final String value = entry.getValue();
						if (value != null && !value.isEmpty()) {
							switch (identifier.toLowerCase(Locale.ENGLISH)) {

							case "x":
								if (utilityActionHelper.waitForElement(driver, By.xpath(value))) {
									flag = true;
									getLoc = By.xpath(value);
								}
								break;

							case "i":
								if (utilityActionHelper.waitForElement(driver, By.id(value))) {
									flag = true;
									getLoc = By.id(value);
								}
								break;

							case "ai":
								if (utilityActionHelper.waitForElement(driver, AppiumBy.accessibilityId(value))) {
									flag = true;
									getLoc = AppiumBy.accessibilityId(value);
								}
								break;

							case "n":
								if (validationActionHelper.isNativeAndroid(driver)) {
									if (utilityActionHelper.waitForElement(driver, By.xpath((CONTAINS_TEXT_XPATH
											+ value + CONTAINS_CONTENT_DESC + value + "')]")))) {
										flag = true;
										getLoc = By.xpath((CONTAINS_TEXT_XPATH + value
												+ CONTAINS_CONTENT_DESC + value + "')]"));
									}
								} else {
									if (utilityActionHelper.waitForElement(driver, By.name(value))) {
										flag = true;
										getLoc = By.name(value);
									}
								}
								break;

							case "plt":
								if (utilityActionHelper.waitForElement(driver, By.partialLinkText(value))) {
									flag = true;
									getLoc = By.partialLinkText(value);
								}
								break;

							case "lt":
								if (utilityActionHelper.waitForElement(driver, By.linkText(value))) {
									flag = true;
									getLoc = By.linkText(value);
								}
								break;

							case "tn":
								if (utilityActionHelper.waitForElement(driver, By.tagName(value))) {
									flag = true;
									getLoc = By.tagName(value);
								}
								break;

							case "cs":
								if (utilityActionHelper.waitForElement(driver, By.cssSelector(value))) {
									flag = true;
									getLoc = By.cssSelector(value);
								}
								break;

							case "cn":
								if (utilityActionHelper.waitForElement(driver, By.className(value))) {
									flag = true;
									getLoc = By.className(value);
								}
								break;
							default :
								break;
							}
						}
						if (flag) {
							if (validationActionHelper.isMobileWeb(driver)) {
								((JavascriptExecutor) driver)
										.executeScript(WINDOW_SCROLL_TO + driver.findElement(getLoc).getLocation().x
												+ "," + driver.findElement(getLoc).getLocation().y + ")");
							}
							return getLoc;
						}
					}
				}
			} else {
				getLoc = getElementByLocator(elementName);
				return getLoc;
			}
		} catch (final MobileExceptionWrapper e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Method to read object repository
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-04-2020
	 * @param elementName
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	private HashMap<String, String> readObjectRepository(final WebDriver driver, final String elementName)
			throws MobileExceptionWrapper {
		String platform = MOBILE_WEB;
		final HashMap<String, String> locator = new HashMap<>();
		final Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();

		if (validationActionHelper.isMobileWeb(driver)) {
			platform = MOBILE_WEB;
		} else if (driver.toString().contains("WindowsDriver")) {
			platform = "desktop";
		} else {
			if (cap.getCapability(PLATFORM_NAME).toString() != null)
				if (cap.getCapability(PLATFORM_NAME).toString()
						.equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
						|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase("LINUX")) {
					platform = "android";
				} else {
					platform = "ios";
				}
		}
		try {
			String locatorType = "";
			String locatorValue = "";
			if (platform.equalsIgnoreCase(MOBILE_WEB)) {
				for (String key : properties_mobile_web.stringPropertyNames()) {
					if (key.split(">")[0].trim().equals(elementName)) {
						locatorType = key.split(">")[1];
						final String locator_mobile_web = properties_mobile_web
								.getProperty(elementName + ">" + locatorType).trim();
						locatorValue = locator_mobile_web;
						locator.put(locatorType, locatorValue);
						System.out.println(elementName + DECOR + locatorType + " = " + locatorValue);
					}
				}
			}

			if (platform.equalsIgnoreCase("iOS")) {
				for (String key : properties_iOS.stringPropertyNames()) {
					if (key.split(">")[0].trim().equals(elementName)) {
						locatorType = key.split(">")[1];
						final String locator_ios = properties_iOS.getProperty(elementName + ">" + locatorType).trim();
						locatorValue = locator_ios;
						locator.put(locatorType, locatorValue);
						System.out.println(elementName + DECOR + locatorType + " = " + locatorValue);
					}
				}
			}

			if (platform.equalsIgnoreCase("Android")) {
				for (String key : properties_android.stringPropertyNames()) {
					if (key.split(">")[0].trim().equals(elementName)) {
						locatorType = key.split(">")[1];
						final String locator_android = properties_android.getProperty(elementName + ">" + locatorType)
								.trim();
						locatorValue = locator_android;
						locator.put(locatorType, locatorValue);
						System.out.println(elementName + DECOR + locatorType + " = " + locatorValue);
					}
				}
			}

			if (platform.equalsIgnoreCase("desktop")) {
				for (String key : properties_desktop.stringPropertyNames()) {
					if (key.split(">")[0].trim().equals(elementName)) {
						locatorType = key.split(">")[1];
						final String locator_desktop = properties_desktop.getProperty(elementName + ">" + locatorType)
								.trim();
						locatorValue = locator_desktop;
						locator.put(locatorType, locatorValue);
						System.out.println(elementName + DECOR + locatorType + " = " + locatorValue);
					}
				}
			}

		} catch (final Exception e) {
			e.printStackTrace();
		}
		return locator;
	}

	/**
	 * Method helps to get the web element with specified expected condition
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-04-2020
	 * @param driver
	 * @param elementLocator
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	private WebElement waitForElementLocator(WebDriver driver, By elementLocator) throws MobileExceptionWrapper {
		WebElement element = null;
		try {
			long timeout = Long
					.parseLong(new DataHandler().getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			if (driver != null && elementLocator != null) {
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
			}
		} catch (Exception lException) {
			try {
				long timeout = Long.parseLong(
						new DataHandler().getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
				if (driver != null && elementLocator != null) {
					WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
					element = wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
				}
			} catch (Exception e) {
			}
		}
		return element;
	}

	/**
	 * Method to wait for the element using the object mentioned in the Object
	 * Repository
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-202
	 * @param driver
	 * @param elementName
	 * @return element
	 * @throws MobileExceptionWrapper
	 */
	public WebElement waitForElement(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		WebElement element = null;
		try {
			long timeout = Long
					.parseLong(new DataHandler().getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			By actualElement = getElementByLocator(elementName);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			if (validationActionHelper.isMobileWeb(driver)) {
				((JavascriptExecutor) driver).executeScript(
						WINDOW_SCROLL_TO + element.getLocation().x + "," + element.getLocation().y + ")");
			}
		} catch (Exception e) {
			try {
				long timeout = Long.parseLong(
						new DataHandler().getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
				By actualElement = getElementByLocator(elementName);
				element = wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				if (validationActionHelper.isMobileWeb(driver)) {
					((JavascriptExecutor) driver).executeScript(
							WINDOW_SCROLL_TO + element.getLocation().x + "," + element.getLocation().y + ")");
				}
			} catch (Exception e2) {

			}
		}
		return element;
	}

	/**
	 * To get the By locator
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param elementName
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	private By getElementByLocator(String elementName) throws MobileExceptionWrapper {
		By byElement = null;
		try {
			if (elementName.startsWith("#") || elementName.startsWith("td[") || elementName.startsWith("tr[")
					|| elementName.startsWith("td ") || elementName.startsWith("tr ")
					|| elementName.startsWith("input[") || elementName.startsWith("span[")
					|| elementName.startsWith("div")) {
				byElement = By.cssSelector(elementName);
			} else if (elementName.startsWith("//") || elementName.startsWith(".//") || elementName.startsWith("(//")) {
				byElement = By.xpath(elementName);
			} else if (elementName.startsWith("name")) {
				byElement = By.name(elementName.split(">>")[1]);
			} else if (elementName.startsWith("id")) {
				byElement = By.id(elementName.split(">>")[1]);
			} else if (elementName.startsWith("className")) {
				byElement = By.className(elementName.split(">>")[1]);
			} else if (elementName.startsWith("linkText")) {
				byElement = By.linkText(elementName.split(">>")[1]);
			} else if (elementName.startsWith("partialLinkText")) {
				byElement = By.partialLinkText(elementName.split(">>")[1]);
			} else {
				byElement = By.tagName(elementName);
			}
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND);
		}
		return byElement;
	}
}
