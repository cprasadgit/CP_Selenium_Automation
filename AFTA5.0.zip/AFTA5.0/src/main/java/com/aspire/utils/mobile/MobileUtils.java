package com.aspire.utils.mobile;

import static org.openqa.selenium.support.locators.RelativeLocator.with;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.HidesKeyboard;
import io.appium.java_client.InteractsWithApps;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.SupportsRotation;
import io.appium.java_client.remote.options.BaseOptions;

public class MobileUtils {

	public static WebDriverWait driverwait;
	public static Random random;
	DataHandler dataHandler = new DataHandler();

	private static final String FINGER = "finger"; 
	private static final String DIRECTION = "direction";
	private static final String MOBILE_SCROLL = "mobile: scroll";
	private static final String PLATFORM_NAME = "platformName";
	private static final String LINUX = "LINUX";
	private static final String ADB_S = "adb -s ";
	private static final String WRONG_STATUS_MSG = "You have entered wrong status, please enter ON or OFF status";
	private static final String USER_DIR = "user.dir";
	private static final String I_DEVICE_INFO = "ideviceinfo -u ";
	private static final String SHORT_LOADING = "SHORT_LOADING";
	private static final String WINDOW_SCROLL_TO = "window.scrollTo(";
	
	
	/**
	 * This method is to perform swipe action for native application to desired
	 * location - specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @param startx
	 * @param starty
	 * @param endx
	 * @param endy
	 * @return isSwiped
	 * @throws MobileExceptionWrapper
	 * 
	 */
	public static boolean swipe(WebDriver driver, int startx, int starty, int endx, int endy)
			throws MobileExceptionWrapper {
		boolean isSwiped = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				delay(2);
				PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
				Sequence seq = new Sequence(finger, 1);
				seq.addAction(
						finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), startx, starty));
				seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
				seq.addAction(
						finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(), endx, endy));
				seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
				((RemoteWebDriver) driver).perform(Arrays.asList(seq));
				delay(2);
				isSwiped = true;
			}
		} catch (Exception lException) {
			lException = new Exception("Check the parameters: " + " startx: " + startx + " starty: " + starty
					+ " endx: " + endx + " endy: " + endy);
			throw new MobileExceptionWrapper(lException);
		}
		return isSwiped;
	}

	/**
	 * This method is to perform swipe from left to right action for native
	 * application - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static boolean swipeFromLeftToRight(WebDriver driver) throws MobileExceptionWrapper {
		boolean isSwiped = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				Dimension size = driver.manage().window().getSize();
				int starty = size.height / 2;
				int startx = size.width / 2;
				Point source = new Point(startx, starty);
				PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
				Sequence seq = new Sequence(finger, 1);
				seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
						source.getX() / 2, source.getY() / 2));
				seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
				seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
						source.getX() + 350, source.getY() / 2));
				seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
				((RemoteWebDriver) driver).perform(Arrays.asList(seq));
				delay(3);
				isSwiped = true;
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return isSwiped;
	}

	/**
	 * This method is to perform swipe from right to left action for native
	 * application - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @return isSwiped
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static boolean swipeFromRightToLeft(WebDriver driver) throws MobileExceptionWrapper {
		boolean isSwiped = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				Dimension size = driver.manage().window().getSize();
				int starty = size.height / 2;
				int startx = size.width / 2;
				Point source = new Point(startx, starty);
				PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
				Sequence seq = new Sequence(finger, 1);
				seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
						source.getX() + 350, source.getY() / 2));
				seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
				seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
						source.getX() / 2, source.getY() / 2));
				seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
				((RemoteWebDriver) driver).perform(Arrays.asList(seq));
				delay(2);
				isSwiped = true;
			}

		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return isSwiped;
	}

	/**
	 * This method is to perform swipe from bottom to up action for native
	 * application - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @return isSwiped
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static boolean swipeFromBottomToUp(WebDriver driver) throws MobileExceptionWrapper {
		boolean isSwiped = false;
		try {
			if (driver == null || driver.equals(StringUtils.EMPTY)) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				Dimension size = driver.manage().window().getSize();
				int starty = size.height / 2;
				int startx = size.width / 2;
				Point source = new Point(startx, starty);
				PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
				Sequence seq = new Sequence(finger, 1);
				seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
						source.getX() / 2, source.getY() + 900));
				seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
				seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
						source.getX() / 2, source.getY() / 2));
				seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
				((RemoteWebDriver) driver).perform(Arrays.asList(seq));
				delay(2);
				isSwiped = true;
			}
		} catch (Exception lException) {

			throw new MobileExceptionWrapper(lException);
		}
		return isSwiped;
	}

	/**
	 * This method is to perform swipe from top to bottom action for native
	 * application - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @return isSwiped
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static boolean swipeFromTopToBottom(WebDriver driver) throws MobileExceptionWrapper {
		boolean isSwiped = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				if (new MobileValidations().isNativeiOS(driver)) {
					JavascriptExecutor js = (JavascriptExecutor) driver;
					HashMap<String, String> scrollObject = new HashMap<String, String>();
					scrollObject.put(DIRECTION, "up");
					js.executeScript(MOBILE_SCROLL, scrollObject);
				}
				if (new MobileValidations().isNativeAndroid(driver)) {
					Dimension size = driver.manage().window().getSize();
					int starty = size.height / 2;
					int startx = size.width / 2;
					Point source = new Point(startx, starty);
					PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
					Sequence seq = new Sequence(finger, 1);
					seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
							source.getX() / 2, source.getY() / 2));
					seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
					seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
							source.getX() / 2, source.getY() + 900));
					seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
					((RemoteWebDriver) driver).perform(Arrays.asList(seq));
					delay(2);
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return isSwiped;
	}

	/**
	 * Method to scroll the page down - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void scrollDown(WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (new MobileValidations().isNativeiOS(driver)) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				HashMap<String, String> scrollObject = new HashMap<String, String>();
				scrollObject.put(DIRECTION, "up");
				js.executeScript(MOBILE_SCROLL, scrollObject);
			}
			if (new MobileValidations().isNativeAndroid(driver)) {
				Dimension size = driver.manage().window().getSize();
				int starty = size.height / 2;
				int startx = size.width / 2;
				Point source = new Point(startx, starty);
				PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
				Sequence seq = new Sequence(finger, 1);
				seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
						source.getX() / 2, source.getY() / 2));
				seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
				seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
						source.getX() / 2, source.getY() + 900));
				seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
				((RemoteWebDriver) driver).perform(Arrays.asList(seq));
				delay(2);
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to scroll the page down with number of times - Specific for mobile
	 * native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void scrollDown(WebDriver driver, int numberOfTimes) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (new MobileValidations().isNativeiOS(driver)) {
				for (int i = 0; i < numberOfTimes; i++) {
					JavascriptExecutor js = (JavascriptExecutor) driver;
					HashMap<String, String> scrollObject = new HashMap<String, String>();
					scrollObject.put(DIRECTION, "up");
					js.executeScript(MOBILE_SCROLL, scrollObject);
				}
			}
			if (new MobileValidations().isNativeAndroid(driver)) {
				for (int i = 0; i < numberOfTimes; i++) {
					Dimension size = driver.manage().window().getSize();
					int starty = size.height / 2;
					int startx = size.width / 2;
					Point source = new Point(startx, starty);
					PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
					Sequence seq = new Sequence(finger, 1);
					seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
							source.getX() / 2, source.getY() / 2));
					seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
					seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
							source.getX() / 2, source.getY() + 900));
					seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
					((RemoteWebDriver) driver).perform(Arrays.asList(seq));
					delay(2);
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to scroll the page up - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void scrollUp(WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (new MobileValidations().isNativeiOS(driver)) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				HashMap<String, String> scrollObject = new HashMap<String, String>();
				scrollObject.put(DIRECTION, "down");
				js.executeScript(MOBILE_SCROLL, scrollObject);
			}
			if (new MobileValidations().isNativeAndroid(driver)) {
				Dimension size = driver.manage().window().getSize();
				int starty = size.height / 2;
				int startx = size.width / 2;
				Point source = new Point(startx, starty);
				PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
				Sequence seq = new Sequence(finger, 1);
				seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
						source.getX() / 2, source.getY() + 900));
				seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
				seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
						source.getX() / 2, source.getY() / 2));
				seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
				((RemoteWebDriver) driver).perform(Arrays.asList(seq));
				delay(2);
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to scroll the page up with number of times - Specific for mobile
	 * native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void scrollUp(WebDriver driver, int numberOfTimes) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (new MobileValidations().isNativeiOS(driver)) {
				for (int i = 0; i < numberOfTimes; i++) {
					JavascriptExecutor js = (JavascriptExecutor) driver;
					HashMap<String, String> scrollObject = new HashMap<String, String>();
					scrollObject.put(DIRECTION, "down");
					js.executeScript(MOBILE_SCROLL, scrollObject);
				}
			}
			if (new MobileValidations().isNativeAndroid(driver)) {
				for (int i = 0; i < numberOfTimes; i++) {
					Dimension size = driver.manage().window().getSize();
					int starty = size.height / 2;
					int startx = size.width / 2;
					Point source = new Point(startx, starty);
					PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
					Sequence seq = new Sequence(finger, 1);
					seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
							source.getX() / 2, source.getY() + 900));
					seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
					seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
							source.getX() / 2, source.getY() / 2));
					seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
					((RemoteWebDriver) driver).perform(Arrays.asList(seq));
					delay(2);
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * This method is to hide the active keyboard - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return isKeyboardhidden
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static boolean hideKeyboard(WebDriver driver) throws MobileExceptionWrapper {
		boolean isKeyboardhidden = false;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				if (new MobileValidations().isNativeAndroid(driver)) {
					if (new MobileValidations().verifyKeyboardPresent(driver, "Keyboard is not present")) {
						((HidesKeyboard) driver).hideKeyboard();
						isKeyboardhidden = true;
					}
				} else {
					((HidesKeyboard) driver).hideKeyboard();
					isKeyboardhidden = true;
				}
			}
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}
		return isKeyboardhidden;
	}

	
	/**
	 * Force reset the application and do clear data - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */
	/*
	public static void resetApp(WebDriver driver) throws MobileExceptionWrapper {
		String appPackage = "", appActivity = "", appPath = "";
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		appPackage = DataHandler.getProperty(MobileConstants.AUTOMATION_TEST_CONFIG,
				MobileConstants.ANDROID_APPPACKAGE);
		appActivity = DataHandler.getProperty(MobileConstants.AUTOMATION_TEST_CONFIG,
				MobileConstants.ANDROID_APPACTIVITY);
		appPath = DataHandler.getProperty(MobileConstants.AUTOMATION_TEST_CONFIG, MobileConstants.ANDROID_APPLICATION);
		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			if (cap.getCapability(MobileCapabilityType.PLATFORM_NAME).toString()
					.equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
					|| (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX))) {

				if (appPackage != null && !appPackage.equals("")) {
					Process p = Runtime.getRuntime()
							.exec(ADB_S + cap.getCapability(MobileCapabilityType.UDID).toString()
									+ " shell pm clear " + appPackage);
					p.waitFor();
					p.destroy();
					Process q = Runtime.getRuntime()
							.exec(ADB_S + cap.getCapability(MobileCapabilityType.UDID).toString()
									+ " shell am start -n " + appPackage + "/" + appActivity);
					q.waitFor();
					q.destroy();

				} else if (appPath != null && !appPath.equals("")) {
					((SupportsLegacyAppManagement) driver).resetApp();
				}

			} else if (cap.getCapability(MobileCapabilityType.PLATFORM_NAME).toString() != null
					&& cap.getCapability(MobileCapabilityType.PLATFORM_NAME).toString()
							.equalsIgnoreCase(MobileConstants.PLATFORM_NAME_IOS)) {
				try {
					((IOSDriver) driver).removeApp(((org.openqa.selenium.Capabilities) cap)
							.getCapability(IOSMobileCapabilityType.BUNDLE_ID).toString().trim());
					((IOSDriver) driver).installApp(((org.openqa.selenium.Capabilities) cap)
							.getCapability(MobileCapabilityType.APP).toString().trim());
					((IOSDriver) driver).launchApp();
				} catch (Exception lException) {
					throw new MobileExceptionWrapper("iOS app location or bundleID missing in Environment tab",
							lException);
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}
*/

	/**
	 * This method closes the application without reset the data - Specific for
	 * mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void closeApp(WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				delay(3);
				//((SupportsLegacyAppManagement) driver).closeApp();
			}
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * This method activates the given application if it installed, but not running
	 * or if it is running in the background.
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-03-2023
	 * @param bundleID
	 * @throws MobileExceptionWrapper
	 * 
	 */
	public static void activateApp(WebDriver driver, String bundleID) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				((InteractsWithApps) driver).activateApp(bundleID);
			}
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * This method used to remove the application from device - Specific for mobile
	 * native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param bundleId
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void removeApp(WebDriver driver, String bundleId) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
					|| (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX))) {
				delay(2);
				Process process = Runtime.getRuntime()
						.exec(ADB_S + cap.getCapability("udid").toString() + " shell pm uninstall " + bundleId);
				process.waitFor();
				process.destroy();
			} else {
				((InteractsWithApps) driver).removeApp(bundleId);
			}
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * This method helps to install the application - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param appPath
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void installApp(WebDriver driver, String appPath) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				((InteractsWithApps) driver).installApp(appPath);
			}
		} catch (Exception lException) {
			lException = new Exception(MobileConstants.WRONG_APP_PATH);
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * This method used to run the application in background for specified amount of
	 * time (in seconds) - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param seconds
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void runAppInBackground(WebDriver driver, int seconds) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null && seconds > 0) {
				delay(3);
				((InteractsWithApps) driver).runAppInBackground(Duration.ofSeconds(seconds));
			}
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * To start an application in between of automation execution - Specific for
	 * mobile native Android
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param appPackage
	 * @param appActivity
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void startApplication(WebDriver driver, String appPackage, String appActivity)
			throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (appPackage == null || appPackage.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.APP_PACKAGE_VALIDATION_EXCEPTION);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.APP_PACKAGE_VALIDATION_EXCEPTION);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (appActivity == null || appActivity.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.APP_ACTIVITY_VALIDATION_EXCEPTION);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.APP_ACTIVITY_VALIDATION_EXCEPTION);
			throw new MobileExceptionWrapper(e);
		}
		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			if (driver != null) {
				Process p = Runtime.getRuntime()
						.exec(ADB_S + cap.getCapability("uuid").toString()
								+ " shell am start -n " + appPackage + "/" + appActivity);
				p.waitFor();
				p.destroy();
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Lock the device (bring it to the lock screen) for a given number of seconds -
	 * Specific for mobile native - Android
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param seconds
	 * @throws MobileExceptionWrapper
	 * @throws IOException
	 * @throws InterruptedException
	 * 
	 */

	public static void lockDeviceScreen(WebDriver driver, int seconds)
			throws MobileExceptionWrapper, IOException, InterruptedException {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {

			if (seconds <= 0) {
				throw (new MobileExceptionWrapper(
						"Check the parameter value: " + " seconds : " + seconds + " , it should be greater than 0"));
			}
		} catch (Exception e) {
			e = new Exception(
					"Check the parameter value: " + " seconds : " + seconds + " , it should be greater than 0");
			throw new MobileExceptionWrapper(e);

		}
		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();

		if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
				|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
			((AndroidDriver) driver).lockDevice();
			Thread.sleep(seconds * 1000);
			Process p = Runtime.getRuntime().exec(
					ADB_S + cap.getCapability("udid").toString() + " shell am start -n io.appium.unlock/.Unlock");
			p.waitFor();
			Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid").toString() + " shell input keyevent 4");
		} else {
			// ((IOSDriver) driver).lockDevice(Duration.ofSeconds(seconds));
			System.out.println("Sorry, this feature not availalble for iOS");
		}
	}

	/**
	 * To rotate the screen orientation to landscape (Specific to native
	 * applications) - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void rotateScreenToLandscape(WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				((SupportsRotation) driver).rotate(ScreenOrientation.LANDSCAPE);
			}
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * To rotate the screen orientation to portrait (Specific to native
	 * applications) - Specific for mobile native
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void rotateScreenToPortrait(WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				((SupportsRotation) driver).rotate(ScreenOrientation.PORTRAIT);
			}
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * Method to press Home button of a device - Specific for mobile native Android
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 */
	public static void pressDeviceHome(WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			if (driver != null) {
				if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
						|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
					Process process = Runtime.getRuntime()
							.exec(ADB_S + cap.getCapability("udid").toString() + " shell input keyevent 3");
					process.waitFor();
					process.destroy();
				} else {
					// code for ios should be included
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to restart a device - Specific for mobile native Android and iOS
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 */
	public static void restartDevice(WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			if (driver != null) {

				if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
						|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
					Process process = Runtime.getRuntime()
							.exec(ADB_S + cap.getCapability("udid").toString() + " reboot");
					process.waitFor();
					process.destroy();
				} else {
					Process process = Runtime.getRuntime()
							.exec("idevicediagnostics -u " + cap.getCapability("udid").toString() + " restart");
					process.waitFor();
					process.destroy();
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * Method to set WiFi and Mobile Data ON or OFF - Specific for mobile native
	 * Android
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param status
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws MobileExceptionWrapper
	 */

	public static void setWiFiAndData(WebDriver driver, String status)
			throws IOException, InterruptedException, MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			Process process;
			if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
					|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
				if (status.equalsIgnoreCase("on")) {
					process = Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid")
							+ " shell am broadcast -a io.appium.settings.wifi --es setstatus enable");
					process = Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid")
							+ " shell am broadcast -a io.appium.settings.data_connection --es setstatus enable");
					process.waitFor();
				} else if (status.equalsIgnoreCase("off")) {
					process = Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid")
							+ " shell am broadcast -a io.appium.settings.wifi --es setstatus disable");
					process = Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid")
							+ " shell am broadcast -a io.appium.settings.data_connection --es setstatus disable");
					process.waitFor();
				} else {
					System.out.println(WRONG_STATUS_MSG);
				}
			}
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e);
		}
	}

	/**
	 * Method to set WiFi ON or OFF - Specific for mobile native Android
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param status
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws MobileExceptionWrapper
	 */

	public static void setWiFi(WebDriver driver, String status)
			throws IOException, InterruptedException, MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			Process process;
			if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
					|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
				if (status.equalsIgnoreCase("on")) {
					process = Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid")
							+ " shell am broadcast -a io.appium.settings.wifi --es setstatus enable");
					process.waitFor();
				} else if (status.equalsIgnoreCase("off")) {
					process = Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid")
							+ " shell am broadcast -a io.appium.settings.wifi --es setstatus disable");
					process.waitFor();
					delay(3);
				} else {
					System.out.println(WRONG_STATUS_MSG);
				}
			}
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e);
		}
	}

	/**
	 * Method to set mobile data ON or OFF - Specific for mobile native Android
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param status
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws MobileExceptionWrapper
	 */

	public static void setMobileData(WebDriver driver, String status)
			throws IOException, InterruptedException, MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			Process process;
			if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX) || cap
					.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)) {
				if (status.equalsIgnoreCase("on")) {
					process = Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid")
							+ " shell am broadcast -a io.appium.settings.data_connection --es setstatus enable");
					process.waitFor();
				} else if (status.equalsIgnoreCase("off")) {
					process = Runtime.getRuntime().exec(ADB_S + cap.getCapability("udid")
							+ " shell am broadcast -a io.appium.settings.data_connection --es setstatus disable");
					process.waitFor();
					delay(3);
				} else {
					System.out.println(WRONG_STATUS_MSG);
				}
			}
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e);
		}
	}

	/**
	 * Method to get the device log without specifying logLevel- Applicable for
	 * Native applications.
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param logLevel
	 * @throws MobileExceptionWrapper
	 * @throws IOException 
	 */
	public static void getDeviceLog(WebDriver driver) throws MobileExceptionWrapper, IOException {
		BufferedReader bufferedReader = null;
		BufferedWriter bufferedWriter = null;
		FileWriter fileWriter = null;
		String line = null;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				DateFormat dateFormat = new SimpleDateFormat("dd_MM_yyyy");
				Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
				if (new MobileValidations().isNativeAndroid(driver)) {
					String deviceUDID = cap.getCapability("udid").toString();
					new File(new File(System.getProperty(USER_DIR)), MobileConstants.DEVICE_LOG_FOLDER).mkdirs();
					File logFile = null;
					logFile = new File(System.getProperty(USER_DIR) + MobileConstants.DEVICE_LOG_FOLDER + "aLogcat"
							+ "_" + deviceUDID + "_" + dateFormat.format(new Date()) + ".txt");
					if (!logFile.exists()) {
						logFile.createNewFile();
					}
					Process process = Runtime.getRuntime().exec(ADB_S + deviceUDID + " logcat -d");
					bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					fileWriter = new FileWriter(logFile.getAbsoluteFile(), false);
					bufferedWriter = new BufferedWriter(fileWriter);
					while (((line = bufferedReader.readLine()) != null)) {
						if (!(line.isEmpty())) {
							bufferedWriter.write(line);
							bufferedWriter.write("\n");
						}
					}
					process.waitFor();
					process.destroy();
				}
				if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase("iOS")
						&& cap.getBrowserName().toString().equalsIgnoreCase("iOS")) {
					String deviceUDID = cap.getCapability("udid").toString();
					new File(new File(System.getProperty(USER_DIR)), MobileConstants.DEVICE_LOG_FOLDER).mkdirs();
					File logFile = null;
					logFile = new File(System.getProperty(USER_DIR) + MobileConstants.DEVICE_LOG_FOLDER + "aLogcat"
							+ "_" + deviceUDID + "_" + dateFormat.format(new Date()) + ".txt");
					if (!logFile.exists()) {
						logFile.createNewFile();
					}
					Process process = Runtime.getRuntime().exec("idevicesyslog -u " + deviceUDID);
					bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					fileWriter = new FileWriter(logFile.getAbsoluteFile(), false);
					bufferedWriter = new BufferedWriter(fileWriter);
					while ((line = bufferedReader.readLine()) != null) {
						if (!(line.isEmpty())) {
							bufferedWriter.write(line);
							bufferedWriter.write("\n");
							delay(5);
							break;
						}
					}
					process.waitFor();
					process.destroy();
				}
			}
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e.getMessage(), e);
		}finally {
			bufferedWriter.close();
			fileWriter.close();
		}
	}

	/**
	 * Method to get the device informations such as "Manufacturer","Model","OS",
	 * "OS Version","Network","Device ID","Location".
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * @throws IOException 
	 */
	public static void getDeviceInformation(WebDriver driver) throws MobileExceptionWrapper, IOException {
		BufferedReader bufferedReader = null;
		BufferedWriter bufferedWriter = null;
		FileWriter fileWriter = null;
		String line = null;
		String deviceName = null;
		String getDeviceName = null;
		int count = 0;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}

		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			String deviceUDID = cap.getCapability("udid").toString();
			if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
					|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
				getDeviceName = ADB_S + cap.getCapability("udid") + " shell getprop ro.product.manufacturer";
			} else if (new MobileValidations().isNativeiOS(driver)) {
				getDeviceName = I_DEVICE_INFO + cap.getCapability("udid") + " -k ProductType";
			}

			Process getDeviceNameProcess = Runtime.getRuntime().exec(getDeviceName);
			bufferedReader = new BufferedReader(new InputStreamReader(getDeviceNameProcess.getInputStream()));
			line = bufferedReader.readLine();
			if ((line != null) && !(line.isEmpty())) {
				deviceName = line;
			}
			new File(new File(System.getProperty(USER_DIR)), MobileConstants.DEVICE_INFO_FOLDER).mkdirs();
			File deviceInfoFile = null;
			deviceInfoFile = new File(System.getProperty(USER_DIR) + MobileConstants.DEVICE_INFO_FOLDER
					+ "deviceInfo_" + deviceUDID + "_" + deviceName + ".txt");
			if (!deviceInfoFile.exists()) {
				deviceInfoFile.createNewFile();
			}
			if (driver != null) {
				if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
						|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
					fileWriter = new FileWriter(deviceInfoFile.getAbsoluteFile(), false);
					bufferedWriter = new BufferedWriter(fileWriter);
					for (String info : MobileConstants.DEVICE_INFO_NAME) {
						Process process = Runtime.getRuntime()
								.exec(ADB_S + cap.getCapability("udid") + " shell getprop " + info);
						bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						line = bufferedReader.readLine();
						if (!(line.isEmpty())) {
							bufferedWriter.write(MobileConstants.DEVICE_INFO[count] + " : " + line);
							bufferedWriter.write("\n");
						} else {
							bufferedWriter.write(MobileConstants.DEVICE_INFO[count] + " : " + "Not Set");
							bufferedWriter.write("\n");
						}
						count = count + 1;
						process.waitFor();
						process.destroy();
					}
					String location = getDeviceLocation(driver);
					if (location != null) {
						bufferedWriter.write(MobileConstants.DEVICE_INFO[count] + " : " + location);
					} else {
						bufferedWriter.write(MobileConstants.DEVICE_INFO[count] + " : " + "Not Set");
					}
					bufferedWriter.flush();
					bufferedWriter.close();

				} else if (new MobileValidations().isNativeiOS(driver)) {
					fileWriter = new FileWriter(deviceInfoFile.getAbsoluteFile(), false);
					bufferedWriter = new BufferedWriter(fileWriter);

					bufferedWriter.write("Manufacturer : Apple");
					bufferedWriter.write("\n");

					Process process = Runtime.getRuntime()
							.exec(I_DEVICE_INFO + cap.getCapability("udid") + " -k ProductType");
					bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					line = bufferedReader.readLine();
					if ((line != null) && !(line.isEmpty())) {
						bufferedWriter.write("Model : " + line.replace(',', '.'));
					} else {
						bufferedWriter.write("Model : Not Set");
					}
					bufferedWriter.write("\n");

					bufferedWriter.write("OS : iOS");
					bufferedWriter.write("\n");
					process = Runtime.getRuntime()
							.exec(I_DEVICE_INFO + cap.getCapability("udid") + " -k ProductVersion");
					bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					line = bufferedReader.readLine();
					if ((line != null) && !(line.isEmpty())) {
						bufferedWriter.write("OS Version : " + line);
					} else {
						bufferedWriter.write("OS Version : Not Set");
					}
					bufferedWriter.write("\n");

					process = Runtime.getRuntime()
							.exec(I_DEVICE_INFO + cap.getCapability("udid") + " -k TelephonyCapability");
					bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					line = bufferedReader.readLine();
					if ((line != null) && !(line.isEmpty())) {
						bufferedWriter.write("Network : " + line);
					} else {
						bufferedWriter.write("Network : Not Set");
					}
					bufferedWriter.write("\n");

					process = Runtime.getRuntime()
							.exec(I_DEVICE_INFO + cap.getCapability("udid") + " -k UniqueDeviceID");
					bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					line = bufferedReader.readLine();
					if ((line != null) && !(line.isEmpty())) {
						bufferedWriter.write("Device ID : " + line);
					} else {
						bufferedWriter.write("Device ID : Not Set");
					}
					bufferedWriter.write("\n");

					String location = getDeviceLocation(driver);
					if (location != null) {
						bufferedWriter.write("Location : " + location);
					} else {
						bufferedWriter.write("Location : Not Set");
					}
					bufferedWriter.write("\n");

					bufferedWriter.flush();
					bufferedWriter.close();
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}finally {
			fileWriter.close();
			bufferedWriter.close();
		}
	}

	/**
	 * Method to get the device location - Specific for mobile native Android and
	 * iOS
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param deviceUDID
	 * @return location
	 * @throws MobileExceptionWrapper
	 */

	public static String getDeviceLocation(WebDriver driver) throws MobileExceptionWrapper {
		BufferedReader bufferedReader = null;
		String line = null;
		String latLong = null;
		String location = null;
		String deviceUDID = null;

		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}

		try {
			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			deviceUDID = cap.getCapability("udid").toString();
			if (driver != null) {
				if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
						|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
					Process process = Runtime.getRuntime().exec(ADB_S + deviceUDID + " shell dumpsys location");
					bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					while (((line = bufferedReader.readLine()) != null)) {
						if (!(line.isEmpty())) {
							if (line.contains(MobileConstants.LOC_INFO)) {
								Pattern pattern = Pattern.compile(MobileConstants.LAT_LONG_REGEX);
								Matcher matcher = pattern.matcher(line);
								if (matcher.find()) {
									latLong = matcher.group(0);
								}
								break;
							}
						}
					}
					process.waitFor();
					process.destroy();
				} else if (new MobileValidations().isNativeiOS(driver)) {
					String url = "https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyAlXpwAl16WDrzgM3xLhHO1kTYWYmRX_hI";
					HttpPost request = new HttpPost(url);
					HttpClient httpClient = HttpClientBuilder.create().build();
					StringBuilder stringBuilder = new StringBuilder();
					HttpResponse response = httpClient.execute(request);
					HttpEntity entity = response.getEntity();
					InputStream stream = entity.getContent();
					int b;
					while ((b = stream.read()) != -1) {
						stringBuilder.append((char) b);
					}
					String result = stringBuilder.toString();
					JSONObject jsonObject = new JSONObject(result);
					JSONObject jsonObject2 = jsonObject.getJSONObject("location");
					System.out.println(jsonObject2.toString());
					String latitude = jsonObject2.get("lat").toString();
					String longitude = jsonObject2.get("lng").toString();
					latLong = latitude + "," + longitude;
				}
				if (latLong != null) {
					HttpGet httpGet = new HttpGet(MobileConstants.GEOCODE_URL + "?latlng="
							+ URLEncoder.encode(latLong, "UTF-8") + "&sensor=false");
					HttpClient client = HttpClientBuilder.create().build();
					HttpResponse response;
					StringBuilder stringBuilder = new StringBuilder();
					try {
						response = client.execute(httpGet);
						HttpEntity entity = response.getEntity();
						InputStream stream = entity.getContent();
						int b;
						while ((b = stream.read()) != -1) {
							stringBuilder.append((char) b);
						}
					} catch (ClientProtocolException e) {
						throw new MobileExceptionWrapper(e);
					} catch (IOException e) {
						throw new MobileExceptionWrapper(e);
					}
					String result = stringBuilder.toString();
					JSONObject jsonObject = new JSONObject(result);
					JSONObject address = (JSONObject) jsonObject.getJSONArray("results").get(0);
					location = address.getString("formatted_address");
				}
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException.getMessage(), lException);
		}
		return location;
	}

	/**
	 * Method to get device date and time - Specific for Android
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return deviceTime
	 * @throws MobileExceptionWrapper
	 */
	public static String getDeviceDate(WebDriver driver) throws MobileExceptionWrapper {
		String deviceTime = "";

		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				Capabilities cap = getCapabilities(driver);
				if (cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(MobileConstants.PLATFORM_NAME_ANDROID)
						|| cap.getCapability(PLATFORM_NAME).toString().equalsIgnoreCase(LINUX)) {
					Process process = Runtime.getRuntime()
							.exec(ADB_S + cap.getCapability("udid").toString() + " shell date +%s");
					BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					int read;
					char[] buffer = new char[4096];
					StringBuffer output = new StringBuffer();
					while ((read = reader.read(buffer)) > 0) {
						output.append(buffer, 0, read);
					}
					reader.close();
					process.waitFor();
					if (output.toString() != null || output.toString().length() != 0) {
						long time = Long.parseLong(output.toString().trim());
						Date date = new Date(time * 1000);
						DateFormat df = new SimpleDateFormat("EEEE dd MMM yyyy hh:mm:ss zzz");
						deviceTime = df.format(date).toString();
					}
				}
			}
		} catch (Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}
		return deviceTime;
	}

	/**
	 * 
	 * Method to get the count of items available in the list based on the class
	 * name
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param className
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static int getCountOfListItems(WebDriver driver, String className) throws MobileExceptionWrapper {
		int numberOfItems;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			List<WebElement> elements = driver.findElements(By.className(className));
			numberOfItems = elements.size();
			if (numberOfItems == 0) {
				System.out.println("No items found in the list");
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return numberOfItems;
	}

	/**
	 * Method to get device screen orientation - specific for native applications
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static String getScreenOrientation(WebDriver driver) throws MobileExceptionWrapper {
		String orientationValue = null;
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (new MobileValidations().isNativeiOS(driver)) {
				orientationValue = ((IOSDriver) driver).getOrientation().toString();
			}
			if (new MobileValidations().isNativeAndroid(driver)) {
				orientationValue = ((AndroidDriver) driver).getOrientation().toString();
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return orientationValue;
	}

	/**
	 * Method to swipe up from the bottom edge of any iOS device to open control
	 * center
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */
	public static void openIOSControlCenter(WebDriver driver) throws MobileExceptionWrapper {
		try {
			Dimension size = driver.manage().window().getSize();
			int starty = (int) (size.height);
			int endy = (int) (size.height * 0.10);
			int startx = size.width / 2;
			Point source = new Point(startx, starty);
			PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
			Sequence seq = new Sequence(finger, 1);
			seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
					source.getX() / 2, source.getY() + 900));
			seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
			seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
					source.getX() / 2, endy));
			seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
			((RemoteWebDriver) driver).perform(Arrays.asList(seq));
			delay(2);
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to swipe down to close control center in iOS devices
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @modified 13-03-2023
	 * @param driver
	 * @throws MobileExceptionWrapper
	 */
	public static void closeIOSControlCenter(WebDriver driver) throws MobileExceptionWrapper {
		try {
			Dimension size = driver.manage().window().getSize();
			int starty = (int) (size.height * 0.10);
			int endy = (int) (size.height);
			int startx = size.width / 2;
			Point source = new Point(startx, starty);
			PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, FINGER);
			Sequence seq = new Sequence(finger, 1);
			seq.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(),
					source.getX() / 2, source.getY() / 2));
			seq.addAction(finger.createPointerDown(PointerInput.MouseButton.MIDDLE.asArg()));
			seq.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(),
					source.getX() / 2, endy));
			seq.addAction(finger.createPointerUp(PointerInput.MouseButton.MIDDLE.asArg()));
			((RemoteWebDriver) driver).perform(Arrays.asList(seq));
			delay(2);
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to mock GPS location of a device to the given latitude and longitude -
	 * Implemented for native android application
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param latitude
	 * @param longitude
	 * @throws MobileExceptionWrapper
	 */

	public static void mockLocation(WebDriver driver, String latitude, String longitude) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		if (latitude != null && longitude != null) {
			try {
				// ClassLoader classLoader = getClass().getClassLoader();
				File apkFilePath = new File(
						MobileUtils.class.getResource(MobileConstants.LOCATION_SPOOFING_APK).getFile());
				Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
				installApp(driver, apkFilePath.toString());
				startApplication(driver, MobileConstants.LOCATION_SPOOF_PACKAGE,
						MobileConstants.LOCATION_SPOOF_ACTIVITY);
				navigateToBack(driver);
				Process process = Runtime.getRuntime()
						.exec(ADB_S + cap.getCapability("udid").toString() + " shell am broadcast -a "
								+ MobileConstants.LOCATION_SPOOF_ACTION + " -e lat " + latitude + " -e lon "
								+ longitude);
				process.waitFor();
				process.destroy();
			} catch (Exception e) {
				throw new MobileExceptionWrapper(e);
			}
		}
	}

	/**
	 * Helps to retrieve and return the capability details
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @return
	 */
	public static Capabilities getCapabilities(final WebDriver driver) {
		final Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
		return cap;
	}

	/**
	 * 
	 * This method used to navigate to previous page (in Android Native and Mobile
	 * Web)
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void navigateToBack(final WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				driver.navigate().back();
			}
		} catch (final Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * 
	 * This method used to navigate to next page (this method for Mobile Web)
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void navigateForward(final WebDriver driver) throws MobileExceptionWrapper {
		try {
			if (driver == null || driver.equals("")) {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (Exception e) {
			e = new Exception(MobileConstants.DRIVER_MISSING);
			throw new MobileExceptionWrapper(e);
		}
		try {
			if (driver != null) {
				driver.navigate().forward();
			}
		} catch (final Exception lException) {
			lException.printStackTrace();
			throw new MobileExceptionWrapper(lException);
		}

	}

	/**
	 * Method to wait for the element using the object mentioned in the Object
	 * Repository
	 * 
	 * @author sanoj.swaminathan
	 * @modified sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param elementName
	 * @return element
	 * @throws MobileExceptionWrapper
	 */
	public static WebElement waitForElementPresent(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		WebElement element = null;
		try {
			long timeout = Long.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
			element = driverwait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
			((JavascriptExecutor) driver)
					.executeScript(WINDOW_SCROLL_TO + element.getLocation().x + "," + element.getLocation().y + ")");
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + elementName);
		}
		return element;
	}

	/**
	 * Method to wait for the elements using the object mentioned in the Object
	 * Repository
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param elementName
	 * @return elements
	 * @throws MobileExceptionWrapper
	 */
	public static List<WebElement> waitForElementsPresent(WebDriver driver, String elementName)
			throws MobileExceptionWrapper {
		List<WebElement> elements;
		try {
			if (elementName != null) {
				long timeout = Long
						.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
				driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
				By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
				driverwait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				elements = driver.findElements(actualElement);
			} else
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + elementName);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + elementName);
		}
		return elements;
	}

	/**
	 * Method to wait for the element using the By locator
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param elementLocator
	 * @return element
	 * @throws MobileExceptionWrapper
	 */
	public static WebElement waitForElementPresent(WebDriver driver, By elementLocator) throws MobileExceptionWrapper {
		WebElement element = null;
		try {
			long timeout = Long.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			element = driverwait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + elementLocator);
		}
		return element;
	}

	/**
	 * Method to wait for element to be visible
	 * 
	 * @author sanojs
	 * @since 02-03-2023
	 * @param driver
	 * @param elementName
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static WebElement waitForElement(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		WebElement element = null;
		try {
			long timeout = Long.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
			element = driverwait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			if (new MobileValidations().isMobileWeb(driver)) {
				((JavascriptExecutor) driver).executeScript(
						WINDOW_SCROLL_TO + element.getLocation().x + "," + element.getLocation().y + ")");
			}
		} catch (Exception e) {
			try {
				long timeout = Long
						.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
				driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
				By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
				element = driverwait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				if (new MobileValidations().isMobileWeb(driver)) {
					((JavascriptExecutor) driver).executeScript(
							WINDOW_SCROLL_TO + element.getLocation().x + "," + element.getLocation().y + ")");
				}
			} catch (Exception exe) {

			}
		}
		return element;
	}

	/**
	 * Method to wait for the element using the object mentioned in the object
	 * repository
	 * 
	 * @author sanojs
	 * @since 15-06-2023
	 * @param driver
	 * @param elementName
	 * @param waitTime
	 * @return element
	 * @throws MobileExceptionWrapper
	 */
	public static WebElement waitForElement(WebDriver driver, String elementName, long waitTime)
			throws MobileExceptionWrapper {
		WebElement element = null;
		try {
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(waitTime));
			By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
			element = driverwait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			((JavascriptExecutor) driver)
					.executeScript(WINDOW_SCROLL_TO + element.getLocation().x + "," + element.getLocation().y + ")");
		} catch (Exception e) {
			try {
				long timeout = Long
						.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
				driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
				By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
				element = driverwait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				((JavascriptExecutor) driver).executeScript(
						WINDOW_SCROLL_TO + element.getLocation().x + "," + element.getLocation().y + ")");

			} catch (Exception exe) {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + elementName);
			}
		}
		return element;
	}

	/**
	 * Method to wait for elements to be visible
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param driver
	 * @param elementName
	 * @return elements
	 * @throws MobileExceptionWrapper
	 */
	public static List<WebElement> waitForElements(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		List<WebElement> elements;
		try {
			long timeout = Long.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
			driverwait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			elements = driver.findElements(actualElement);
		} catch (Exception e) {
			try {
				long timeout = Long
						.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
				driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
				By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
				driverwait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				elements = driver.findElements(actualElement);
			} catch (Exception exe) {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + elementName);
			}
		}
		return elements;
	}

	/**
	 * Method to wait for the element to be visible using the By locator
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param driver
	 * @param elementLocator
	 * @return element
	 * @throws MobileExceptionWrapper
	 */
	public static boolean waitForElement(WebDriver driver, By elementLocator) throws MobileExceptionWrapper {
		boolean isElementVisible = false;
		try {
			long timeout = Long.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			driverwait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
			isElementVisible = true;
		} catch (Exception e) {
			try {
				long timeout = Long
						.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
				driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
				driverwait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
				isElementVisible = true;
			} catch (Exception ex) {
				throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + elementLocator);
			}
		}
		return isElementVisible;
	}

	/**
	 * Method to Wait for the element to get Visible
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param elementLocator
	 * @return isElementVisible
	 * @throws MobileExceptionWrapper
	 */
	public static boolean waitForElementVisible(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		boolean isElementVisible = false;
		try {
			long timeout = Long.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
			driverwait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));

			isElementVisible = true;
		} catch (Exception e) {
			isElementVisible = false;
		}
		return isElementVisible;
	}

	/**
	 * Method to Wait for the element to get Invisible
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param elementKey
	 * @return isElementInVisible
	 * @throws MobileExceptionWrapper
	 */
	public static boolean waitForElementInVisible(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		boolean isElementInVisible = false;
		try {
			long timeout = Long.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
			isElementInVisible = driverwait.until(ExpectedConditions.invisibilityOfElementLocated(actualElement));
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
		return isElementInVisible;
	}

	/**
	 * Method to Wait for the element's text to be present
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param elementKey
	 * @return element
	 * @throws MobileExceptionWrapper
	 */
	public static boolean waitForTextPresent(WebDriver driver, String elementName, String expectedText)
			throws MobileExceptionWrapper {
		boolean isTextPresent = false;
		try {
			long timeout = Long.parseLong(DataHandler.getProperty(MobileConstants.FRAMEWORK_CONFIG, SHORT_LOADING));
			driverwait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			By actualElement = new ObjectRepositoryHandler().getObject(elementName, driver);
			isTextPresent = driverwait.until(ExpectedConditions.textToBePresentInElementLocated(actualElement, expectedText));
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
		return isTextPresent;
	}

	/**
	 * Method to wait for the checkbox selected
	 * 
	 * @author sanoj.swaminathan
	 * @since 05/18/2021
	 * @param driver
	 * @param elementName
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static boolean waitForCheckboxSelected(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		boolean isCheckboxSelected = false;
		try {
			if (driver != null) {
				WebElement element = waitForElement(driver, elementName);
				if (element != null) {
					if (element.getAttribute("checked") != null) {
						if (element.getAttribute("checked").equals("true")) {
							isCheckboxSelected = true;
						}
					} else {
						isCheckboxSelected = false;
					}
				}
			}
		} catch (Exception e) {
			isCheckboxSelected = false;
		}
		return isCheckboxSelected;
	}

	/**
	 * Get the web element based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction
	 * @param element
	 * @return
	 * @throws MobileExceptionWrapper
	 */
	public static WebElement getRelativeElement(WebDriver driver, String tagName, String direction, WebElement element)
			throws MobileExceptionWrapper {
		WebElement elementToDoAction = null;
		try {
			switch (direction) {
			case "left":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).toLeftOf(element));
				break;
			case "right":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).toRightOf(element));
				break;
			case "above":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).above(element));
				break;
			case "below":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).below(element));
				break;
			case "near":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).near(element));
				break;
			
			default :
				break;
			}
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
		return elementToDoAction;
	}

	/**
	 * Set delay between test steps
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2021
	 * @param driver
	 * @param delayInSeconds
	 * @throws MobileExceptionWrapper
	 */
	public static void delay(int delayInSeconds) throws MobileExceptionWrapper {
		try {
			Thread.sleep(delayInSeconds * 1000);
		} catch (Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to drag and drop an element from source to destination
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param sourceElementName
	 * @param destinationElementName
	 * @return element
	 * @throws MobileExceptionWrapper
	 */
	public static void dragAndDrop(WebDriver driver, String sourceElementName, String destinationElementName)
			throws MobileExceptionWrapper {
		try {
			WebElement sourceElement = waitForElement(driver, sourceElementName);
			WebElement destinationElement = waitForElement(driver, destinationElementName);
			Actions action = new Actions(driver);
			action.clickAndHold(sourceElement).build().perform();
			delay(1);
			action.moveToElement(destinationElement).build().perform();
			delay(1);
			action.moveByOffset(-1, -1).build().perform();
			delay(1);
			action.release().build().perform();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to scroll to the element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void scrollToElement(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		try {
			WebElement element = waitForElement(driver, elementName);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to move to the Web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void moveToElement(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		try {
			Actions actions = new Actions(driver);
			WebElement element = waitForElement(driver, elementName);
			actions.moveToElement(element).perform();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to move to the Web element based on the provided X and Y co-ordinates
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param xOffset
	 * @param yOffset
	 * @throws MobileExceptionWrapper
	 */
	public static void moveToElementByXandY(WebDriver driver, String elementName, int xOffset, int yOffset)
			throws MobileExceptionWrapper {
		try {
			Actions actions = new Actions(driver);
			WebElement element = waitForElement(driver, elementName);
			actions.moveToElement(element, xOffset, yOffset).perform();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get the attribute value of the web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param attributeName
	 * @throws MobileExceptionWrapper
	 */
	public static String getElementAttributeValue(WebDriver driver, String elementName, String attributeName)
			throws MobileExceptionWrapper {
		String elementAttribute = "";
		try {
			WebElement element = waitForElement(driver, elementName);
			elementAttribute = element.getAttribute(attributeName);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
		return elementAttribute;
	}

	/**
	 * Method to select the value from the drop down using the visible text
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param visibleText
	 * @throws MobileExceptionWrapper
	 */
	public static void selectDropDownValueByVisibleText(WebDriver driver, String elementName, String visibleText)
			throws MobileExceptionWrapper {
		try {
			Select select = new Select(waitForElement(driver, elementName));
			select.selectByVisibleText(visibleText);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to select the value from the drop down using the index
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param index
	 * @throws MobileExceptionWrapper
	 */
	public static void selectDropDownValueByIndex(WebDriver driver, String elementName, int index)
			throws MobileExceptionWrapper {
		try {
			Select select = new Select(waitForElement(driver, elementName));
			select.selectByIndex(index);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to select the value from the drop down using value
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param valueToSelect
	 * @throws MobileExceptionWrapper
	 */
	public static void selectDropDownValueByValue(WebDriver driver, String elementName, String valueToSelect)
			throws MobileExceptionWrapper {
		try {
			Select select = new Select(waitForElement(driver, elementName));
			select.selectByValue(valueToSelect);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method deselect the selected value from the dropdown based on index passed
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param index
	 * @throws MobileExceptionWrapper
	 * 
	 */
	public static void deselectElementByIndex(final WebDriver driver, final String elementName, final int index)
			throws MobileExceptionWrapper {
		try {
			if (driver != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (element != null) {
					final Select listbox = new Select(element);
					listbox.deselectByIndex(index);
				} else {
					throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method deselect the selected value from the dropdown based on Value passed
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param value
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void deselectElementByValue(final WebDriver driver, final String elementName, final String value)
			throws MobileExceptionWrapper {
		try {
			if (driver != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (element != null) {
					final Select listbox = new Select(element);
					listbox.deselectByValue(value);
				} else {
					throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method deselect the selected value from the dropdown based on visible text
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param visibleText
	 * @throws MobileExceptionWrapper
	 * 
	 */

	public static void deselectElementByVisibleText(final WebDriver driver, final String elementName,
			final String visibleText) throws MobileExceptionWrapper {
		try {
			if (driver != null) {
				WebElement element = new ObjectRepositoryHandler().getObject(driver, elementName);
				if (element != null) {
					final Select listbox = new Select(element);
					listbox.deselectByVisibleText(visibleText);
				} else {
					throw new MobileExceptionWrapper(MobileConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			} else {
				throw new MobileExceptionWrapper(MobileConstants.DRIVER_MISSING);
			}
		} catch (final Exception lException) {
			throw new MobileExceptionWrapper(lException);
		}
	}

	/**
	 * Method to get the X co-ordinate of the Web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static int getXcoordinate(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		try {
			WebElement element = waitForElement(driver, elementName);
			Point point = element.getLocation();
			return point.getX();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get the Y co-ordinate of the Web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static int getYcoordinate(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		try {
			WebElement element = waitForElement(driver, elementName);
			Point point = element.getLocation();
			return point.getY();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get the Count of the elements from the Web element list
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static int countOfElementsFromList(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		try {
			List<WebElement> elements = waitForElements(driver, elementName);
			return elements.size();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to clear the input field (which is referred by the user from the
	 * Object Repository)
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void clearInputField(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		try {
			WebElement element = waitForElement(driver, elementName);
			element.clear();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to delete the value from input field (which is referred by the user
	 * from the Object Repository)
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static void clearAllFromInputField(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		try {
			WebElement sourceElement = waitForElement(driver, elementName);
			sourceElement.sendKeys(Keys.CONTROL + "a");
			sourceElement.sendKeys(Keys.DELETE);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to Copy and Paste the value from one input field to another input
	 * field
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param sourceElementName
	 * @param destinationElementName
	 * @throws MobileExceptionWrapper
	 */
	public static void copyAndPasteFromOneInputFieldToAnother(WebDriver driver, String sourceElementName,
			String destinationElementName) throws MobileExceptionWrapper {
		try {
			WebElement sourceElement = waitForElement(driver, sourceElementName);
			sourceElement.sendKeys(Keys.CONTROL + "a");
			sourceElement.sendKeys(Keys.CONTROL + "c");

			WebElement destinationElement = waitForElement(driver, destinationElementName);
			destinationElement.clear();
			destinationElement.sendKeys(Keys.CONTROL + "v");
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get the text of the Web Element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws MobileExceptionWrapper
	 */
	public static String getElementText(WebDriver driver, String elementName) throws MobileExceptionWrapper {
		String elementText = "";
		try {
			WebElement element = waitForElement(driver, elementName);
			elementText = element.getText();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
		return elementText;
	}

	/**
	 * Capture the screenshot of the current screen and store into Screenshots
	 * folder in the project structure
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 */
	public static String captureScreenshot(WebDriver driver, String fileName) throws MobileExceptionWrapper {
		String destinationFilePath = null;
		try {
			TakesScreenshot screenShot = ((TakesScreenshot) driver);
			File sourceFile = screenShot.getScreenshotAs(OutputType.FILE);
			destinationFilePath = System.getProperty(USER_DIR) + "/Screenshots/" + fileName + "_" + getCurrentDate()
					+ ".jpg";
			File destinationFile = new File(destinationFilePath);
			FileUtils.copyFile(sourceFile, destinationFile);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e);
		}
		return destinationFilePath;
	}

	/**
	 * Capture the screenshot of the current screen
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2021
	 * @param driver
	 * @throws MobileExceptionWrapper
	 */
	public static String captureScreenshot(WebDriver driver) throws MobileExceptionWrapper {
		File sourceFile = null;
		try {

			Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
			if (new MobileValidations().isNativeAndroid(driver)) {
				delay(2);
				Process process = Runtime.getRuntime()
						.exec(ADB_S + cap.getCapability("udid").toString() + " shell input keyevent 27");
				process.waitFor();
				process.destroy();
			} else if (new MobileValidations().isNativeiOS(driver)) {
				driver.findElement(By.name("Take Picture")).click();
			} else {
				TakesScreenshot screenShot = ((TakesScreenshot) driver);
				sourceFile = screenShot.getScreenshotAs(OutputType.FILE);
			}
		} catch (Exception e) {
			throw new MobileExceptionWrapper(e);
		}
		return sourceFile.getAbsolutePath();
	}

	/**
	 * Method to get a random number between the two ranges
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param lowerBound
	 * @param upperBound
	 * @throws MobileExceptionWrapper
	 */
	public static int getRandomNumber(int lowerBound, int upperBound) throws MobileExceptionWrapper {
		try {
			random = new Random();
			int randomNum = random.nextInt(upperBound - lowerBound + 1) + lowerBound;
			return randomNum;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get a random number with the a number length mentioned
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param numberLength
	 * @throws MobileExceptionWrapper
	 */
	public static String getRandomNumber(int numberLength) throws MobileExceptionWrapper {
		try {
			random = new Random();
			int randomNum = 0;
			boolean loop = true;
			while (loop) {
				randomNum = random.nextInt();
				if (Integer.toString(randomNum).length() == numberLength
						&& !Integer.toString(randomNum).startsWith("-")) {
					loop = false;
				}
			}
			String randomNumber = Integer.toString(randomNum);
			return randomNumber;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get a random string value with the string length mentioned
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stringLength
	 * @throws MobileExceptionWrapper
	 */
	public static String getRandomString(int stringLength) throws MobileExceptionWrapper {
		try {
			String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
			StringBuilder sb = new StringBuilder(stringLength);
			for (int i = 0; i < stringLength; i++) {
				int index = (int) (AlphaNumericString.length() * Math.random());
				sb.append(AlphaNumericString.charAt(index));
			}
			return sb.toString();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get a random string which has only alphabets with the string length
	 * mentioned
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stringLength
	 * @throws MobileExceptionWrapper
	 */
	public static String getRandomStringOnlyAlphabets(int stringLength) throws MobileExceptionWrapper {
		try {
			String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvxyz";
			StringBuilder sb = new StringBuilder(stringLength);
			for (int i = 0; i < stringLength; i++) {
				int index = (int) (AlphaNumericString.length() * Math.random());
				sb.append(AlphaNumericString.charAt(index));
			}
			return sb.toString();
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get the current date
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws MobileExceptionWrapper
	 */
	public static String getCurrentDate() throws MobileExceptionWrapper {
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy_HH-mm-ss");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			return filePathdate;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get the current date in the date format ddMMMyyyy
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws MobileExceptionWrapper
	 */
	public static String getCurrentDateInFormatddMMMyyyy() throws MobileExceptionWrapper {
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			return filePathdate;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get a current date in the date format ddMMyyyy
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws MobileExceptionWrapper
	 */
	public static String getCurrentDateInFormatddMMyyyy() throws MobileExceptionWrapper {
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			return filePathdate;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to get the day from the current date
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws MobileExceptionWrapper
	 */
	public static String getDayFromCurrentDate() throws MobileExceptionWrapper {
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy_HH-mm-ss");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			String day = filePathdate.substring(0, 2);
			return day;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to convert a double value to an Integer
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param doubleValue
	 * @throws MobileExceptionWrapper
	 */
	public static int convertDoubleToInt(double doubleValue) throws MobileExceptionWrapper {
		try {
			int intValue = (int) doubleValue;
			return intValue;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to convert a float value to an Integer
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param floatValue
	 * @throws MobileExceptionWrapper
	 */
	public static int convertFloatToInt(float floatValue) throws MobileExceptionWrapper {
		try {
			int intValue = (int) floatValue;
			return intValue;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to convert a string value to an Integer
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stringValue
	 * @throws MobileExceptionWrapper
	 */
	public static int convertStringToInt(String stringValue) throws MobileExceptionWrapper {
		try {
			int intValue = Integer.parseInt(stringValue);
			return intValue;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to convert a string value to a double value
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stringValue
	 * @throws MobileExceptionWrapper
	 */
	public static double convertStringToDouble(String stringValue) throws MobileExceptionWrapper {
		try {
			double doubleValue = Double.parseDouble(stringValue);
			return doubleValue;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to convert an Integer to a string value
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param intValue
	 * @throws MobileExceptionWrapper
	 */
	public static String convertIntToString(int intValue) throws MobileExceptionWrapper {
		try {
			String stringValue = String.valueOf(intValue);
			return stringValue;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to convert a double value to a string value
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param doubleValue
	 * @throws MobileExceptionWrapper
	 */
	public static String convertDoubleToString(double doubleValue) throws MobileExceptionWrapper {
		try {
			String stringValue = String.valueOf(doubleValue);
			return stringValue;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to convert a string value to a long value
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param doubleValue
	 * @throws MobileExceptionWrapper
	 */
	public static long convertStringToLong(String stringValue) throws MobileExceptionWrapper {
		try {
			long longValue = Long.parseLong(stringValue);
			return longValue;
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
	}

	/**
	 * Method to encode any file data
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-03-2023
	 * @param filePath
	 * @throws MobileExceptionWrapper
	 */
	public static String encodeFile(String filePath) throws MobileExceptionWrapper {
		String encodedString = null;
		try {
			byte[] fileContent = FileUtils.readFileToByteArray(new File(filePath));
			encodedString = Base64.getEncoder().encodeToString(fileContent);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
		return encodedString;
	}

	/**
	 * Method to decode any string data
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-03-2023
	 * @param dataToBeDecoded
	 * @throws MobileExceptionWrapper
	 */
	public static String decodeString(String dataToBeDecoded) throws MobileExceptionWrapper {
		byte[] decodedString = null;
		try {
			decodedString = Base64.getDecoder().decode(dataToBeDecoded);
		} catch (Exception e) {
			throw new MobileExceptionWrapper(MobileConstants.CAUSE + e.getMessage());
		}
		return decodedString.toString();
	}

	/**
	 * Method to delete file
	 * 
	 * @author sanoj.swaminathan
	 * @since 21-03-2023
	 * @param filePath
	 */
	public static void deleteFile(String filePath) {
		try {
			FileUtils.forceDelete(new File(filePath));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
