package com.aspire.utils.api;

import java.util.Map;

import com.aspire.utils.Log;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class APIUtil {

	
	private static final String STATUS_CODE = "Status Code: ";
	private static final String RESPONSE_BODY = "Response body: \n";
	private static final String TIME_TAKEN_TO_GET_RESPONSE = "Time taken to get response is: \n";
	private static final String MILLI_SECOND = " milli second";
	private static final String MILLI_SECONDS_N= " milli second\n";
	private static final String RUNNING_GET_COMMAND= "running GET command";
	private static final String URL= "URL: \n";
	
	
	
	
	
	/**
	 * setBaseURL method sets baseURL
	 * 
	 * @param baseURL
	 */
	public static void setBaseURL(String baseURL) {

		Log.event("Setting base URL as:" + baseURL + "\n");
		try {
			if (!baseURL.isEmpty() || !baseURL.contains(null)) {
				RestAssured.baseURI = baseURL;
			}
		} catch (NullPointerException e) {
			Log.event("Base URL is set as null");
		}
	}

	/**
	 * Returns response of GET API method execution
	 * 
	 * @param baseURL
	 * @param endpoint
	 * @return Response of GET command
	 */
	public static Response get(String baseURL, String endpoint) {
		setBaseURL(baseURL);

		Log.event("Endpoint: " + endpoint + "\n");
		Response resp = RestAssured.given().get(endpoint);

		Log.event(STATUS_CODE + resp.getStatusCode() + "\n");
		Log.event(RESPONSE_BODY + resp.asString() + "\n");
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECOND);

		return resp;
	}

	/**
	 * Returns response of GET API method execution
	 * 
	 * @param baseURL
	 * @param username
	 * @param password
	 * @param contentType
	 * @param url
	 * @return Response of GET command
	 */
	public static Response get(String baseURL, String username, String password, String contentType, String url) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().auth().preemptive().basic(username, password).get(url);

		return resp;
	}

	/**
	 * Returns response of GET API method execution
	 * 
	 * @param baseURL
	 * @param headers
	 * @param username
	 * @param password
	 * @param contentType
	 * @param url
	 * @return Response of GET command
	 */
	public static Response get(String baseURL, Map<String, String> headers, String username, String password,
			String contentType, String url) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().auth().basic(username, password).headers(headers).contentType(contentType)
				.get(url);

		Log.event("GET Command URL:" + url + "\n");
		Log.event("Request Headers: \n" + headers.toString() + "\n");
		Log.event(RESPONSE_BODY + resp.asString() + "\n");
		Log.event(STATUS_CODE + resp.getStatusCode() + "\n");
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECONDS_N);
		return resp;
	}

	/**
	 * Returns response of GET API method execution based on provided query
	 * parameters
	 * 
	 * @param baseURL
	 * @param headers
	 * @param queryParam
	 * @param contentTypeJson
	 * @param body
	 * @param url
	 * @return
	 */
	public static Response getWithQuerryParam(String baseURL, Map<String, String> headers,
			Map<String, String> queryParam, String url) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().params(queryParam).headers(headers).get(url);
		RestAssured.given().params(queryParam).headers(headers).get(url);
		Log.event(RUNNING_GET_COMMAND);
		Log.event(URL + url + "\n");
		Log.event("Header: \n" + resp.getHeaders().toString() + "\n");
		Log.event(RESPONSE_BODY + resp.asString() + "\n");
		Log.event("Status Code: \n" + resp.getStatusCode() + "\n");
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECONDS_N);
		return resp;
	}

	/**
	 * To get using basic Auth
	 * 
	 * @param baseURL
	 * @param headers
	 * @param queryParam
	 * @param endPoint
	 * @param username
	 * @param password
	 * @return
	 */
	public static Response getWithBasicAuth(String baseURL, Map<String, String> headers, Map<String, String> queryParam,
			String endPoint, String username, String password) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().auth().preemptive().basic(username, password).params(queryParam)
				.headers(headers).get(endPoint);
		return resp;
	}

	/**
	 * Returns response of POST API method execution
	 * 
	 * @param headerKey
	 * @param headerValue
	 * @param contentTypeJson
	 * @param body
	 * @param url
	 * @return Response of POST command
	 */
	public static Response post(String baseURL, Map<String, String> headers, String username, String password,
			String body, String url) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().auth().basic(username, password).headers(headers).body(body).post(url)
				.andReturn();
		Log.event("running POST command");
		Log.event("URL \n" + url);
		Log.event("Header \n" + resp.getHeaders().toString());
		Log.event("Response body \n" + resp.getBody().asString());
		Log.event("Status Code \n" + resp.getStatusCode());
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECOND);
		return resp;
	}

	/**
	 * Returns response of POST API method execution
	 * 
	 * @param baseURL
	 * @param headers
	 * @param body
	 * @return Response of POST command
	 */
	/**
	 * Returns response of POST API method execution
	 * 
	 * @param baseURL
	 * @param headers
	 * @param body
	 * @return
	 */
	public static Response postWithBody(String baseURL, Map<String, String> headers, String body, String endpoint) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().headers(headers).body(body).post(endpoint).andReturn();
		Log.event("running POST command");
		Log.event(baseURL);
		Log.event("Header \n" + resp.getHeaders().toString());
		Log.event("Response body \n" + resp.asString());
		Log.event("Status Code \n" + resp.getStatusCode());
		return resp;
	}

	/**
	 * Returns response of POST API method execution
	 * 
	 * @param headerKey
	 * @param body
	 * @param url
	 * @return Response of POST command
	 */
	public static Response postWithoutBody(String baseURL, Map<String, String> headers) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().headers(headers).post().andReturn();
		Log.event("Running POST command...");
		Log.event(baseURL);
		Log.event("Header \n" + resp.getHeaders().toString());
		Log.event("Response body \n" + resp.asString());
		Log.event("Status Code Received: " + resp.getStatusCode());
		return resp;
	}

	/**
	 * Returns response of PUT API method execution based on query parameters
	 * 
	 * @param headers
	 * @param url
	 * @return
	 */
	public static Response putWithoutBody(String baseURL, Map<String, String> headers) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().headers(headers).put().andReturn();
		Log.event("running PUT command");
		Log.event("Header \n" + resp.getHeaders().toString());
		Log.event("Response body \n" + resp.asString());
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECOND);

		return resp;

	}

	/**
	 * Returns response of PUT API method execution
	 * 
	 * @param headerKey
	 * @param headerValue
	 * @param contentTypeJson
	 * @param body
	 * @param url
	 * @return Response of PUT command
	 */
	public static Response putWithBody(String baseURL, Map<String, String> headers, String body, String url) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().headers(headers).body(body).put(url).andReturn();
		Log.event("running PUT command");
		Log.event("URL \n" + url);
		Log.event("Header \n" + resp.getHeaders().toString());
		Log.event("Response body \n" + resp.asString());
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECOND);

		return resp;

	}

	/**
	 * Returns response of PUT API method execution based on path parameters
	 * 
	 * @param baseURL
	 * @param headers
	 * @param inputData
	 * @param contentTypeJson
	 * @param body
	 * @param url
	 * @return
	 */

	public static Response putWithPathParams(String baseURL, Map<String, String> headers, Map<String, String> inputData,
			String body, String url) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().headers(headers).pathParams(inputData).body(body).put(url).andReturn();
		Log.event("running PUT command");
		Log.event("URL \n" + baseURL);
		Log.event("Header \n" + resp.getHeaders().toString());
		Log.event("Response body \n" + resp.asString());
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECOND);

		return resp;

	}

	/**
	 * Returns response of DELETE API method execution
	 * 
	 * @param headerKey
	 * @param headerValue
	 * @param body
	 * @param url
	 * @return Response of DELETE command
	 */
	public static Response delete(String baseURL, Map<String, String> headers, String username, String password,
			String url) {
		setBaseURL(baseURL);
		Log.event("running DELETE command");

		Log.event("Endpoint: " + url + "\n");
		Log.event("Request Headers: \n" + headers.toString() + "\n");
		Log.event("Username&Password : \n" + username + "||" + password + "\n");

		Response resp = RestAssured.given().headers(headers).delete(url);

		Log.event(RESPONSE_BODY + resp.asString() + "\n");
		Log.event(STATUS_CODE + resp.getStatusCode() + "\n");
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECOND);

		return resp;

	}

	public static Response deleteWithQuerryParams(String baseURL, Map<String, String> headers, String inputpara,
			String contentType, String url) {
		setBaseURL(baseURL);
		Response resp = RestAssured.given().headers(headers).queryParam(inputpara).contentType(contentType).delete(url);

		Log.event("running Delete command");
		Log.event(URL + url + "\n");
		Log.event("Header: \n" + resp.getHeaders().toString() + "\n");
		Log.event(RESPONSE_BODY + resp.asString() + "\n");
		Log.event("Status Code: \n" + resp.getStatusCode() + "\n");
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECONDS_N);
		return resp;
	}

	/**
	 * Standard DELETE
	 * 
	 * @param baseUrl
	 * @param headers
	 * @param path     parameter
	 * @param endpoint
	 */
	public static Response deleteWithPathParams(String baseURL, Map<String, String> headers,
			Map<String, String> pathParams, String endpoint) {
		Response resp = RestAssured.given().baseUri(baseURL).headers(headers).pathParams(pathParams).delete(endpoint);
		Log.event(RUNNING_GET_COMMAND);
		Log.event(URL + baseURL + "\n");
		Log.event("Header: \n" + resp.getHeaders().toString() + "\n");
		if (resp.getStatusCode() != 404) {
			Log.event(RESPONSE_BODY + resp.asString() + "\n");
		}
		Log.event("Status Code: \n" + resp.getStatusCode() + "\n");
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECONDS_N);

		return resp;
	}

	/**
	 * Standard DELETE
	 * 
	 * @param baseUrl
	 * @param headers
	 * @param path     parameter
	 * @param query    parameter
	 * @param endpoint
	 */
	public static Response deleteWithQuerryAndPathParams(String baseURL, Map<String, String> headers,
			Map<String, String> queryParams, Map<String, String> pathParams, String endpoint) {
		Response resp = RestAssured.given().baseUri(baseURL).headers(headers).params(queryParams).pathParams(pathParams)
				.delete(endpoint);
		Log.event(RUNNING_GET_COMMAND);
		Log.event(URL + baseURL + "\n");
		Log.event("Header: \n" + resp.getHeaders().toString() + "\n");
		Log.event(RESPONSE_BODY + resp.asString() + "\n");
		Log.event("Status Code: \n" + resp.getStatusCode() + "\n");
		Log.event(TIME_TAKEN_TO_GET_RESPONSE + resp.getTime() + MILLI_SECONDS_N);
		return resp;
	}
}