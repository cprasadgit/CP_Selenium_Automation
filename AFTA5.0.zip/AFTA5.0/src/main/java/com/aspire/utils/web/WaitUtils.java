package com.aspire.utils.web;

import java.time.Duration;
import java.util.List;

import org.apache.commons.lang3.BooleanUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aspire.utils.IPropertiesReader;
import com.aspire.utils.Log;
import com.aspire.utils.PropertiesReaderUtil;
import com.aspire.utils.StopWatch;
import com.epam.healenium.SelfHealingDriver;

public class WaitUtils {

	private static String EXPECTED_TEXT = "Expected text ";
	private static String ELEMENT_DISPLAYING =" element is displaying";
	private static String ELEMENT_NOT_DISPLAY = " element is not displayed";
	
	private static IPropertiesReader propertyReader = PropertiesReaderUtil.getInstance();

	public static ExpectedCondition<Boolean> pageLoad;
	public static String queryString = "return (document.readyState != 'complete' || document.styleSheets.length  == 0)";

	static {
		pageLoad = currentDriver -> BooleanUtils
				.isNotTrue((Boolean) ((JavascriptExecutor) currentDriver).executeScript(queryString));
	}

	/**
	 * waitForPageLoad waits for the page load with custom page load wait time
	 *
	 */
	public static void waitForPageLoad(final SelfHealingDriver driver, int maxWait) {
		long startTime = StopWatch.startTime();
		FluentWait<WebDriver> wait = new WebDriverWait(driver, Duration.ofSeconds(maxWait))
				.ignoring(StaleElementReferenceException.class, WebDriverException.class)
				.pollingEvery(Duration.ofMillis(500)).withMessage("Page Load Timed Out");
		try {
			wait.until(pageLoad);
			String title = driver.getTitle().toLowerCase();
			String url = driver.getCurrentUrl().toLowerCase();
			Log.event("Page URL:: " + url);
			if ("the page cannot be found".equalsIgnoreCase(title) || title.contains("is not available")
					|| url.contains("/error/") || url.toLowerCase().contains("/errorpage/")) {
				Assert.fail("Site is down. [Title: " + title + ", URL:" + url + "]");
			}
		} catch (TimeoutException e) {
			System.out.println("Timeout exception occured");
			Log.message("Timeout exception occured");
			driver.navigate().refresh();
			wait.until(pageLoad);
		}
		Log.event("Page Load Wait: (Sync)", StopWatch.elapsedTime(startTime));

	} // waitForPageLoad

	/**
	 * waitForPageLoad waits for the page load with default page load wait time
	 *
	 */
	public static void waitForPageLoad(final SelfHealingDriver driver) {
		waitForPageLoad(driver, WebDriverFactory.maxPageLoadWait);
	}

	/**
	 * To wait for the specific element on the page
	 *
	 * @param driver  - WebDriver
	 * @param element - WebElement to wait for
	 * @param maxWait - Max wait duration
	 * @return statusOfElementToBeReturned - return true if element is present else
	 *         return false
	 */
	public static boolean waitForElement(SelfHealingDriver driver, WebElement element, int... maxWaitArray) {
		int maxWait = maxWaitArray.length > 0 ? maxWaitArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		boolean staleElementException = false;
		boolean statusOfElementToBeReturned = false;
		long startTime = StopWatch.startTime();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(maxWait));
		do {
			try {
				wait.until(ExpectedConditions.visibilityOf(element));
				statusOfElementToBeReturned = true;
			} catch (TimeoutException e) {
				Log.event("Unable to find a element after " + StopWatch.elapsedTime(startTime) + " sec");
			} catch (StaleElementReferenceException e1) {
				Log.event("selectDropDownByVisibleText - Stale element exception");
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);
		return statusOfElementToBeReturned;
	}

	/**
	 * To wait for the specific element on the page
	 *
	 * @param driver  - WebDriver
	 * @param element - WebElement to wait for
	 * @param maxWait - Max wait duration
	 * @return statusOfElementToBeReturned - return true if element is present else
	 *         return false
	 */
	public static boolean waitForElementToBeVisible(SelfHealingDriver driver, By byElement, int... maxWaitArray) {
		int maxWait = maxWaitArray.length > 0 ? maxWaitArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		boolean staleElementException = false;
		boolean statusOfElementToBeReturned = false;
		long startTime = StopWatch.startTime();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(maxWait));
		do {
			try {
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(byElement));
				statusOfElementToBeReturned = true;
			} catch (TimeoutException e) {
				Log.event("Unable to find a element after " + StopWatch.elapsedTime(startTime) + " sec");
			} catch (StaleElementReferenceException e1) {
				Log.event("selectDropDownByVisibleText - Stale element exception");
				staleElementException = true;
			}
			retryCount++;
		} while (retryCount == 1 && staleElementException);
		return statusOfElementToBeReturned;
	}

	/**
	 * Wait for the given text is present in the specified element.
	 * 
	 * @param driver
	 * @param webElement         - Element in which given text to be present
	 * @param expectedText       - Expected Text
	 * @param elementDescription - Description
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void waitForExpectedTextToBePresent(SelfHealingDriver driver, WebElement webElement, String expectedText,
			String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();

		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.textToBePresentInElement(webElement, expectedText));
			Log.event(EXPECTED_TEXT + expectedText + " displayed in " + elementDescription);
		} catch (TimeoutException e) {
			Log.fail(EXPECTED_TEXT + expectedText + "not displayed in" + elementDescription + e, driver);
		}
	}

	/**
	 * Wait for particular element to be present
	 * 
	 * @param driver
	 * @param webElement         - expected element
	 * @param elementDescription - Description
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void waitForElementToBePresent(SelfHealingDriver driver, WebElement webElement, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		int retryCount = 0;
		do {
			try {
				if (!waitForElement(driver, webElement, timeout))
					throw new NoSuchElementException(elementDescription + " not found in page!!");
				Log.event(elementDescription + " displayed");
				break;
			} catch (NoSuchElementException e) {
				Log.fail(elementDescription + " not displayed" + e, driver);
			} catch (StaleElementReferenceException e) {
				Log.event("Wait for Element To be Present- StaleElement Exception");
			}
			retryCount++;
		} while (retryCount == 1);

	}

	/**
	 * Wait till the expected element becomes clickable
	 * 
	 * @param driver
	 * @param webElement         - Expected element needs to clickable
	 * @param elementDescription - Description
	 * @param timeOutArray       - custom timeout in secs
	 */
	public static void waitForElementToBeClickable(SelfHealingDriver driver, WebElement webElement, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.elementToBeClickable(webElement));
			Log.event(elementDescription + " is clickable");
		} catch (NoSuchElementException e) {
			Log.fail(elementDescription + " is not clickable" + e, driver);
		}
	}

	/**
	 * Wait for the given text is present in the specified element for particular
	 * time period.
	 * 
	 * @param driver
	 * @param webElement         - Element in which given text to be present
	 * @param expectedText       - Expected text to be present in the given element
	 * @param elementDescription - Description
	 * @param timeout            - time period in secs
	 */
	public static void waitForExpectedTextToBeVisibleForFewSecs(SelfHealingDriver driver, WebElement webElement,
			String expectedText, String elementDescription, int timeout) {
		waitForExpectedTextToBePresent(driver, webElement, expectedText, elementDescription);
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElement(webElement, expectedText)));
			Log.event(EXPECTED_TEXT + expectedText + " is not visible after the expected" + timeout + " secs");
		} catch (TimeoutException e) {
			Log.fail(EXPECTED_TEXT + expectedText + "is visible even after the " + timeout + " secs" + e, driver);
		}
	}

	/**
	 * @author anitha.raphel Used to wait For Element To Be visible
	 * @param driver
	 * @param webElement
	 * @param elementDescription
	 * @param timeOutArray
	 */
	public static void waitForElementToBeVisible(SelfHealingDriver driver, WebElement webElement, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.visibilityOf(webElement));
			Log.event(elementDescription + " element is displayed");
		} catch (TimeoutException e) {
			Log.fail(elementDescription + " element is not displaying" + e, driver);
		}
	}

	/**
	 * @author magesh.nagamani Used to wait For Element To Be visible
	 * @param driver
	 * @param webElement
	 * @param elementDescription
	 * @param timeOutArray
	 */
	public static void waitForLocatorToBeVisible(SelfHealingDriver driver, By byLocator, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.visibilityOfElementLocated(byLocator));
			Log.event(elementDescription + ELEMENT_NOT_DISPLAY);
		} catch (TimeoutException e) {
			Log.fail(elementDescription + ELEMENT_DISPLAYING + e, driver);
		}
	}

	/**
	 * @author magesh.nagamani Used to wait For Element To Be visible
	 * @param driver
	 * @param webElement
	 * @param elementDescription
	 * @param timeOutArray
	 */
	public static void waitForLocatorToBeInVisible(SelfHealingDriver driver, By byLocator, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(byLocator));
			Log.event(elementDescription + ELEMENT_NOT_DISPLAY);
		} catch (TimeoutException e) {
			Log.fail(elementDescription + ELEMENT_DISPLAYING + e, driver);
		}
	}

	/**
	 * @author magesh.nagamani Used to wait For Element To Be visible
	 * @param driver
	 * @param webElement
	 * @param elementDescription
	 * @param timeOutArray
	 */
	public static void waitForLocatorToBeInVisibleFromDOM(SelfHealingDriver driver, By byLocator, String elementDescription,
			int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();

		for (int i = 0; i < timeout; i++) {
			try {

				List<WebElement> elements = driver.findElements(byLocator);
				Log.event("Elements size- " + elements.size());
				if (elements.size() > 0) {
					Log.event("In if i-" + i);
					Thread.sleep(1000);
				} else {
					Log.event("In else i-" + i);
					Thread.sleep(1000);
					Log.event(elementDescription + ELEMENT_NOT_DISPLAY);
					break;
				}
			} catch (TimeoutException e) {
				Log.fail(elementDescription + ELEMENT_DISPLAYING + e, driver);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @author magesh.nagamani Used to wait For Element To Be visible
	 * @param driver
	 * @param webElement
	 * @param elementDescription
	 * @param timeOutArray
	 */
	public static void waitForElementToBeInVisible(SelfHealingDriver driver, List<WebElement> element,
			String elementDescription, int... timeOutArray) {
		int timeout = timeOutArray.length > 0 ? timeOutArray[0] : propertyReader.maxElementWait();
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.invisibilityOfAllElements(element));
			Log.event(elementDescription + ELEMENT_NOT_DISPLAY);
		} catch (TimeoutException e) {
			Log.fail(elementDescription + ELEMENT_DISPLAYING + e, driver);
		}
	}
}
