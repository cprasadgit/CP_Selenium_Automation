package com.aspire.utils.mobile;

public class MobileConstants {

	// ============Generic=====================================
	public static final String SYSTEM_OS_WIN = "Windows";
	public static final String SYSTEM_OS_MAC = "Mac";
	public static final String TEST_ENVIRONMENT = "testEnvironment";
	public static final String SCREENSHOT_ON_TEST_CASE_PASS = "screenshotOnTestCasePass";
	public static final String ANDROID_OBJECT_REPO = "./Repositories/android_object_repo";
	public static final String IOS_OBJECT_REPO = "./Repositories/ios_object_repo";
	public static final String MOBILE_WEB_OBJECT_REPO = "./Repositories/mobile_web_object_repo";
	public static final String DESKTOP_OBJECT_REPO = "./Repositories/desktop_object_repo";
	public static final String[] DEVICE_INFO_NAME = { "ro.product.manufacturer", "ro.product.model", "net.bt.name",
			"ro.build.version.release", "gsm.operator.alpha", "ro.serialno" };
	public static final String[] DEVICE_INFO = { "Manufacturer", "Model", "OS", "OS Version", "Network", "Device ID",
			"Location" };
	public static final String DEVICE_LOG_FOLDER = "//Logs//Device_logs//";
	public static final String DEVICE_INFO_FOLDER = "//Device_Info//";
	public static final String LOC_INFO = "passive: Location";
	public static final String LAT_LONG_REGEX = "-?\\d+(\\.\\d+)?\\,-?\\d+(\\.\\d+)?";
	public static final String GEOCODE_URL = "http://maps.googleapis.com/maps/api/geocode/json";
	public static final String LOCATION_SPOOFING_APK = "SupportFiles/locationSpoofing.apk";
	public static final String LOCATION_SPOOF_PACKAGE = "com.example.amotz.mockLocationForDeveloper";
	public static final String LOCATION_SPOOF_ACTIVITY = "com.example.amotz.mockLocationForDeveloper.MyActivity";
	public static final String LOCATION_SPOOF_ACTION = "com.example.amotz.mockLocationForDeveloper.updateLocation";
	public static final String API_RESPONSE_DATA = "./src/test/resources/APITesting/ResponseData/";
	public static final String API_REQUEST_PAYLOAD = "./src/test/resources/APITesting/RequestPayload/";
	public static final String API_REQUEST_GRAPHQL = "./src/test/resources/APITesting/GraphQL/";

	// ==========> Configuration files
	public static final String FRAMEWORK_CONFIG = "framework_config";
	public static final String AUTOMATION_TEST_CONFIG = "automation_test_config";
	public static final String EMAIL_CONFIG = "email_config";
	public static final String DB_CONFIG = "db_config";

	// ============From AutomationBase=====================================

	public static final String APPIUM_START_MSG = "Run started";
	public static final String APPIUM_START_SUCCESS_MSG = "Appium successfully started...";
	public static final String WAITING_FOR_APPIUM_TO_START = "Waiting for starting Appium...";
	public static final String DRIVER_LOAD_MSG = "Loading driver details...";
	public static final String DRIVER_LOAD_SUCCESS_MSG = "Your automation session started successfully...";
	public static final String APPIUM_HOST_IP = "appiumHostIP";
	public static final String APPIUM_CONFIGURATION_ERROR = "Appium is not installed or path missing in System Environment variable";
	public static final String MAC_NODE_CONFIGURATION_ERROR = "Please set PATH variable in Run Configurations of the project. Steps: Right click on project > Run As > Run Configurations > Environment tab";
	public static final String TESTNG_OS_MISSING = "Specify Platform Name('Android','iOS') in testng.xml";
	public static final String TESTNG_BROWSERNAME_MISSING = "Specify Browser Name in testng.xml";
	public static final String TESTNG_PLATFORM_MISSING = "Specify Platform Name in testng.xml";
	public static final String TESTNG_UDID_MISSING = "Specify UDID of device in testng.xml";
	public static final String TESTNG_PLATFORMVERSION_MISSING = "Specify Desktop browser version in testng.xml";
	public static final String INVALID_BROWSER_NAME = "You are trying to run incompatible browser in defined platform, failed to open";
	public static final String WRONG_CAPABILITIES = "You have mentioned wrong or empty details in testng.xml";
	public static final String OBJECT_REPO_FILES_MISSING = "Object repository property files missing, test execution terminated...";
	public static final String PLATFORM_NAME_ANDROID = "Android";
	public static final String PLATFORM_NAME_IOS = "iOS";
	public static final String ANDROID_APPLICATION = "androidAppLocation";
	public static final String ANDROID_APPPACKAGE = "androidAppPackage";
	public static final String ANDROID_APPACTIVITY = "androidAppActivity";
	public static final String IOS_APPLICATION = "iOSAppLocation";
	public static final String IOS_BUNDLEID = "iOSBundleId";
	public static final String WINDOWS_APPLICATION_PATH = "windowsDesktopApplicationPath";
	public static final String MAC_APPLICATION_PATH = "macDesktopApplicationPath";
	public static final String BUNDLE_ID_MISSING = "In automation_config property file, you need to specify application location and bundleID or bundleID only if you already installed application";
	public static final String SAFAIBROWSERERORMESSAGE = "Apple's decision to drop Safari on Windows. SafariDriver requires Safari 10 running on OSX El Capitan or greater.";
	public static final String SAFAILAUNCHERAPPPATH = "//usr//local//lib//node_modules//appium//node_modules//appium-ios-driver//build//SafariLauncher//SafariLauncher.app";
	public static final String DEVICECONSOLEPATH = "/usr/local/lib/node_modules/deviceconsole/deviceconsole";
	public static final String MOBILEDEVICEPATH = "/usr/local/bin/mobiledevice";
	public static final String XCODEBUILDPATH = "/usr/bin/xcodebuild";
	public static final String APPIUM_WAITING_TIME_FOR_NEW_COMMANDIN = "appiumWaitingTimeForNewCommand";

	// ===============Exception Messages
	public static final String EXCEPTION_MESSAGE = "This test is failed because of the ";
	public static final String CAUSE = "The reason of this exception is: ";
	public static final String EXCEPTION_MESSAGE_EXCEL_FILE_PATH = "Specify test data Excel file path in automation_test_config.properties file";
	public static final String EXCEPTIION_EXCEL_SHEETNAME = "Can't read data from specified sheet, check sheet name";
	public static final String EXCEPTIION_EXCEL_COLUMN_NO = "Specify column index greater than zero";
	public static final String EXCEPTIION_EXCEL_ROW_NO = "Specify row index greater than zero";
	public static final String EXCEPTIION_EXCEL_COLUMN_NAME = "Excel column with given name not found, check the name";
	public static final String EXCEPTIION_EXCEL_PATH = "Give excel file path as argument";
	public static final String EXCEPTIION_EXCEL_FILE = "Please provide excel file with .xlsx or .xls format";
	public static final String OBJECT_NOT_FOUND = "Object not found";
	public static final String EXCEPTION_MESSAGE_FAILED_TO_GET_SCREEN = "Failed to get current screen";
	public static final String EXCEPTION_MESSAGE_INPUT_IMAGE_NOT_FOUND = "Specified expected image not found";
	public static final String EXCEPTION_MESSAGE_OUTPUT_IMAGE_NOT_FOUND = "Specified actual image not found";
	public static final String EXCEPTION_MESSAGE_FOR_LOAD_URL = "Cannot navigate to invalid web URL, please specify valid web URL";
	public static final String DRIVER_MISSING = "Driver is missing";
	public static final String WRONG_APP_PATH = "Wrong application path";
	public static final String APP_PACKAGE_VALIDATION_EXCEPTION = "Empty or invalid app package is given";
	public static final String APP_ACTIVITY_VALIDATION_EXCEPTION = "Empty or invalid app activity is given";
	public static final String FRAME_MISSING = "Frame is missing";
	public static final String COOKIES_EXCEPTION = "Cookies are missing";
	public static final String EXCEPTION_MESSAGE_WAITFOR_AJAXCALL = "Timeout when waiting for Ajax response";

}