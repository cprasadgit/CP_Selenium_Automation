package com.aspire.utils.testdata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

/**
 * Utility class for interacting with a PostgreSQL database using JDBC.
 */
public class SQLUtils implements IDataReader {
	
	private static String ERROR_QUERY_MSG = "Error in Executing the Query.";
	private static String QUERY_EXECUTED_MSG = "Query executed!" ;
	private static String EXECUTING_QUERY = "Executing Query: ";
	private static String ERR_EXECUTING_QUERY = "Error in executing the query";

	private static SQLUtils sqlUtil = null;

	private static final String POSTGRES_DRIVER = "org.postgresql.Driver";
	private static StringBuilder dbUrl;
	private static Connection connection = null;

	/**
	 * Static block to load the PostgreSQL JDBC driver. This block is executed when
	 * the class is loaded into memory. It initializes the JDBC driver required for
	 * database connections.
	 */
	static {
		try {
			Class.forName(POSTGRES_DRIVER);
		} catch (Exception e) {
			System.out.println("Error while loading database.");
		}
	}

	private SQLUtils() {

	}

	/**
	 * Returns an instance of the SQLUtil class for database operations. If an
	 * instance does not exist, a new instance is created. The database connection
	 * is established and cached for subsequent calls.
	 *
	 * @param dbHost     The host name or IP address of the database server.
	 * @param dbPort     The port number on which the database server is listening.
	 * @param dbName     The name of the database to connect to.
	 * @param dbUserName The username for authenticating the database connection.
	 * @param dbPassword The password for authenticating the database connection.
	 * @return An instance of SQLUtil for performing database operations.
	 */
	public synchronized static SQLUtils getInstance(String dbHost, Integer dbPort, String dbName, String dbUserName,
			String dbPassword) {
		if (Objects.isNull(sqlUtil)) {
			sqlUtil = new SQLUtils();
		}
		sqlUtil.getConnection(dbHost, dbPort, dbName, dbUserName, dbPassword);
		return sqlUtil;
	}

	/**
	 * Establishes a database connection and returns the Connection object. If a
	 * connection already exists, the existing connection is returned.
	 *
	 * @param dbHost     The host name or IP address of the database server.
	 * @param dbPort     The port number on which the database server is listening.
	 * @param dbName     The name of the database to connect to.
	 * @param dbUserName The username for authenticating the database connection.
	 * @param dbPassword The password for authenticating the database connection.
	 * @return A Connection object representing the established database connection.
	 */
	public synchronized Connection getConnection(String dbHost, Integer dbPort, String dbName, String dbUserName,
			String dbPassword) {
		if (Objects.nonNull(connection)) {
			return connection;
		}
		try {
			dbUrl = new StringBuilder();
			dbUrl.append("jdbc:postgresql://").append(dbHost).append(":").append(dbPort).append("/").append(dbName);

			System.out.println("Connection URL: " + dbUrl.toString());
			connection = DriverManager.getConnection(dbUrl.toString(), dbUserName, dbPassword);
		} catch (Exception e) {
			System.err.println("Error in Establishing DB Connection.");
			e.printStackTrace();
		}

		return connection;
	}

	/**
	 * Creates a Statement object for executing SQL queries. This method uses the
	 * existing database connection to create the statement.
	 *
	 * @return A Statement object for executing SQL queries.
	 * @throws SQLException If a database access error occurs.
	 */
	public static Statement createStatement() throws SQLException {
		Statement statement = connection.createStatement();
		return statement;
	}

	/**
	 * Fetches data from the specified database table (sheet) and returns it as a
	 * list of maps.
	 *
	 * @param sheetName The name of the table (sheet) to fetch data from.
	 * @return A list of maps, where each map represents a row of data with column
	 *         names as keys and column values as values.
	 */
	@Override
	public List<Map<String, String>> fetchSheetData(String sheetName) {

		List<Map<String, String>> data = new ArrayList<>();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			String query = "SELECT * FROM " + sheetName;

			ResultSet resultSet = statement.executeQuery(query);
			int columnCount = resultSet.getMetaData().getColumnCount();

			while (resultSet.next()) {
				Map<String, String> rowData = new LinkedHashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					String columnName = resultSet.getMetaData().getColumnName(i);
					String columnValue = resultSet.getString(i);
					rowData.put(columnName, columnValue);
				}
				data.add(rowData);
			}

			resultSet.close();
			
		} catch (SQLException e) {
			System.err.println(ERROR_QUERY_MSG);
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return data;
	}

	@Override
	public Map<String, String> getRowValuesByRowNumber(String sheetName, int rowNum) {
		return fetchSheetData(sheetName).get(rowNum - 1);
	}

	/**
	 * Retrieves the row values from the specified database table (sheet) based on
	 * the provided test case ID (tcID).
	 *
	 * @param sheetName The name of the table (sheet) to retrieve data from.
	 * @param tcID      The test case ID used to filter the rows.
	 * @return A map containing the column names as keys and the corresponding
	 *         column values for the matching row.
	 */
	@Override
	public Map<String, String> getRowValuesByTcId(String sheetName, String tcID) {
		Map<String, String> data = new LinkedHashMap<>();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			String query = "SELECT * FROM " + sheetName + " WHERE tc_id = '" + tcID + "';";

			ResultSet resultSet = statement.executeQuery(query);
			int columnCount = resultSet.getMetaData().getColumnCount();

			while (resultSet.next()) {
				for (int i = 1; i <= columnCount; i++) {
					String columnName = resultSet.getMetaData().getColumnName(i);
					String columnValue = resultSet.getString(i);
					data.put(columnName, columnValue);
				}
			}

			resultSet.close();
		
		} catch (SQLException e) {
			System.err.println(ERROR_QUERY_MSG);
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return data;
	}

	/**
	 * Retrieves the value of a specific cell in the specified database table
	 * (sheet) based on the provided test case ID (tcID) and header.
	 *
	 * @param sheetName The name of the table (sheet) to retrieve data from.
	 * @param header    The column header representing the desired cell.
	 * @param tcID      The test case ID used to identify the row.
	 * @return The value of the specified cell, or null if not found.
	 */
	@Override
	public String getCellValueByTcID(String sheetName, String header, String tcID) {
		String cellValue = null;
		Statement statement = null;
		try {
			statement = connection.createStatement();
			String query = "SELECT " + header + " FROM " + sheetName + " WHERE tc_id = '" + tcID + "'";

			ResultSet resultSet = statement.executeQuery(query);

			if (resultSet.next()) {
				cellValue = resultSet.getString(header);
			}

			resultSet.close();
			
		} catch (SQLException e) {
			System.err.println(ERROR_QUERY_MSG);
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return cellValue;
	}

	@Override
	public String getCellValueByRowNumber(String sheetName, String header, int rowNum) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateSheetWithData(String sheetName, List<Map<String, String>> newData) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addValuesWithFormulas(String sheetName, List<List<Object>> data) {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param queryString
	 * @return
	 */
	public List<Object[]> executeQuery(String queryString) {
		List<Object[]> records = new ArrayList<Object[]>();
		try {
			Statement qSt = createStatement();
			System.out.println(EXECUTING_QUERY + queryString);
			ResultSet resultSet = qSt.executeQuery(queryString);
			System.out.println(QUERY_EXECUTED_MSG);

			// call only once
			int cols = resultSet.getMetaData().getColumnCount();
			while (resultSet.next()) {
				Object[] arr = new Object[cols];
				for (int i = 0; i < cols; i++) {
					arr[i] = resultSet.getObject(i + 1);
				}
				records.add(arr);
			}
			resultSet.close();
			qSt.close();
		} catch (SQLException e) {
			if (e.getMessage().toString().equalsIgnoreCase("No results were returned by the query")) {
				System.out.println("Query executed and no result found");
			} else {
				e.printStackTrace();
				System.out.println(ERR_EXECUTING_QUERY);
			}
		} 
		return records;
	}

	/**
	 * This method executes the given query and return the results as table format.
	 * The CachedRowSet obj can be further used by DB representation classes.
	 *
	 * @param queryString
	 * @return
	 * @throws SQLException
	 */
	public CachedRowSet executeQueryAndReturnTable(String queryString) throws SQLException {
		CachedRowSet crs = RowSetProvider.newFactory().createCachedRowSet();
		try {
			Statement qSt = createStatement();
			System.out.println(EXECUTING_QUERY + queryString);
			ResultSet resultSet = qSt.executeQuery(queryString);
			System.out.println(QUERY_EXECUTED_MSG);

			crs.populate(resultSet);

			resultSet.close();
			qSt.close();
		} catch (SQLException e) {
			System.err.println(ERR_EXECUTING_QUERY);
		}
		return crs;
	}

	/**
	 * Executes an SQL update query that modifies data in the database.
	 *
	 * @param queryString The SQL query to execute.
	 * @return True if the query was executed successfully, otherwise false.
	 */
	public boolean executeUpdateQuery(String queryString) {
		try {
			Statement qSt = createStatement();
			System.out.println(EXECUTING_QUERY + queryString);
			qSt.executeUpdate(queryString);
			System.out.println(QUERY_EXECUTED_MSG);
			qSt.close();
		} catch (SQLException e) {
			System.err.println(ERR_EXECUTING_QUERY);
			return false;
		}
		return true;
	}

	/**
	 * Executes a query for insert or delete operations without expecting a result
	 * set.
	 *
	 * @param queryString The SQL query to execute.
	 * @return True if the query was executed successfully, otherwise false.
	 */
	public boolean executeInsDelQuery(String queryString) {
		try {
			Statement qSt = createStatement();
			System.out.println(EXECUTING_QUERY + queryString);
			qSt.executeQuery(queryString);
			System.out.println(QUERY_EXECUTED_MSG);
			qSt.close();
		} catch (SQLException e) {
			executeInsDelQuery(ERR_EXECUTING_QUERY);
			return false;
		}
		return true;
	}

}
