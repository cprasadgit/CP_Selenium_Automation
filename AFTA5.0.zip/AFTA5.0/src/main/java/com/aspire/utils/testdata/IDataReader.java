package com.aspire.utils.testdata;

import java.util.List;
import java.util.Map;

/**
 * This interface defines methods for interacting with a sheet of data,
 * providing functionality to fetch, retrieve, update, and manipulate data.
 * 
 * @author bharathi.murugan
 * @version 5.0.0
 * @since 18-08-2023
 */
public interface IDataReader {

	/**
	 * Fetches the data from the specified sheet.
	 *
	 * @param sheetTableName The name of the sheet from which to fetch data.
	 * @return A list of rows, where each row is represented as a map of column
	 *         headers to cell values.
	 */
	List<Map<String, String>> fetchSheetData(String sheetTableName);

	/**
	 * Retrieves all values of a specified row in the given sheet by row number.
	 *
	 * @param sheetTableName The name of the sheet containing the row.
	 * @param rowNum    The row number from which to retrieve values.
	 * @return A map of column headers to cell values for the specified row.
	 */
	Map<String, String> getRowValuesByRowNumber(String sheetTableName, int rowNum);

	/**
	 * Retrieves all values of a specified row in the given sheet by test case ID.
	 *
	 * @param sheetTableName The name of the sheet containing the row.
	 * @param tcId      The unique test case ID for the row.
	 * @return A map of column headers to cell values for the specified row.
	 */
	Map<String, String> getRowValuesByTcId(String sheetTableName, String tcId);

	/**
	 * Retrieves the value of a specified cell in the given sheet by header and test
	 * case ID.
	 *
	 * @param sheetTableName The name of the sheet containing the cell.
	 * @param header    The column header of the cell.
	 * @param tcID      The unique test case ID for the row containing the cell.
	 * @return The value of the specified cell.
	 */
	String getCellValueByTcID(String sheetTableName, String header, String tcID);

	/**
	 * Retrieves the value of a specified cell in the given sheet by header and row
	 * number.
	 *
	 * @param sheetTableName The name of the sheet containing the cell.
	 * @param header    The column header of the cell.
	 * @param rowNum    The row number of the cell.
	 * @return The value of the specified cell.
	 */
	String getCellValueByRowNumber(String sheetTableName, String header, int rowNum);

	/**
	 * Updates the data in the specified sheet with new data.
	 *
	 * @param sheetTableName The name of the sheet to be updated.
	 * @param newData   The new data to be written to the sheet.
	 * @return True if the update is successful, false otherwise.
	 */
	boolean updateSheetWithData(String sheetTableName, List<Map<String, String>> newData);

	/**
	 * Adds values with formulas to the specified sheet.
	 *
	 * @param sheetTableName The name of the sheet to which data with formulas should be
	 *                  added.
	 * @param data      A list of rows, where each row contains a list of objects
	 *                  representing cell values.
	 * @return True if the addition is successful, false otherwise.
	 */
	boolean addValuesWithFormulas(String sheetTableName, List<List<Object>> data);
}