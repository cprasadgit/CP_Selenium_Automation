package com.aspire.utils.mobile;

public interface TestDataKeywords {
	public static final String USERNAME = "USERNAME";
	public static final String PASSWORD = "PASSWORD";
	public static final String WEBSITE = "WEBSITE";
	public static final String QUIZNAME = "QUIZNAME";

}
