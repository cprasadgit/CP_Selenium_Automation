package com.aspire.utils.mobile;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataHandler {
	static XSSFWorkbook workBook;
	static XSSFSheet sheet;

	public DataHandler() {

	}

	public DataHandler(String excelFilePath, String sheetName) {
		try {
			workBook = new XSSFWorkbook(excelFilePath);
		} catch (IOException e) {
			e.printStackTrace();
		}
		sheet = workBook.getSheet(sheetName);
	}

	/**
	 * Get number of rows from excel sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @return rowCount @
	 */
	public static int getRowCountFromExcel() {
		int rowCount = sheet.getPhysicalNumberOfRows();
		return rowCount;
	}

	/**
	 * Get number of columns from excel sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @return colCount
	 */
	public static int getColCountFromExcel() {
		int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
		return colCount;
	}

	/**
	 * Get string or numeric data from excel sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param rowNum
	 * @param colNum
	 * @return cellValue @
	 */
	public static String getDataFromExcel(int rowNum, int colNum) {
		String cellValue = null;
		try {
			CellType cellType = sheet.getRow(rowNum - 1).getCell(colNum - 1).getCellType();
			if (cellType.toString().toLowerCase().equals("numeric")) {
				cellValue = new MobileUtils().convertIntToString(new MobileUtils()
						.convertDoubleToInt(sheet.getRow(rowNum - 1).getCell(colNum - 1).getNumericCellValue()));
			}
			if (cellType.toString().toLowerCase().equals("string")) {
				cellValue = sheet.getRow(rowNum - 1).getCell(colNum - 1).getStringCellValue();
			}
			if (cellType.toString().toLowerCase().equals("formula")) {
				FormulaEvaluator evaluator = workBook.getCreationHelper().createFormulaEvaluator();
				switch (evaluator.evaluateFormulaCell(sheet.getRow(rowNum - 1).getCell(colNum - 1))) {
				case NUMERIC:
					cellValue = Double.toString(sheet.getRow(rowNum - 1).getCell(colNum - 1).getNumericCellValue());
					break;
				case STRING:
					cellValue = sheet.getRow(rowNum - 1).getCell(colNum - 1).getStringCellValue();
					break;
				default:
					break;
				}
			}
		} catch (Exception e) {
		} finally {
			try {
				workBook.close();
			} catch (Exception e) {
			}
		}
		return cellValue;
	}

	/**
	 * Get Date data from excel sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param rowNum
	 * @param colNum
	 * @return cellValue
	 */
	public static String getDateDataFromExcel(int rowNum, int colNum) {
		String dateValue = "";
		try {
			Date cellValue = sheet.getRow(rowNum - 1).getCell(colNum - 1).getDateCellValue();
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			dateValue = dateFormat.format(cellValue);
		} catch (Exception e) {
		} finally {
			try {
				workBook.close();
			} catch (Exception e) {
			}
		}
		return dateValue;
	}

	/**
	 * Get Date data from excel sheet based on the given date format
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param rowNum
	 * @param colNum
	 * @param dateFormat
	 * @return cellValue
	 */
	public static String getDateDataFromExcel(int rowNum, int colNum, String dateFormat) {
		String dateValue = "";
		try {
			Date cellValue = sheet.getRow(rowNum - 1).getCell(colNum - 1).getDateCellValue();
			DateFormat finalDateFormat = new SimpleDateFormat(dateFormat);
			dateValue = finalDateFormat.format(cellValue);
		} catch (Exception e) {
		} finally {
			try {
				workBook.close();
			} catch (Exception e) {
			}
		}
		return dateValue;
	}

	/**
	 * Get list of data from a column
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param sheetName
	 * @param colNum
	 * @return
	 * @ @throws IOException
	 */
	public static ArrayList<String> getColumnDataFromExcel(String sheetName, int colNum) throws IOException {
		ArrayList<String> list = new ArrayList<String>();
		try {
			if (colNum < 1)
				throw new MobileExceptionWrapper(MobileConstants.EXCEPTIION_EXCEL_COLUMN_NO);

			int index = workBook.getSheetIndex(sheetName);
			if (index == -1) {
				throw new MobileExceptionWrapper(MobileConstants.EXCEPTIION_EXCEL_SHEETNAME);
			}

			XSSFSheet mySheet = workBook.getSheetAt(index);
			Iterator<Row> rowIter = mySheet.rowIterator();
			Row row;
			Cell cell;
			while (rowIter.hasNext()) {
				row = (Row) rowIter.next();
				cell = row.getCell(colNum - 1);
				if (cell != null) {
					if (cell.getCellType().toString().toLowerCase().equals("string"))
						list.add(cell.getStringCellValue());
					else if (cell.getCellType().toString().toLowerCase().equals("numeric")) {
						list.add(cell.getNumericCellValue() + "");
					} else
						list.add(cell.toString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				workBook.close();
			} catch (Exception e) {
			}
		}
		return list;
	}

	/**
	 * Method to get the property value from the property file
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param fileName
	 * @param propertyName
	 * @return propValue @
	 */
	public static String getProperty(String fileName, String propertyName) {
		String propValue = "";
		try {
			Properties props = new Properties();
			ClassLoader classLoader = DataHandler.class.getClassLoader();
			InputStream input = classLoader.getResourceAsStream(fileName + ".properties");
			props.load(input);
			propValue = props.getProperty(propertyName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return propValue;
	}

	/**
	 * Method to write new key and value to the properties file
	 * 
	 * @author sanoj.swaminathan
	 * @since 31-07-2023
	 * @param filePath. For example: ./src/test/resources/config.properties
	 * @param keyName
	 * @param value
	 */
	public static void writeToPropertiesFile(String filePath, String keyName, String value) {

		Properties properties = new Properties();
		try (InputStream inputStream = new FileInputStream(filePath)) {
			properties.load(inputStream);
		} catch (IOException e) {
		}

		if (!properties.containsKey(keyName)) {
			properties.setProperty(keyName, value);
			try (OutputStream outputStream = new FileOutputStream(filePath, false)) {
				properties.store(outputStream, null);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("Key already exists, skipping addition.");
		}
	}
}