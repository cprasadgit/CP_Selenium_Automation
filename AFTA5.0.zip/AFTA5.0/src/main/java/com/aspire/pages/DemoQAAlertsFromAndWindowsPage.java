package com.aspire.pages;

import java.lang.String;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.*;

import com.aspire.utils.web.WebUtils;
import com.epam.healenium.SelfHealingDriver;

public class DemoQAAlertsFromAndWindowsPage {

	private SelfHealingDriver driver;

	public DemoQAAlertsFromAndWindowsPage(SelfHealingDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "((//div[@class='element-group'])[3] //li[@id='item-0']")
	private WebElement btnBrowserWindows;

	@FindBy(how = How.XPATH, using = "(//div[@class='element-group'])[3] //li[@id='item-1']")
	private WebElement btnAlerts;

	@FindBy(how = How.CSS, using = "#tabButton")
	private WebElement btnNewTab;

	@FindBy(how = How.CSS, using = "#windowButton")
	private WebElement btnNewWindow;

	@FindBy(how = How.CSS, using = "#msgWindowButtonWrapper")
	private WebElement btnNewWindowMessage;

	@FindBy(how = How.CSS, using = "#sampleHeading")
	private WebElement newTabTitle;

	@FindBy(how = How.CSS, using = "body")
	private WebElement newWindowMessage;

	@FindBy(how = How.CSS, using = "#confirmButton")
	private WebElement btnConfirmBoxClickMe;

	@FindBy(how = How.CSS, using = "#promtButton")
	private WebElement btnPromptBoxClickMe;

	@FindBy(how = How.CSS, using = "#confirmResult")
	private WebElement confrimSuccessMessage;

	@FindBy(how = How.CSS, using = "#promptResult")
	private WebElement promptSuccessMessage;

	public void clickBrowserWindowsOption() {
		btnBrowserWindows.click();
	}

	public void clickAlertsOption() {
		btnAlerts.click();
	}

	public void clickNewTabButton() {
		btnNewTab.click();
	}

	public void clickNewWindowButton() {
		btnNewWindow.click();
	}

	public void clickNewWindowWithMessage() {
		btnNewWindowMessage.click();
	}

	public void clickConfirmBoxClickMeButton() {
		btnConfirmBoxClickMe.click();
	}

	public void clickPromptBoxClickMeButton() {
		promptSuccessMessage.click();
	}

	public boolean verifyNewTabisOpened() {
		try {
			WebUtils.switchToSecondTab(driver);
			if (newTabTitle.isDisplayed()) {
				return true;
			}
			return false;
		} catch (Exception e) {
			System.out.println("New tab is not loaded due to exception" + e.getMessage());
			return false;
		}
	}

	public boolean verifyNewWindowWithMessage() {
		try {
			WebUtils.switchToSecondTab(driver);
			if (newWindowMessage.isDisplayed()) {
				return true;
			}
			return false;
		} catch (Exception e) {
			System.out.println("New window is not loaded with message due to exception" + e.getMessage());
			return false;
		}
	}

	public boolean verifySuccessMessageOnConfirmAlert() {
		try {
			if (confrimSuccessMessage.getText().contains("You selected")) {
				return true;
			}
			return false;
		} catch (Exception e) {
			System.out.println("Message not displayed due to exception" + e.getMessage());
			return false;
		}
	}

	public void acceptConfirmAlert() {
		Alert confirmAlert = driver.switchTo().alert();
		confirmAlert.accept();
	}

	public void enterValueInPromptBox(String value) {
		Alert promptAlert = driver.switchTo().alert();
		promptAlert.sendKeys(value);
		promptAlert.accept();
	}

	public boolean verifySuccessMessageOnPromptBox() {
		try {
			if (promptSuccessMessage.getText().contains("You entered")) {
				return true;
			}
			return false;
		} catch (Exception e) {
			System.out.println("Message not displayed due to exception" + e.getMessage());
			return false;
		}
	}

	public String getPageTitle() {
		return this.driver.getTitle().trim();
	}

}