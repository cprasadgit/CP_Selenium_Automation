package com.aspire.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.epam.healenium.SelfHealingDriver;

public class DemoQAWidgetsPage {

	private SelfHealingDriver driver;

	public DemoQAWidgetsPage(SelfHealingDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "(//div[@class='element-group'])[4] //li[@id='item-1']")
	private WebElement btnAutoComplete;

	@FindBy(how = How.XPATH, using = "(//div[@class='element-group'])[4] //li[@id='item-6']")
	private WebElement btnToolTips;

	@FindBy(how = How.CSS, using = "#autoCompleteMultipleContainer")
	private WebElement txtMulitplevalue;

	@FindBy(how = How.CSS, using = "#autoCompleteSingleContainer")
	private WebElement txtSingleValue;

	@FindBy(how = How.CSS, using = ".btn.btn-success")
	private WebElement btnHoverMeToSee;

	@FindBy(how = How.CSS, using = ".tooltip-inner")
	private WebElement hoverMessage;

	public void clickAutoCompleteOption() {
		btnAutoComplete.click();
	}

	public void clickToolTipsButton() {
		btnToolTips.click();
	}

	public void enterMulipleValuesInTextBox(String value1, String value2, String value3) {
		txtMulitplevalue.sendKeys(value1);
		txtMulitplevalue.sendKeys(Keys.ENTER);
		txtMulitplevalue.sendKeys(value2);
		txtMulitplevalue.sendKeys(Keys.ENTER);
		txtMulitplevalue.sendKeys(value3);
		txtMulitplevalue.sendKeys(Keys.ENTER);
	}

	public void enterSingleValuesInTextBox(String value) {
		txtMulitplevalue.sendKeys(value);
		txtMulitplevalue.sendKeys(Keys.ENTER);
	}

	public boolean verifyMessageOnMouseHover() {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(btnHoverMeToSee).perform();
			if (hoverMessage.getText().contains("You hovered over the Button")) {
				return true;
			}
			return false;
		} catch (Exception e) {
			System.out.println("Message not displayed due to exception" + e.getMessage());
			return false;
		}
	}

}