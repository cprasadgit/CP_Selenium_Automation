package com.aspire.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.epam.healenium.SelfHealingDriver;

public class SignInPageGw {

	private SelfHealingDriver driver;

	public SignInPageGw(SelfHealingDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.CSS, using = "#Login-LoginScreen-LoginDV-submit div[class='gw-action--inner gw-hasDivider'] >div:nth-of-type(2)")
	private WebElement lblLogIn;

	@FindBy(how = How.CSS, using = "input[name='Login-LoginScreen-LoginDV-username']")
	private WebElement txtUsername;

	@FindBy(how = How.CSS, using = "input[name='Login-LoginScreen-LoginDV-password']")
	private WebElement txtPassword;

	@FindBy(how = How.CSS, using = "div[id$='submit_Input'] div[id$='submit'] > div[role='button']")
	public WebElement btnLogIn;

	public void clickLogInLabel() {
		lblLogIn.click();
	}

	public void typeTextIntoUsername(String text) {
		txtUsername.sendKeys(text);
	}

	public void typeTextIntoPassword(String text) {
		txtPassword.sendKeys(text);
	}

	public void clickLogin() {
		btnLogIn.click();
		// WebUtils.clickJS(driver, btnLogIn, "");
	}

}
