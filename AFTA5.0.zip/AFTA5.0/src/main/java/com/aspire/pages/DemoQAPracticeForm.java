package com.aspire.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aspire.utils.web.WebUtils;
import com.epam.healenium.SelfHealingDriver;

public class DemoQAPracticeForm {

	private SelfHealingDriver driver;

	public DemoQAPracticeForm(SelfHealingDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "(//ul[@class='menu-list'])[2]")
	private WebElement BtnPracticeForm;

	@FindBy(how = How.CSS, using = "#firstName")
	private WebElement txtFirstName;

	@FindBy(how = How.CSS, using = "#lastName")
	private WebElement txtLastName;

	@FindBy(how = How.CSS, using = "#userEmail")
	private WebElement txtEmail;

	@FindBy(how = How.CSS, using = "#gender-radio-1")
	private WebElement btnMaleGender;

	@FindBy(how = How.CSS, using = "#userNumber")
	private WebElement txtMobileNumber;

	@FindBy(how = How.CSS, using = "#dateOfBirthInput")
	private WebElement txtDateOfBirth;

	@FindBy(how = How.CSS, using = "#state")
	private WebElement stateDropDown;

	@FindBy(how = How.CSS, using = "#submit")
	private WebElement btnSubmit;

	@FindBy(how = How.CSS, using = "div.modal-content div.modal-header #example-modal-sizes-title-lg")
	private WebElement formSubmittedPopUp;

	public void clickPracticeForm() {
		BtnPracticeForm.click();
	}

	public void enterFirstName(String firstName) {
		WebUtils.type(driver, txtFirstName, firstName, "First Name");
	}

	public void enterLastName(String lastName) {
		WebUtils.type(driver, txtLastName, lastName, "Last Name");
	}

	public void enterEmailAddress(String email) {
		WebUtils.type(driver, txtEmail, email, "Email Address");
	}

	public void clickMaleRadioButton() {
		btnMaleGender.click();
	}

	public void enterMobileNumber(String mobileNumber) {
		WebUtils.type(driver, txtMobileNumber, mobileNumber, "Mobile Number");
	}

	public void enterDateOfBirth(String dob) {
		WebUtils.type(driver, txtDateOfBirth, dob, "Date Of Birth");
	}

	public void selectState(String stateName) {
		WebUtils.selectDropDownByVisibleText(driver, stateDropDown, stateName, "State Dropdown");
	}

	public void clickSubmitBtn() {
		btnSubmit.click();
	}

	public boolean verifyFormSubmittedPopUpisDisplayed() {
		try {
			if (WebUtils.getText(driver, formSubmittedPopUp, "Form Submmited Popup Title")
					.contains("Thanks for submitting the form")) {
				return true;
			}
			return false;
		} catch (Exception e) {
			System.out.println("PopUp not displayed due to exception" + e.getMessage());
			return false;
		}
	}

	public String getPageTitle() {
		return this.driver.getTitle().trim();
	}

}