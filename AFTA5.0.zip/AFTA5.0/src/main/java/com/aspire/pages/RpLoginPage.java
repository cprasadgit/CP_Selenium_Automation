package com.aspire.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aspire.utils.web.WebUtils;
import com.epam.healenium.SelfHealingDriver;

public class RpLoginPage {
	private SelfHealingDriver driver;

	@FindBy(how = How.ID, using = "locale-select")
	private WebElement selAccountLoginsignInWithGooglesignInWithLinkedinorforgotYourPassword;

	@FindBy(how = How.ID, using = "1-email")
	private WebElement txtEmail;

	@FindBy(how = How.NAME, using = "password")
	private WebElement txtPassword;

	@FindBy(how = How.NAME, using = "submit")
	private WebElement btnLogIn;

	/**
	 * Constructor
	 */
	public RpLoginPage(SelfHealingDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/**
	 * Adding ActionMethods for 'dropdown' element-SelectByVisibleText
	 */
	public RpLoginPage selectAccountLoginsignInWithGooglesignInWithLinkedinorforgotYourPassword(
			String optionToBeSelected) throws Exception {
		WebUtils.selectDropDownByVisibleText(driver,
				selAccountLoginsignInWithGooglesignInWithLinkedinorforgotYourPassword, optionToBeSelected,
				"AccountLoginsignInWithGooglesignInWithLinkedinorforgotYourPasswordDropdown");
		return this;
	}

	/**
	 * Adding ActionMethods for 'dropdown' element-SelectByIndex
	 */
	public RpLoginPage selectAccountLoginsignInWithGooglesignInWithLinkedinorforgotYourPassword(int indexToSelect)
			throws Exception {
		WebUtils.selectDropDownByIndex(driver, selAccountLoginsignInWithGooglesignInWithLinkedinorforgotYourPassword,
				indexToSelect, "AccountLoginsignInWithGooglesignInWithLinkedinorforgotYourPasswordDropdown");
		return this;
	}

	/**
	 * Adding ActionMethods for 'input' element
	 */
	public RpLoginPage typeTextIntoEmail(String textToEnter) throws Exception {
		// WebUtils.type(driver, txtEmail, textToEnter, "EmailField");
		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('id','12-email')", txtEmail);
		txtEmail.sendKeys(textToEnter);
		return this;
	}

	/**
	 * Adding ActionMethods for 'input' element
	 */
	public RpLoginPage typeTextIntoPassword(String textToEnter) throws Exception {
		// WebUtils.type(driver, txtPassword, textToEnter, "PasswordField");
		txtPassword.sendKeys(textToEnter);
		return this;
	}

	/**
	 * Adding ActionMethods for 'button' element
	 */
	public RpLoginPage clickLogInButton() throws Exception {
		btnLogIn.click();
		return this;
	}
}
