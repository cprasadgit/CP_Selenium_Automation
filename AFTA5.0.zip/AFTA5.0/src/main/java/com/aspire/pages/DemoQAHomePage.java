package com.aspire.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.epam.healenium.SelfHealingDriver;

public class DemoQAHomePage {

	private SelfHealingDriver driver;

	public DemoQAHomePage(SelfHealingDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = "div.category-cards div.card:nth-child(2)]")
	private WebElement btnForms;

	@FindBy(how = How.CSS, using = "div.category-cards div.card:nth-child(3)")
	private WebElement btnAlertsFrameAndWindows;

	@FindBy(how = How.CSS, using = "div.category-cards div.card:nth-child(4)]")
	private WebElement btnWidgets;

	public void clickFormsBtn() {
		btnForms.click();
	}

	public void clickAlertsFrameAndWindowsBtn() {
		btnAlertsFrameAndWindows.click();
	}

	public void clickWidgetsBtn() {
		btnWidgets.click();
	}

	public void clickAlertsFrameWindowsOption() {
		// TODO Auto-generated method stub
		
	}

}