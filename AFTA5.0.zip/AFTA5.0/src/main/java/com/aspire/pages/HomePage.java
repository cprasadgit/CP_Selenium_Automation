package com.aspire.pages;

import java.lang.String;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import com.epam.healenium.SelfHealingDriver;

public class HomePage{

	private SelfHealingDriver driver;
	
 	public HomePage(SelfHealingDriver driver) {
    	this.driver = driver;
    	PageFactory.initElements(driver, this);
  	}
  	
  	
 	@FindBy(how = How.CSS, using = "a[href='/?q=bloglisting']" )
  	private WebElement lnkBlog;
  	
  	@FindBy(how = How.CSS, using = "#footerMenu >a:nth-of-type(1)" )
  	private WebElement lnkHome;
  	
  	@FindBy(how = How.CSS, using = "a[href='https://www.aspiresys.com/careers']" )
  	private WebElement lnkCareers;
  	
  	@FindBy(how = How.CSS, using = "a[href='https://www.aspiresys.com/in-the-news']" )
  	private WebElement lnkInTheNews;
  	
  	@FindBy(how = How.CSS, using = "a[href='https://www.aspiresys.com/terms-of-use']" )
  	private WebElement lnkTermsOfUse;
  	
  	@FindBy(how = How.CSS, using = "a[href='https://www.aspiresys.com/privacy']" )
  	private WebElement lnkPrivacy;
  	
  	@FindBy(how = How.CSS, using = "a[href='https://www.aspiresys.com/sitemap']" )
  	private WebElement lnkSiteMap;
  	
  	@FindBy(how = How.CSS, using = "a[href='https://www.aspiresys.com/contact-us']" )
  	private WebElement lnkContactUs;
  	
  	
  	
    public void clickBlogLink() {
        lnkBlog.click();
    }
    
    public void clickHomeLink() {
        lnkHome.click();
    }
    
    public void clickCareersLink() {
        lnkCareers.click();
    }
    
    public void clickInTheNewsLink() {
        lnkInTheNews.click();
    }
    
    public void clickTermsOfUseLink() {
        lnkTermsOfUse.click();
    }
    
    public void clickPrivacyLink() {
        lnkPrivacy.click();
    }
    
    public void clickSiteMapLink() {
        lnkSiteMap.click();
    }
    
    public void clickContactUsLink() {
        lnkContactUs.click();
    }
    
	
	public String getPageTitle() {
		return this.driver.getTitle().trim();
	}
  	
}