package com.aspire.pojo;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RelatedNode {
	@JsonProperty("html")
	private String html;

	@JsonProperty("target")
	private ArrayList<String> target;

	// Getter and setter methods for 'html'
	public String getHtml() {
		return html;
	}

	public void setHtml(String html) {
		this.html = html;
	}

	// Getter and setter methods for 'target'
	public ArrayList<String> getTarget() {
		return target;
	}

	public void setTarget(ArrayList<String> target) {
		this.target = target;
	}
}
