package com.aspire.pojo;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class All {
	@JsonProperty("data")
	private Object data;

	@JsonProperty("id")
	private String id;

	@JsonProperty("impact")
	private String impact;

	@JsonProperty("message")
	private String message;

	@JsonProperty("relatedNodes")
	private ArrayList<RelatedNode> relatedNodes;

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ArrayList<RelatedNode> getRelatedNodes() {
		return relatedNodes;
	}

	public void setRelatedNodes(ArrayList<RelatedNode> relatedNodes) {
		this.relatedNodes = relatedNodes;
	}

}