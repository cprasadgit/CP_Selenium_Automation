package com.aspire.pojo;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Inapplicable {
	@JsonProperty("description")
	private String description;

	@JsonProperty("help")
	private String help;

	@JsonProperty("helpUrl")
	private String helpUrl;

	@JsonProperty("id")
	private String id;

	@JsonProperty("impact")
	private Object impact;

	@JsonProperty("nodes")
	private ArrayList<Object> nodes;

	@JsonProperty("tags")
	private ArrayList<String> tags;

	// Getter and setter methods for 'description'
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	// Getter and setter methods for 'help'
	public String getHelp() {
		return help;
	}

	public void setHelp(String help) {
		this.help = help;
	}

	// Getter and setter methods for 'helpUrl'
	public String getHelpUrl() {
		return helpUrl;
	}

	public void setHelpUrl(String helpUrl) {
		this.helpUrl = helpUrl;
	}

	// Getter and setter methods for 'id'
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	// Getter and setter methods for 'impact'
	public Object getImpact() {
		return impact;
	}

	public void setImpact(Object impact) {
		this.impact = impact;
	}

	// Getter and setter methods for 'nodes'
	public ArrayList<Object> getNodes() {
		return nodes;
	}

	public void setNodes(ArrayList<Object> nodes) {
		this.nodes = nodes;
	}

	// Getter and setter methods for 'tags'
	public ArrayList<String> getTags() {
		return tags;
	}

	public void setTags(ArrayList<String> tags) {
		this.tags = tags;
	}
}
