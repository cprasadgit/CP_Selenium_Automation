package com.aspire.pojo;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Map;

import com.aspire.utils.IPropertiesReader;
import com.aspire.utils.PropertiesReaderUtil;

public class PerformanceTestResult {

	private static IPropertiesReader configInterface = PropertiesReaderUtil.getInstance();
	public static String filePath = "perfmetrics";
	public static String fileName = "PerfReport.xlsx";

	@Key("Request")
	public String request;

	@Key("Browser")
	public String browser;

	@Key("Type")
	public String type;

	@Key("No of Request")
	public String noOfRequest;

	@Key("Fully Loaded(ms)")
	public String fullLoaded;

	@Key("TimeTo FirstByte(ms)")
	public String timeToFirstByte;

	@Key("First Paint(ms)")
	public String firstPaint;

	@Key("First Contentful Paint(ms)")
	public String firstContentfulPaint;

	@Key("DOM Interactive(ms)")
	public String DOMInteractive;

	@Key("DOM Content Loaded(ms)")
	public String DOMContentLoaded;

	@Key("DOM Complete(ms)")
	public String DOMComplete;

	@Key("OnLoad Time(ms)")
	public String onLoadTime;

	@Key("Transfer Size(byte)")
	public String transferSize;

	@Key("90 Percentile(ms)")
	public String nintyPercentile;

	@Key("95 Percentile(ms)")
	public String nintyFivePercentile;

	public PerformanceTestResult(Map<String, String> values) throws IOException {
		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			if (field.isAnnotationPresent(Key.class)) {
				String key = field.getAnnotation(Key.class).value();
				field.setAccessible(true);
				try {
					field.set(this, values.get(key));
				} catch (IllegalArgumentException | IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}

}
