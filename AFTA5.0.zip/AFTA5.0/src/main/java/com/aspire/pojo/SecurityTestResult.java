package com.aspire.pojo;

public class SecurityTestResult {
	public String pageName;

	public int high = 0;
	public int medium = 0;
	public int low = 0;
	public int informational = 0;

	public String reportLink;

	public SecurityTestResult(String pageName, int high, int medium, int low, int informational, String reportLink) {
		this.pageName = pageName;
		this.high = high;
		this.medium = medium;
		this.low = low;
		this.informational = informational;
		this.reportLink = reportLink;
	}

}
