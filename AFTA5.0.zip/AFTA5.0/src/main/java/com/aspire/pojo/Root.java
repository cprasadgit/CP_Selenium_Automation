package com.aspire.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Root {
	@JsonProperty("inapplicable")
	private List<Inapplicable> inapplicable;

	@JsonProperty("incomplete")
	private List<Incomplete> incomplete;

	@JsonProperty("passes")
	private List<Pass> passes;

	@JsonProperty("timestamp")
	private Date timestamp;

	@JsonProperty("url")
	private String url;

	@JsonProperty("violations")
	private List<Violation> violations;

	// Getter and setter methods for 'inapplicable'
	public List<Inapplicable> getInapplicable() {
		return inapplicable;
	}

	public void setInapplicable(ArrayList<Inapplicable> inapplicable) {
		this.inapplicable = inapplicable;
	}

	// Getter and setter methods for 'incomplete'
	public List<Incomplete> getIncomplete() {
		return incomplete;
	}

	public void setIncomplete(ArrayList<Incomplete> incomplete) {
		this.incomplete = incomplete;
	}

	// Getter and setter methods for 'passes'
	public List<Pass> getPasses() {
		return passes;
	}

	public void setPasses(List<Pass> passes) {
		this.passes = passes;
	}

	// Getter and setter methods for 'timestamp'
	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	// Getter and setter methods for 'url'
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	// Getter and setter methods for 'violations'
	public List<Violation> getViolations() {
		return violations;
	}

	public void setViolations(List<Violation> violations) {
		this.violations = violations;
	}
}
