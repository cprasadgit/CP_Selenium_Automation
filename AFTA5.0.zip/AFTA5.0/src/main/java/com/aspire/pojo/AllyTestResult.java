package com.aspire.pojo;

public class AllyTestResult {

	public String pageName;

	public int critical = 0;
	public int serious = 0;
	public int moderate = 0;
	public int minor = 0;
	public String reportLink = "";

	public AllyTestResult(String pageName, Root root, String reportLink) {
		this.pageName = pageName;
		this.reportLink = reportLink;
		root.getViolations().stream().forEach(violation -> {

			switch (violation.getImpact()) {
			case "critical":
				this.critical += 1;
				break;

			case "serious":
				this.serious += 1;
				break;

			case "moderate":
				this.moderate += 1;
				break;

			case "minor":
				this.minor += 1;
				break;

			default:
				break;

			}

		});
	}

}
