package com.aspire.pojo;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Node {
	@JsonProperty("all")
	private ArrayList<Object> all;

	@JsonProperty("any")
	private ArrayList<Any> any;

	@JsonProperty("html")
	private String html;

	@JsonProperty("impact")
	private String impact;

	@JsonProperty("none")
	private ArrayList<None> none;

	@JsonProperty("target")
	private ArrayList<String> target;

	@JsonProperty("failureSummary")
	private String failureSummary;

	// Getter and setter methods for 'all'
	public ArrayList<Object> getAll() {
		return all;
	}

	public void setAll(ArrayList<Object> all) {
		this.all = all;
	}

	// Getter and setter methods for 'any'
	public ArrayList<Any> getAny() {
		return any;
	}

	public void setAny(ArrayList<Any> any) {
		this.any = any;
	}

	// Getter and setter methods for 'html'
	public String getHtml() {
		return html;
	}

	public void setHtml(String html) {
		this.html = html;
	}

	// Getter and setter methods for 'impact'
	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	// Getter and setter methods for 'none'
	public ArrayList<None> getNone() {
		return none;
	}

	public void setNone(ArrayList<None> none) {
		this.none = none;
	}

	// Getter and setter methods for 'target'
	public ArrayList<String> getTarget() {
		return target;
	}

	public void setTarget(ArrayList<String> target) {
		this.target = target;
	}

	// Getter and setter methods for 'failureSummary'
	public String getFailureSummary() {
		return failureSummary;
	}

	public void setFailureSummary(String failureSummary) {
		this.failureSummary = failureSummary;
	}
}
