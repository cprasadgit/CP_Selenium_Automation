package com.aspire.pojo;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Any {
	@JsonProperty("data")
	private Object data;

	@JsonProperty("id")
	private String id;

	@JsonProperty("impact")
	private String impact;

	@JsonProperty("message")
	private String message;

	@JsonProperty("relatedNodes")
	private ArrayList<RelatedNode> relatedNodes;

	// Getter and setter methods for 'data'
	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	// Getter and setter methods for 'id'
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	// Getter and setter methods for 'impact'
	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	// Getter and setter methods for 'message'
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	// Getter and setter methods for 'relatedNodes'
	public ArrayList<RelatedNode> getRelatedNodes() {
		return relatedNodes;
	}

	public void setRelatedNodes(ArrayList<RelatedNode> relatedNodes) {
		this.relatedNodes = relatedNodes;
	}
}
