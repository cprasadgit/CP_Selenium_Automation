package com.aspire.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Data {
	@JsonProperty("bgColor")
	private String bgColor;

	@JsonProperty("contrastRatio")
	private int contrastRatio;

	@JsonProperty("expectedContrastRatio")
	private String expectedContrastRatio;

	@JsonProperty("fgColor")
	private String fgColor;

	@JsonProperty("fontSize")
	private String fontSize;

	@JsonProperty("fontWeight")
	private String fontWeight;

	@JsonProperty("missingData")
	private String missingData;

	// Getter and setter methods for 'bgColor'
	public String getBgColor() {
		return bgColor;
	}

	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}

	// Getter and setter methods for 'contrastRatio'
	public int getContrastRatio() {
		return contrastRatio;
	}

	public void setContrastRatio(int contrastRatio) {
		this.contrastRatio = contrastRatio;
	}

	// Getter and setter methods for 'expectedContrastRatio'
	public String getExpectedContrastRatio() {
		return expectedContrastRatio;
	}

	public void setExpectedContrastRatio(String expectedContrastRatio) {
		this.expectedContrastRatio = expectedContrastRatio;
	}

	// Getter and setter methods for 'fgColor'
	public String getFgColor() {
		return fgColor;
	}

	public void setFgColor(String fgColor) {
		this.fgColor = fgColor;
	}

	// Getter and setter methods for 'fontSize'
	public String getFontSize() {
		return fontSize;
	}

	public void setFontSize(String fontSize) {
		this.fontSize = fontSize;
	}

	// Getter and setter methods for 'fontWeight'
	public String getFontWeight() {
		return fontWeight;
	}

	public void setFontWeight(String fontWeight) {
		this.fontWeight = fontWeight;
	}

	// Getter and setter methods for 'missingData'
	public String getMissingData() {
		return missingData;
	}

	public void setMissingData(String missingData) {
		this.missingData = missingData;
	}
}
