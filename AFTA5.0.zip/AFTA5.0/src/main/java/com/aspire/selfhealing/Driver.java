package com.aspire.selfhealing;

import org.openqa.selenium.WebDriver;

import com.epam.healenium.SelfHealingDriver;

public interface Driver extends WebDriver, SelfHealingDriver{

	public Driver getDriverInstance();
	
}
