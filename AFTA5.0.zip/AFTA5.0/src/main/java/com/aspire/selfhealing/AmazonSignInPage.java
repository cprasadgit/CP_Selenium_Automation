package com.aspire.selfhealing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.epam.healenium.SelfHealingDriver;

public class AmazonSignInPage {
	private WebDriver driver;

	@FindBy(how = How.ID, using = "ap_email")
	private WebElement txtEmailOrMobilePhoneNumber1;

	@FindBy(how = How.ID, using = "continue")
	private WebElement btnByContinuingYouAgreeToAmazonsConditionsOfUseAnd;

	@FindBy(how = How.ID, using = "createAccountSubmit")
	private WebElement lnkCreateYourAmazonAccount;

	/**
	 * Constructor
	 */
	public AmazonSignInPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/**
	 * Adding ActionMethods for 'input' element
	 */
	public AmazonSignInPage typeTextIntoEmailOrMobilePhoneNumber1(String textToEnter) throws Exception {
		txtEmailOrMobilePhoneNumber1.sendKeys(textToEnter);
		return this;
	}

	/**
	 * Adding ActionMethods for 'button' element
	 */
	public AmazonSignInPage clickByContinuingYouAgreeToAmazonsConditionsOfUseAndButton() throws Exception {
		btnByContinuingYouAgreeToAmazonsConditionsOfUseAnd.click();
		return this;
	}

	/**
	 * Adding ActionMethods for 'Link' element
	 */
	public AmazonSignInPage clickCreateYourAmazonAccountLink() throws Exception {
		lnkCreateYourAmazonAccount.click();
		return this;
	}
}
