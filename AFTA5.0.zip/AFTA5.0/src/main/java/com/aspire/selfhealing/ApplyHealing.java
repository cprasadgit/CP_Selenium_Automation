package com.aspire.selfhealing;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.aspire.utils.IPropertiesReader;
import com.aspire.utils.PropertiesReaderUtil;
import com.aspire.utils.api.APIUtil;
import com.aspire.utils.testdata.WorkBookUtils;

import io.restassured.response.Response;

public class ApplyHealing {

	private static String srcFolderPath = "src\\main\\java\\";
	private static String reportFilePath = System.getProperty("user.dir") + File.separatorChar + "src\\main\\resources"
			+ File.separatorChar + "HealingReport.xlsx";
	private static IPropertiesReader propertiesReader = PropertiesReaderUtil.getInstance();
	static List<String> classNamesToAvoid = List.of(propertiesReader.hlmClassToAvoid().split(","));
	private static final String UPDATEHEALEDLOCATOR = "UpdateHealedLocator";

	public static void getLocators() throws IOException {
		String projectName = propertiesReader.hlmProjectName();

		// Making a GET request to the API
		Response response = APIUtil.get(propertiesReader.hlmUrl(), propertiesReader.hlmResultsEndpoint());

		// Parsing the response as a List of Maps
		List<Map<String, ?>> jsonResponse = response.jsonPath().getList("$");

		// Map to hold className as key and its corresponding data as value
		Map<String, List<Map<String, ?>>> groupedData = filterAndGroupData(jsonResponse, projectName);

		// Initialize WorkBookUtils
		WorkBookUtils workBook = initializeWorkBook();

		// Printing grouped data by className
		printGroupedData(groupedData, workBook);
	}

	private static Map<String, List<Map<String, ?>>> filterAndGroupData(List<Map<String, ?>> jsonResponse,
			String projectName) {
		Map<String, List<Map<String, ?>>> groupedData = new HashMap<>();

		for (Map<String, ?> element : jsonResponse) {
			String className = (String) element.get("className");

			if (!classNamesToAvoid.contains(className)
					&& projectName.equalsIgnoreCase(getCurrentProjectName(className))) {
				groupedData.computeIfAbsent(className, k -> new ArrayList<>()).add(element);
			}
		}

		return groupedData;
	}

	private static String getCurrentProjectName(String className) {
		return className.split("\\.")[1];
	}

	private static WorkBookUtils initializeWorkBook() throws IOException {
		WorkBookUtils workBook = WorkBookUtils.getWorkBook(new File(reportFilePath));
		new File(reportFilePath).delete(); // Delete the file before updating

		return workBook;
	}

	private static void printGroupedData(Map<String, List<Map<String, ?>>> groupedData, WorkBookUtils workBook) {
		for (String className : groupedData.keySet()) {
			int rowIndex = 1;
			String pageName = getPageName(className);

			workBook.addRowValuesToSheet(pageName, List.of("S.No", "PackageName", "ClassName", "MethodName",
					"HealingSuccess", "Locator", "HealedLocator", "LocatorType", UPDATEHEALEDLOCATOR), 0, 0);

			List<Map<String, ?>> classData = groupedData.get(className);

			for (Map<String, ?> data : classData) {
				String methodName = (String) data.get("methodName");
				String locatorValue = (String) data.get("locator");

				List<Map<String, ?>> results = (List<Map<String, ?>>) data.get("results");
				printResults(workBook, rowIndex, pageName, className, methodName, locatorValue, results);
				rowIndex++;
			}
		}
		workBook.writeToFile();
	}

	private static String getPageName(String className) {
		String[] pageNames = className.split("\\.");
		return pageNames[pageNames.length - 1];
	}

	private static void printResults(WorkBookUtils workBook, int rowIndex, String pageName, String className,
			String methodName, String locatorValue, List<Map<String, ?>> results) {
		for (Map<String, ?> result : results) {
			Map<String, String> locator = (Map<String, String>) result.get("locator");
			String value = locator.get("value");
			String type = locator.get("type").split("By.")[1].trim();
			if (type.toLowerCase().startsWith("css"))
				type = "CSS";

			boolean successHealing = (Boolean) result.get("successHealing");

			workBook.addRowValuesToSheet(pageName, List.of(rowIndex, className, pageName, methodName + "()",
					successHealing, locatorValue, value, type.toUpperCase(), ""), rowIndex, 0);
		}
	}

	public static void applyHealingToClass() throws IOException {
		WorkBookUtils workBook = WorkBookUtils.getWorkBook(new File(reportFilePath));

		IntStream.range(0, workBook.getSheetCount()).forEach(sheetCount -> {
			String sheetName = workBook.getSheetName(sheetCount).split("\\.")[0];

			List<Map<String, String>> healedLocators = workBook.fetchSheetData(sheetName);

			healedLocators.forEach(entry -> {
				if (Objects.nonNull(entry.get(UPDATEHEALEDLOCATOR))
						&& entry.get(UPDATEHEALEDLOCATOR).equalsIgnoreCase("yes")) {
					// get package/class name to replace webelement locator
					String packageName = entry.get("PackageName").trim();
					// String className = entry.get("ClassName").trim();
					String failedLocator = entry.get("Locator").trim();
					String healedLocator = entry.get("HealedLocator").trim();
					String locatorType = entry.get("LocatorType").trim();
					// String updateHealedLocator = entry.get(UPDATEHEALEDLOCATOR).trim();

					updateLocatorInFile(packageName, failedLocator, healedLocator, locatorType);
				}
			});

		});
	}

	private static void updateLocatorInFile(String packageName, String failedLocator, String healedLocator,
			String locatorType) {
		try {

			String packagesAsFolders = packageName.replace('.', '\\');
			String absolutePathOfFile = srcFolderPath + packagesAsFolders + ".java";

			File javaFile = new File(absolutePathOfFile);

			Path pathOfJavaFile = Paths.get(javaFile.toURI());

			Stream<String> lines = Files.lines(pathOfJavaFile);
			// data = lines.collect(Collectors.joining("\n"));

			// Convert a Stream to List
			List<String> lineList = lines.collect(Collectors.toList());

			for (int i = 0; i < lineList.size(); i++) {
				if (lineList.get(i).trim().startsWith("@FindBy") && lineList.get(i).contains(failedLocator)) {
					String commentLine = "\t" + "// {Self-Healing} - Auto updated healed locator below"
							+ System.lineSeparator();
					String failedLocatorLineAsComment = "\t" + "//" + lineList.get(i).trim() + System.lineSeparator();
					String updatedLocatorLine = commentLine + failedLocatorLineAsComment + "\t" + "@FindBy(how = How."
							+ locatorType.toUpperCase() + ", using = \"" + healedLocator + "\")";

					lineList.set(i, updatedLocatorLine);
				}
			}

			lines.close();
			// delete exising file and write new file with updated healed locator
			Files.deleteIfExists(pathOfJavaFile);
			Files.createFile(pathOfJavaFile);
			for (String line : lineList) {
				Files.writeString(pathOfJavaFile, line + System.lineSeparator(), StandardOpenOption.APPEND);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
