package com.aspire.selfhealing;

import java.net.MalformedURLException;

import com.aspire.utils.web.WebDriverFactory;
import com.epam.healenium.SelfHealingDriver;

public class AftaDriver {

	private static boolean healingDriver = false;

	public static Driver getDriverInstance() throws MalformedURLException {
		Driver driver = null;

		if (healingDriver == true)
			driver = (Driver) SelfHealingDriver.create(WebDriverFactory.get());
		else
			driver = (Driver) WebDriverFactory.get();
			

		return driver;
	}

}
