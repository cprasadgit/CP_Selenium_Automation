package com.aspire.template.tests;

import java.util.Date;

public class User {
	public String name;
	public String job;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}


	public User(){
	}

	public User(String name, String job) {
		this.name = name;
		this.job = job;
	}

//	public User(String name, String job, String id, Date createdAt) {
//		this.name = name;
//		this.job = job;
//		this.id = id;
//		this.createdAt = createdAt;
//	}
}
