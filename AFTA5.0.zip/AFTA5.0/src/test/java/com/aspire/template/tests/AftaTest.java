package com.aspire.template.tests;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

import com.aspire.utils.Log;

public class AftaTest {

	@BeforeMethod
	protected void setThreadName(Method method) {
		Log.setThreadNameAsMethodName(method.getName());
	}

	protected void handleCatchBlock(Exception e) {
		Log.fail(e.getMessage());
		Assert.fail("TestScript Failed", e);
	}

}
