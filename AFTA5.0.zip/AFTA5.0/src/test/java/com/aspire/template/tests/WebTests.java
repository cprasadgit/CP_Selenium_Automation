package com.aspire.template.tests;

import java.net.MalformedURLException;
import java.util.List;
import java.util.Optional;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v120.performance.Performance;
import org.openqa.selenium.devtools.v120.performance.model.Metric;
import org.openqa.selenium.remote.Augmenter;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aspire.pages.DemoQAAlertsFromAndWindowsPage;
import com.aspire.pages.DemoQAHomePage;
import com.aspire.pages.DemoQAPracticeForm;
import com.aspire.pages.DemoQAWidgetsPage;
import com.aspire.pages.HomePage;
import com.aspire.utils.Log;
import com.aspire.utils.web.WebDriverFactory;
import com.aspire.utils.web.WebUtils;
import com.epam.healenium.SelfHealingDriver;

public class WebTests extends AftaTest {

	String webSite = "https://systems.aspiresys.com";
	String demoQAWebSite = "https://demoqa.com/";

	@Test
	public void TC_DemoQA_03_AI() throws MalformedURLException {
		
		SelfHealingDriver driver = null;
		try {
	    // Launch browser and navigate to URL
	    driver = SelfHealingDriver.create(WebDriverFactory.get());
	    driver.get(demoQAWebSite);

	    // Land on Home page.
	    DemoQAHomePage demoQAHomePage = new DemoQAHomePage(driver);

	    // Click 'Alerts, Frame & windows' option in homepage
	    demoQAHomePage.clickAlertsFrameWindowsOption();

	    // Create object for DemoQAAlertsFromAndWindowsPage
	    DemoQAAlertsFromAndWindowsPage alertsPage = new DemoQAAlertsFromAndWindowsPage(driver);

	    // Click 'Alerts' option in left facet
	    alertsPage.clickAlertsOption();

	    // Click 'Click me' button for On button click, confirm box will appear option
	    alertsPage.clickConfirmBoxClickMeButton();

	    // Click 'Ok' button in the alert box
	    driver.switchTo().alert().accept();

	    // Verify the 'You selected Ok' message is displayed
	    Assert.assertTrue(alertsPage.verifySuccessMessageOnConfirmAlert());

	    // Click 'Click me' button for On button click, prompt box will appear option
	    alertsPage.clickPromptBoxClickMeButton();

	    // Enter 'Mathan' in the alert textbox
	    alertsPage.enterValueInPromptBox("Mathan");

	    // Click ok button in the alert box
	    driver.switchTo().alert().accept();

	    // Verify that success message with entered value is displayed 'You entered Mathan' 
	    Assert.assertTrue(alertsPage.verifySuccessMessageOnPromptBox());

	    driver.quit();
		} catch (Exception e) {
			handleCatchBlock(e);
		} finally {
			driver.quit();
		}
	}
	
	@Test
	public void TC01() {
		SelfHealingDriver driver = null;
		String expectedTitle = "Careers";
		try {
			Log.testCaseInfo("Check page navigation to Carrers page");

			// Launch browser
			driver = SelfHealingDriver.create(WebDriverFactory.get());

			// Navigate to webSite
			driver.get(webSite);

			HomePage homePage = new HomePage(driver);

			// click on Carrers link
			homePage.clickCareersLink();

			// switch to new tab
			WebUtils.switchToSecondTab(driver);

			// verify title of the page
			Log.assertThat(homePage.getPageTitle().contains(expectedTitle), "The page title includes " + expectedTitle,
					"The page title doesn't includes " + expectedTitle);

			Log.testCaseResult(driver);
		} catch (Exception e) {
			handleCatchBlock(e);
		} finally {
			driver.quit();
		}
	}

	@Test
	public void TC_DemoQA_02() {
		SelfHealingDriver driver = null;
		String firstName = "sam";
		String lastName = "daniel";
		String email = "demoqa@gmail.com";
		String mobileNumber = "9878738478";
		String dob = "22 Aug 1998";
		String stateName = "Haryana";

		try {
			Log.testCaseInfo("Submit the Practice form in DemoQA Website");

			// Launch browser
			driver = SelfHealingDriver.create(WebDriverFactory.get());

			// Navigate to webSite
			driver.get(demoQAWebSite);

			DemoQAHomePage demoQAHomePage = new DemoQAHomePage(driver);

			// Click on Forms Btn
			demoQAHomePage.clickFormsBtn();

			DemoQAPracticeForm demoQAPracticeForm = new DemoQAPracticeForm(driver);

			// click on Practice form button
			demoQAPracticeForm.clickPracticeForm();

			// Enter value in FirstName textbox
			demoQAPracticeForm.enterFirstName(firstName);

			// Enter value in LastName textbox
			demoQAPracticeForm.enterLastName(lastName);

			// Enter value in Email textbox
			demoQAPracticeForm.enterEmailAddress(email);

			// Click on Radio button for Male gender
			demoQAPracticeForm.clickMaleRadioButton();

			// Enter value for Mobile Number textbox
			demoQAPracticeForm.enterMobileNumber(mobileNumber);

			// Enter value for Date of Birth
			demoQAPracticeForm.enterDateOfBirth(dob);

			// Select value State dropdown
			demoQAPracticeForm.selectState(stateName);

			// Click on Submit button
			demoQAPracticeForm.clickSubmitBtn();

			// verify Form Submitted Popup is displayed
			Log.assertThat(demoQAPracticeForm.verifyFormSubmittedPopUpisDisplayed(),
					"PASSED!!! Practice form is submitted successfully", "FAILED !!! Practice form is not submitted");

			Log.testCaseResult(driver);
		} catch (Exception e) {
			handleCatchBlock(e);

		} finally {
			driver.quit();
		}
	}

	@Test
	public void TC_DemoQA_03() {
		SelfHealingDriver driver = null;

		try {
			Log.testCaseInfo("Verify the browser windows actions");

			// Launch browser
			driver = SelfHealingDriver.create(WebDriverFactory.get());

			// Navigate to webSite
			driver.get("https://demoqa.com/");

			DemoQAHomePage demoQAHomePage = new DemoQAHomePage(driver);

			demoQAHomePage.clickAlertsFrameAndWindowsBtn();

			DemoQAAlertsFromAndWindowsPage demoQAAlertsFromAndWindowsPage = new DemoQAAlertsFromAndWindowsPage(driver);

			demoQAAlertsFromAndWindowsPage.clickBrowserWindowsOption();

			demoQAAlertsFromAndWindowsPage.clickNewTabButton();

			Log.assertThat(demoQAAlertsFromAndWindowsPage.verifyNewTabisOpened(),
					"PASSED : 1 - New Tab is opened successfully", "FAILED : 1 - New Tab is not opened");

			driver.close();

			demoQAAlertsFromAndWindowsPage.clickNewWindowButton();

			Log.assertThat(demoQAAlertsFromAndWindowsPage.verifyNewTabisOpened(),
					"PASSED : 2 - New Window is opened successfully", "FAILED : 2 - New Window is not opened");

			driver.close();

			demoQAAlertsFromAndWindowsPage.clickNewWindowWithMessage();

			Log.assertThat(demoQAAlertsFromAndWindowsPage.verifyNewWindowWithMessage(),
					"PASSED : 3 - New Window is opened with message successfully",
					"FAILED : 3 - New Tab is not opened with message");

			Log.testCaseResult(driver);
		} catch (Exception e) {
			handleCatchBlock(e);

		} finally {
			driver.quit();
		}
	}

	@Test
	public void TC_DemoQA_04() {
		SelfHealingDriver driver = null;
		String value = "Aspire";

		try {
			Log.testCaseInfo("Verify the alerts in demoQA website");

			// Launch browser
			driver = SelfHealingDriver.create(WebDriverFactory.get());

			// Navigate to webSite
			driver.get("https://demoqa.com/");

			DemoQAHomePage demoQAHomePage = new DemoQAHomePage(driver);

			demoQAHomePage.clickAlertsFrameAndWindowsBtn();

			DemoQAAlertsFromAndWindowsPage demoQAAlertsFromAndWindowsPage = new DemoQAAlertsFromAndWindowsPage(driver);

			demoQAAlertsFromAndWindowsPage.clickAlertsOption();

			demoQAAlertsFromAndWindowsPage.clickConfirmBoxClickMeButton();

			demoQAAlertsFromAndWindowsPage.acceptConfirmAlert();

			Log.assertThat(demoQAAlertsFromAndWindowsPage.verifySuccessMessageOnConfirmAlert(),
					"PASSED : 1 - Success message is Displayed", "FAILED : 1 - Success Message is not displayed");

			demoQAAlertsFromAndWindowsPage.clickPromptBoxClickMeButton();

			demoQAAlertsFromAndWindowsPage.enterValueInPromptBox(value);

			Log.assertThat(demoQAAlertsFromAndWindowsPage.verifySuccessMessageOnPromptBox(),
					"PASSED : 2 - Success message is displayed for Prompt Box",
					"FAILED : 2 - Success message is not displayed for Prompt Box");

			Log.testCaseResult(driver);
		} catch (Exception e) {
			handleCatchBlock(e);

		} finally {
			driver.quit();
		}
	}

	@Test
	public void TC_DemoQA_05() {
		SelfHealingDriver driver = null;
		String value1 = "r";
		String value2 = "g";
		String value3 = "y";

		try {
			Log.testCaseInfo("Verify Auto complete and tool tips");

			// Launch browser
			driver = SelfHealingDriver.create(WebDriverFactory.get());

			// Navigate to webSite
			driver.get("https://demoqa.com/");

			DemoQAHomePage demoQAHomePage = new DemoQAHomePage(driver);

			demoQAHomePage.clickWidgetsBtn();

			DemoQAWidgetsPage demoQAWidgetsPage = new DemoQAWidgetsPage(driver);

			demoQAWidgetsPage.clickAutoCompleteOption();

			demoQAWidgetsPage.enterMulipleValuesInTextBox(value1, value2, value3);

			demoQAWidgetsPage.enterSingleValuesInTextBox(value1);

			demoQAWidgetsPage.clickToolTipsButton();

			Log.assertThat(demoQAWidgetsPage.verifyMessageOnMouseHover(),
					"PASSED !!! Message is displayed successfully", "FAILED !!! Message is not displayed");

			Log.testCaseResult(driver);
		} catch (Exception e) {
			handleCatchBlock(e);

		} finally {
			driver.quit();
		}
	}

}
