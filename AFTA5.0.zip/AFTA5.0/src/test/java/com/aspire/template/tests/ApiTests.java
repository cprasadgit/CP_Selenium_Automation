package com.aspire.template.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.testng.annotations.Test;

import com.aspire.utils.Log;
import com.aspire.utils.api.APIUtil;
import com.aspire.utils.testdata.TestDataReader;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class ApiTests extends AftaTest {

	String baseURL = "https://reqres.in/";
	String baseURLforPET = "https://petstore.swagger.io/";
	String baseURLforTestFire = "https://demo.testfire.net/";

	@Test
	public void TC_GET() {

		String getUsersEndpoint = "/api/users/";
		try {
			Log.testCaseInfo("Sample GET request");

			Response response = APIUtil.get(baseURL, getUsersEndpoint);
			int receivedStatusCode = response.getStatusCode();

			Log.assertThat(receivedStatusCode == 200,
					"Expected status code(200) is received upon hiting the endpoint- " + getUsersEndpoint,
					"Unexpected status code " + receivedStatusCode + " is received upon hiting the endpoint- "
							+ getUsersEndpoint);

			Log.testCaseResult();
		} catch (Exception e) {
			handleCatchBlock(e);
		} finally {
		}
	}

	@Test
	public void TC_POST() throws Exception {
		String createUserEndpoint = "/api/users/";
		try {
			Log.testCaseInfo("Sample POST request");

			User userData = new User();
			userData.setName("DummyUser");
			userData.setJob("Test Engineer");

			// Creating the ObjectMapper object
			ObjectMapper mapper = new ObjectMapper();
			// Converting the Object to JSONString
			String userDataJson = mapper.writeValueAsString(userData);

			Map<String, String> header = new HashMap<String, String>();
			header.put("Content-Type", "application/json");

			Response response = APIUtil.postWithBody(baseURL, header, userDataJson, createUserEndpoint);
			int receivedStatusCode = response.getStatusCode();

			Log.assertThat(receivedStatusCode == 201,
					"Expected status code(201) is received upon hiting the endpoint- " + createUserEndpoint,
					"Unexpected status code " + receivedStatusCode + " is received upon hiting the endpoint- "
							+ createUserEndpoint);

			Log.testCaseResult();
		} catch (Exception e) {
			handleCatchBlock(e);
		} finally {
		}
	}

	@Test
	public void TC_PUT() throws Exception {
		String updateUserEndpoint = "/api/users/2";
		try {
			Log.testCaseInfo("Sample PUT request");

			User userData = new User();
			userData.setName("DummyUser");
			userData.setJob("Test Engineer");

			// Creating the ObjectMapper object
			ObjectMapper mapper = new ObjectMapper();
			// Converting the Object to JSONString
			String userDataJson = mapper.writeValueAsString(userData);

			Map<String, String> header = new HashMap<String, String>();
			header.put("Content-Type", "application/json");

			Response response = APIUtil.putWithBody(baseURL, header, userDataJson, updateUserEndpoint);
			int receivedStatusCode = response.getStatusCode();

			ResponseBody responseBody = response.getBody();
			String f = responseBody.asPrettyString();

			Log.assertThat(receivedStatusCode == 200,
					"Expected status code(200) is received upon hiting the endpoint- " + updateUserEndpoint,
					"Unexpected status code " + receivedStatusCode + " is received upon hiting the endpoint- "
							+ updateUserEndpoint);

			Log.testCaseResult();
		} catch (Exception e) {
			handleCatchBlock(e);
		} finally {
		}
	}

	@Test
	public void GetPetDeatilsByID() {

		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		int petId = (int) Math.round(Double.parseDouble(testData.get("PetId")));
		String endPoint = String.format(testData.get("EndPoint"), petId);

		try {
			Log.testCaseInfo("TC01 : Verify 200 response for GET PetId  request and verify the pet details");

			Response response = APIUtil.get(baseURLforPET, endPoint);

			int receivedStatusCode = response.getStatusCode();
			int actualPetId = response.jsonPath().getInt("id");

			Log.assertThat(actualPetId == petId, "Verified getting pet details by Id :" + actualPetId,
					"Getting Wrong data actual: " + actualPetId + "Expected " + petId);

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Test
	public void CreatePet() {
		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		String endPoint = testData.get("EndPoint");
		String name = testData.get("PetName");
		String status = testData.get("PetStatus");
		String categoryName = testData.get("CategoryName");
		String tagName = testData.get("TagName");

		try {
			Log.testCaseInfo(
					"TC02 : Verify 200 response  for Add new pet to the store POST Request and verify the pet details created in the response");

			Random random = new Random();

			// Generate a random 5-digit number
			int petId = 10000 + random.nextInt(90000);

			HashMap<String, String> headers = new HashMap<String, String>();
			headers.put(ApiTestdata.ContentType, ApiTestdata.Application_Json);
			CreatePet pet = new CreatePet();
			Category category = new Category();
			Tag tag = new Tag();
			ArrayList<Tag> taglist = new ArrayList<Tag>();
			category.setId(petId);
			category.setName(categoryName);

			tag.setId(petId);
			tag.setName(tagName);

			taglist.add(tag);
			pet.setId(petId);
			pet.setName(name);
			pet.setStatus(status);
			pet.setCategory(category);
			pet.setPhotoUrls(new ArrayList<String>());

			ObjectMapper objectMapper = new ObjectMapper();
			String RequestBody = objectMapper.writeValueAsString(pet);

			Response response = APIUtil.postWithBody(baseURLforPET, headers, RequestBody, endPoint);

			int receivedStatusCode = response.getStatusCode();
			int actualPetId = response.jsonPath().getInt("id");

			Log.assertThat(actualPetId == petId, "Created pet successfully with petId :" + actualPetId,
					"Unable to create pet details check the request body");

			System.out.println(receivedStatusCode);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Test
	public void updatePetDetails() {

		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		String endPoint = testData.get("EndPoint");
		String name = testData.get("PetName");
		String status = testData.get("PetStatus");
		String categoryName = testData.get("CategoryName");
		String tagName = testData.get("TagName");
		int petId = (int) Math.round(Double.parseDouble(testData.get("PetId")));

		try {
			Log.testCaseInfo(
					"TC03 : Veriy 200 response  for update a pet in the store with form data  POST API and verify the updated pet details");

			HashMap<String, String> headers = new HashMap<String, String>();
			headers.put(ApiTestdata.ContentType, ApiTestdata.Application_Json);
			CreatePet pet = new CreatePet();
			Category category = new Category();
			Tag tag = new Tag();
			ArrayList<Tag> taglist = new ArrayList<Tag>();
			category.setId(petId);
			category.setName(categoryName);

			tag.setId(petId);
			tag.setName(tagName);

			taglist.add(tag);
			pet.setId(petId);
			pet.setName(name);
			pet.setStatus(status);
			pet.setCategory(category);
			pet.setPhotoUrls(new ArrayList<String>());

			ObjectMapper objectMapper = new ObjectMapper();
			String RequestBody = objectMapper.writeValueAsString(pet);

			Response response = APIUtil.putWithBody(baseURLforPET, headers, RequestBody, endPoint);

			int receivedStatusCode = response.getStatusCode();
			int actualPetId = response.jsonPath().getInt("id");
			String UpdatedName = response.jsonPath().getString("name");
			System.out.println(UpdatedName);

			Log.assertThat(actualPetId == petId && UpdatedName.equals(name),
					"Updated pet details successfully for petId :" + actualPetId,
					"Getting Wrong data actual petId: " + actualPetId + " Expected " + petId);

			System.out.println(receivedStatusCode);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Test
	public void GetPetDeatilsByWrongID() {

		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		String endPoint = testData.get("EndPoint");
		int expectedStatusCode = (int) Math.round(Double.parseDouble(testData.get("ExpectedStatusCode")));
		int petId = (int) Math.round(Double.parseDouble(testData.get("PetId")));
		String endPointWithId = String.format(endPoint, petId);

		try {
			Log.testCaseInfo(
					"TC04 : Verify 404 Not Found response  for Invalid petId in GET petId API and verify the NumberFormatException error message");

			Response response = APIUtil.get(baseURLforPET, endPointWithId);
			int receivedStatusCode = response.getStatusCode();
			Log.assertThat(receivedStatusCode == expectedStatusCode, "Passed : Verified getting Invalid petID Status:",
					"Failed : Getting Wrong Status Code : " + receivedStatusCode + " Expected Status Code "
							+ expectedStatusCode);

			System.out.println(receivedStatusCode);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Test
	public void GetPetDeatilsBy() {

		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		String endPoint = testData.get("EndPoint");
		int expectedStatusCode = (int) Math.round(Double.parseDouble(testData.get("ExpectedStatusCode")));
		String petId = testData.get("PetId");
		String endPointWithId = String.format(endPoint, petId);

		try {
			Log.testCaseInfo(
					"TC05 : Verify 404 Not Found response  for Invalid petId in GET petId API and verify the Pet not found error message");

			Response response = APIUtil.get(baseURLforPET, endPointWithId);

			int receivedStatusCode = response.getStatusCode();
			Log.assertThat(receivedStatusCode == expectedStatusCode, "Passed : Verified getting Invalid petID Status:",
					"Failed : Getting Wrong Status Code : " + receivedStatusCode + " Expected Status Code " + 404);

			System.out.println(receivedStatusCode);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Test
	public void unautorizedResponse() throws Exception {

		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		String endPoint = testData.get("EndPoint");
		int expectedStatusCode = (int) Math.round(Double.parseDouble(testData.get("ExpectedStatusCode")));
		String authId = testData.get("PetId");

		try {
			Log.testCaseInfo(
					"TC06 : Verify 401 Unautorized response  for the GET Login info API for Invalid authorization");

			HashMap<String, String> headers = new HashMap<String, String>();
			headers.put(ApiTestdata.Authorization, authId);
			headers.put(ApiTestdata.ContentType, ApiTestdata.Application_Json);

			Response response = APIUtil.get(baseURLforTestFire, endPoint);

			int receivedStatusCode = response.getStatusCode();

			System.out.println("Status Code" + receivedStatusCode);
			Log.assertThat(receivedStatusCode == expectedStatusCode,
					"Passed : Verified getting Unautorized response Status:" + receivedStatusCode,
					"Failed : Getting Wrong Status Code : " + receivedStatusCode + " Expected Status Code "
							+ expectedStatusCode);

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Test
	public void postBadRequestResponse() throws Exception {
		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		String endPoint = testData.get("EndPoint");
		int expectedStatusCode = (int) Math.round(Double.parseDouble(testData.get("ExpectedStatusCode")));
		String requestBody = testData.get("CategoryName");

		try {
			Log.testCaseInfo(
					"TC07 : Verify 401 Unautorized response  for the GET Login info API for Invalid authorization");

			HashMap<String, String> headers = new HashMap<String, String>();
			headers.put(ApiTestdata.Authorization, generate_accessToken());
			headers.put(ApiTestdata.ContentType, ApiTestdata.Application_Json);

			Response response = APIUtil.postWithBody(baseURLforTestFire, headers, requestBody, endPoint);

			int receivedStatusCode = response.getStatusCode();

			System.out.println("Status Code" + receivedStatusCode);
			Log.assertThat(receivedStatusCode == expectedStatusCode,
					"Passed : Verified getting Bad Request Status: " + receivedStatusCode,
					"Failed : Getting Wrong Status Code : " + receivedStatusCode + " Expected Status Code "
							+ expectedStatusCode);

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Test
	public void deletePetDetails() throws Exception {

		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		String endPoint = testData.get("EndPoint");
		String name = testData.get("PetName");
		String status = testData.get("PetStatus");
		String categoryName = testData.get("CategoryName");
		String tagName = testData.get("TagName");
		int expectedStatusCode = (int) Math.round(Double.parseDouble(testData.get("ExpectedStatusCode")));
		try {
			Log.testCaseInfo("TC08 : Verify 200 response for delete pets DELETE API and verify the response");

			Random random = new Random();

			// Generate a random 5-digit number
			int petId = 10000 + random.nextInt(90000);

			HashMap<String, String> headers = new HashMap<String, String>();
			headers.put(ApiTestdata.ContentType, ApiTestdata.Application_Json);
			CreatePet pet = new CreatePet();
			Category category = new Category();
			Tag tag = new Tag();
			ArrayList<Tag> taglist = new ArrayList<Tag>();
			category.setId(petId);
			category.setName(categoryName);

			tag.setId(petId);
			tag.setName(tagName);

			taglist.add(tag);
			pet.setId(petId);
			pet.setName(name);
			pet.setStatus(status);
			pet.setCategory(category);
			pet.setPhotoUrls(new ArrayList<String>());

			ObjectMapper objectMapper = new ObjectMapper();
			String RequestBody = objectMapper.writeValueAsString(pet);

			Response response = APIUtil.postWithBody(baseURLforPET, headers, RequestBody, endPoint);
			int actualPetId = response.jsonPath().getInt("id");
			Log.message("created new pet details with petId : " + actualPetId);

			Response DeleteResponse = APIUtil.delete(baseURLforPET, headers, "", "", endPoint + "/" + actualPetId);
			int StatusCode = DeleteResponse.jsonPath().getInt("code");

			Log.assertThat(StatusCode == expectedStatusCode,
					"Deleted the pet details Successfully for petId : " + actualPetId,
					"Unable to delete the details check entered valid petId");

		} catch (Exception e) {
			Log.exception(e);

		}
	}

	@Test
	public void deletePetDetailsWithInvalidPetId() throws Exception {

		Map<String, String> testData = TestDataReader.readData(ApiTests.class.getSimpleName(), new ApiTests() {
		}.getClass().getEnclosingMethod().getName());

		String endPoint = testData.get("EndPoint");
		int expectedStatusCode = (int) Math.round(Double.parseDouble(testData.get("ExpectedStatusCode")));
		int petId = (int) Math.round(Double.parseDouble(testData.get("PetId")));

		try {
			Log.testCaseInfo(
					"TC09 : Verify 404 response  for selete pets DELETE API while pet id is missing or inavalid and verify the response");

			HashMap<String, String> headers = new HashMap<String, String>();
			headers.put(ApiTestdata.ContentType, ApiTestdata.Application_Json);
			Response DeleteResponse = APIUtil.delete(baseURLforPET, headers, "", "", endPoint + "/" + petId);
			int StatusCode = DeleteResponse.getStatusCode();

			Log.assertThat(StatusCode == expectedStatusCode,
					"Getting 404 error tried to delete pet details with invalid petId",
					"Error: Getting response as" + DeleteResponse.getBody().asPrettyString());

		} catch (Exception e) {
			System.out.println(e);

		}
	}

	public static String generate_accessToken() throws Exception {
		Response response = null;
		try {
			HashMap<String, String> headers = new HashMap<String, String>();
			headers.put("Content-Type", "application/json");
			Authorization auth = new Authorization();
			auth.setUsername("jsmith");
			auth.setPassword("demo1234");
			ObjectMapper objectMapper = new ObjectMapper();
			String RequestBody = objectMapper.writeValueAsString(auth);
			response = APIUtil.postWithBody("https://demo.testfire.net", headers, RequestBody, "/api/login");
			System.out.println(response.jsonPath().getString("Authorization"));

		} catch (Exception e) {
			Log.exception(e);
		}
		return response.jsonPath().getString("Authorization");
	}

}
