package com.aspire.template.tests;

import java.net.MalformedURLException;
import java.util.List;
import java.util.Optional;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v120.performance.Performance;
import org.openqa.selenium.devtools.v120.performance.model.Metric;
import org.openqa.selenium.remote.Augmenter;
import org.testng.annotations.Test;

import com.aspire.utils.web.WebDriverFactory;

public class Perf {
	String webSite = "https://systems.aspiresys.com";

	@Test
	public void performanceMetric() throws MalformedURLException {
		Boolean success = false;
		Augmenter augmenter = new Augmenter();
		WebDriver driver = augmenter.augment(WebDriverFactory.get());

		DevTools devTools = ((HasDevTools) driver).getDevTools();
		devTools.createSession();

		devTools.send(Performance.enable(Optional.empty()));
		List<Metric> metricList = devTools.send(Performance.getMetrics());

		driver.get(webSite);

		for (Metric m : metricList) {
			System.out.println(m.getName() + " = " + m.getValue());
			success = true;
		}

	}
}
