package com.aspire.template.tests;

public interface ApiTestdata {
	
	public final String ContentType = "Content-Type";
	public final String Application_Json = "application/json";
	public final String Authorization = "Authorization";

}
