package com.aspire.framework.tests;

import java.io.IOException;

import org.testng.annotations.Test;

import com.aspire.selfhealing.ApplyHealing;

public class SelfHealingLocatorUpdate {

	@Test(description = "locator auto update")
	public void tc_getHealedLocator() throws InterruptedException, IOException {
		ApplyHealing.getLocators();
	}

	@Test(description = "locator auto update")
	public void tc_applyHealing() throws InterruptedException, IOException {
		ApplyHealing.applyHealingToClass();
	}
}