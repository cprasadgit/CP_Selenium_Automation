
package com.aspire.framework.tests;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aspire.utils.Log;
import com.aspire.utils.nft.ExcelWrite;
import com.aspire.utils.nft.MetricsCalculation;
import com.aspire.utils.web.WebDriverFactory;

public class APTF_PerfSmoke {

	private String webSite;
	public static String workBookName;
	public static String workBookName_Updated;
	public static String scenarioName;
	public static Capabilities cap = null;
	public static String buildNumber;
	public String browser;
	public static String dbUrl;
	public static String WebdriverLocation;
	public static String OutputFileLocation;
	public static String MeasurementName;
	public static String testdata;
	public static String perfMetricCal;
	public static String influxDB;
	// String sheetName1 = "Smoke_AMICAE2E_";

	@BeforeMethod(alwaysRun = true)
	public void init(ITestContext context) throws IOException, InvalidFormatException {
		webSite = System.getProperty("webSite") != null ? System.getProperty("webSite")
				: context.getCurrentXmlTest().getParameter("webSite");

		perfMetricCal = context.getCurrentXmlTest().getParameter("PerfMetricCalExcel");
		influxDB = context.getCurrentXmlTest().getParameter("InfluxDBCon");
		buildNumber = context.getCurrentXmlTest().getParameter("buildNumber");
		browser = context.getCurrentXmlTest().getParameter("browser");
		dbUrl = context.getCurrentXmlTest().getParameter("dbUrl");
		MeasurementName = context.getCurrentXmlTest().getParameter("measurementName");
		scenarioName = context.getCurrentXmlTest().getParameter("scenarioName");
		workBookName = context.getCurrentXmlTest().getParameter("workBookName");
		workBookName_Updated = context.getCurrentXmlTest().getParameter("workBookName_Updated");

		OutputFileLocation = System.getProperty("user.dir") + File.separatorChar + "src" + File.separatorChar + "main"
				+ File.separatorChar + "resources" + File.separatorChar + "perfmetrics" + File.separatorChar;
		WebdriverLocation = System.getProperty("user.dir") + "\\drivers\\";

	}

	public void initPerfMetricsCal(String influxDBCon) throws Exception {
		try {
			System.out.println("testinitfuction");
			ExcelWrite.createWorkBook("Navigation Timing", "Dashboard", workBookName, OutputFileLocation);
			Map<String, String> startEndObj = new HashMap<String, String>();
			Map<String, Object> startEndObj1 = new HashMap<String, Object>();
			startEndObj1.put("testName", "Sample");
			long ts = System.currentTimeMillis();
			String timeStamp = String.valueOf(ts);
			startEndObj1.put("timeStamp", timeStamp);
			startEndObj.put("RunID", buildNumber);
			startEndObj.put("application", "IntranetSelenium");
			startEndObj.put("type", "started");
			if (influxDBCon.equalsIgnoreCase("true")) {
				InfluxDB influxDBS = InfluxDBFactory.connect(dbUrl, "influxdb", "qEEzTHTv3WOc2VPCh7yS");
				if (influxDBS != null) {
					System.out.println("Successfully connected to influxDB database test for entering start time");
				}
				Query dbquery = new Query("show databases", "");
				QueryResult databaseResultSet = influxDBS.query(dbquery);
				List<List<Object>> dbNames = databaseResultSet.getResults().get(0).getSeries().get(0).getValues();
				boolean ifDBExists = false;
				for (int i = 0; i < dbNames.size(); i++) {
					String dbName = dbNames.get(i).toString();
					if (dbName.equalsIgnoreCase("[" + MeasurementName + "]")) {
						ifDBExists = true;
						System.out.println("DB Already Exists");
					}
				}
				if (!ifDBExists) {
					System.out.println("Database does not Exist hence creating Database with name " + MeasurementName);
					Query createdatabaseQuery = new Query("create database " + MeasurementName);
					influxDBS.query(createdatabaseQuery);
				}
				String QueryString = "select testName From \"StartEndTime\" where RunID='" + buildNumber
						+ "' and type='started'";
				Query query = new Query(QueryString, MeasurementName);
				QueryResult resultSet = influxDBS.query(query);
				List<List<Object>> runIDs = null;
				try {
					runIDs = resultSet.getResults().get(0).getSeries().get(0).getValues();
					System.out.println("start time already exist for runID - " + buildNumber);
					System.out.println(runIDs);
				} catch (Exception e) {
					System.out.println("start time already not exist for runID - " + buildNumber);
				}
				if (runIDs == null) {
					System.out.println("Adding start time for runID - " + buildNumber);
					Point pointS = null;
					pointS = Point.measurement("StartEndTime").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
							.tag(startEndObj).fields(startEndObj1).build();
					System.out.println(pointS);
					BatchPoints batchPointsS = BatchPoints.database(MeasurementName).build();
					batchPointsS.point(pointS);
					influxDBS.write(batchPointsS);

				}
				influxDBS.close();
				System.out.println("testinitfuctionEND");
			} else
				System.out.println("There is no influx DB is connection established earlier to close");

		} catch (Exception e) {
			System.out.println("Exception that we caught is: " + e);
		}
	}

	public void addTestInfo(String testCaseId, String testDesc, WebDriver driver) {
		String test = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getName();

		String browsername = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest()
				.getParameter("browser");
		String browserversion = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest()
				.getParameter("browser_version");
		String os = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("os").substring(0,
				1);
		String osversion = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest()
				.getParameter("os_version");

		String browserwithos = os + osversion + "_" + browsername + browserversion;

		// return Log.testCaseInfo(testCaseId + " [" + test + "]" +
		// testCaseId + " - " + testDesc + " [" + browserwithos + "]");
	}

	@Test(description = "Perf Analysis")
	public void TC_01_AspirePage() throws Exception {

		final WebDriver driver = WebDriverFactory.get();
		// GetTestData testData;
		APTF_PerfSmoke amicaperf = new APTF_PerfSmoke();

		amicaperf.initPerfMetricsCal(influxDB);
		// testData = new GetTestData(sheetName1, tcId);

		Log.testCaseInfo("<small><b><i>[" + browser + "]</b></i></small>");

		try {
			List<String> urlList = new ArrayList<String>();
			driver.get(webSite);
			// Utils.waitForPageLoad(driver);
			urlList = MetricsCalculation.getUrlList(driver, perfMetricCal);
			MetricsCalculation.calculateMeasurement(MeasurementName, "TC_01_AspirePage", true, false, driver, browser,
					workBookName, urlList, buildNumber, dbUrl, OutputFileLocation, perfMetricCal, influxDB);
			ExcelWrite.copyFileUsingApacheCommonsIO(workBookName, workBookName_Updated, OutputFileLocation,
					perfMetricCal);
			Log.message("User accessed the customer application");

			/*-
			 * 
			LoginPage login = new LoginPage(driver);
			
			login.enterAndSubmitForm(testData.username, testData.password);
			Thread.sleep(5000);
			
			 */
			driver.get("https://amazon.in");
			MetricsCalculation.calculateMeasurement(MeasurementName, "TC_02_AmazonPage", false, true, driver, browser,
					workBookName, urlList, buildNumber, dbUrl, OutputFileLocation, perfMetricCal, influxDB);
			ExcelWrite.copyFileUsingApacheCommonsIO(workBookName, workBookName_Updated, OutputFileLocation,
					perfMetricCal);

		} catch (Exception e) {
			Log.exception(e);
		} finally {
			Log.endTestCase();
			driver.quit();
		}
	}

	@AfterSuite
	public void run() {

		System.out.println("End Timer Activated : " + System.currentTimeMillis() + ";");

		String columnName[] = { "Request", "Browser", "Type", "No of Request", "TotalTime", "TimetoFirstByte",
				"FirstPaint", "FirstContentfulPaint", "domInteractive", "DOMContentLoadedTime", "domComplete",
				"OnLoadTime", "transferSize" };

		String workBookName_Updated1 = workBookName_Updated;
		workBookName_Updated = "newsheet";

		System.out.println(workBookName_Updated1);
		System.out.println(workBookName_Updated);
		ArrayList<String> dashBoardColumn = new ArrayList<String>();
		// Push End Time to influxDB
		Map<String, String> startEndObj = new HashMap<String, String>();
		Map<String, Object> startEndObj1 = new HashMap<String, Object>();
		startEndObj1.put("testName", "Sample");
		long ts = System.currentTimeMillis();
		String timeStamp = String.valueOf(ts);
		startEndObj1.put("timeStamp", timeStamp);
		startEndObj.put("RunID", buildNumber);
		startEndObj.put("application", "IntranetSelenium");
		startEndObj.put("type", "finished");
		if (influxDB.equalsIgnoreCase("true")) {
			InfluxDB influxDBS = InfluxDBFactory.connect(dbUrl, "influxdb", "qEEzTHTv3WOc2VPCh7yS");
			if (influxDBS != null) {
				System.out.println("Successfully connected to influxDB database test for entering end time");
			}
			String QueryString = "select testName From \"StartEndTime\" where RunID='" + buildNumber
					+ "' and type='finished'";
			Query query = new Query(QueryString, MeasurementName);
			QueryResult resultSet = influxDBS.query(query);
			List<List<Object>> runIDs = null;
			try {
				runIDs = resultSet.getResults().get(0).getSeries().get(0).getValues();
				System.out.println(runIDs);
			} catch (Exception e) {
				System.out.println("end time already not exist for runID - " + buildNumber);
			}
			if (runIDs == null) {
				System.out.println("Adding end time for runID - " + buildNumber);
				Point pointS = null;
				pointS = Point.measurement("StartEndTime").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
						.tag(startEndObj).fields(startEndObj1).build();
				System.out.println(pointS);
				BatchPoints batchPointsS = BatchPoints.database(MeasurementName).build();
				batchPointsS.point(pointS);
				influxDBS.write(batchPointsS);

			}
			influxDBS.close();
		} else {
			System.out.println("There is no influx DB is connection established earlier to close");
		}

		try {

			// Copy Raw metrics to Updated sheet one last time

			Thread.sleep(10000); // Wait for 4 mins before copying
			System.out.println(
					"Excel - Copying Raw metrics for last time to the updated sheet @ " + System.currentTimeMillis());
			ExcelWrite.copyFileUsingApacheCommonsIO(workBookName, workBookName_Updated1, OutputFileLocation,
					perfMetricCal);

			HashSet<String> browserNameSet = ExcelWrite.getUniqueValueFromSheet("Navigation Timing",
					workBookName_Updated1, "browser", OutputFileLocation);
			for (String columnname : columnName) {
				dashBoardColumn.add(columnname);
			}

			for (String browserNameValue : browserNameSet) {
				HashSet<String> urlName = ExcelWrite.getUniqueTransactionForEachBrowser("Navigation Timing",
						workBookName_Updated1, "label", "browser", browserNameValue, OutputFileLocation);
				for (String urlNameValue : urlName) {
					ExcelWrite.filterExcelData("Navigation Timing", urlNameValue, browserNameValue, "Dashboard",
							workBookName_Updated1, dashBoardColumn, OutputFileLocation);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		// Utils.proxyClose();
	}

}