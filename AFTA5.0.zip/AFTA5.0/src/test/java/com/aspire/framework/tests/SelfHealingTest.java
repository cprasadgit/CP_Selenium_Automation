package com.aspire.framework.tests;

import java.net.MalformedURLException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aspire.pages.RpLoginPage;
import com.aspire.pages.SignInPageGw;
import com.aspire.selfhealing.AftaDriver;
import com.aspire.selfhealing.AmazonSignInPage;
import com.aspire.selfhealing.Driver;
import com.aspire.utils.Log;
import com.aspire.utils.web.WebDriverFactory;
import com.aspire.utils.web.WebUtils;
import com.epam.healenium.SelfHealingDriver;

public class SelfHealingTest {

	@Test(description = "SelfHealing AmazonPage")
	// SelfHealingTest
	public void tc_00() throws Exception {
		String webSite = "https://www.amazon.in/";

		Log.testCaseInfo("SelfHealing AmazonPage");

		//Driver driver = AftaDriver.getDriverInstance();
//		SelfHealingDriver driver = SelfHealingDriver.create(WebDriverFactory.get());
		WebDriver driver = WebDriverFactory.get();
		driver.get(webSite);

		Thread.sleep(2000);

		WebElement element = driver.findElement(By.id("nav-link-accountList"));

//		WebUtils.clickByActionsClass(driver, element, "");
		element.click();

		// Alter DOM and change ID attribute of password field
		WebElement nameTextbox = driver.findElement(By.id("ap_email"));
		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('id','idEditedg12')", nameTextbox);

		AmazonSignInPage amazonSignInPage = new AmazonSignInPage(driver);
		amazonSignInPage.typeTextIntoEmailOrMobilePhoneNumber1("Magesh");
		amazonSignInPage.clickByContinuingYouAgreeToAmazonsConditionsOfUseAndButton();
		driver.quit();

		Log.pass("SelfHealing AmazonPage");
	}

	// @Test(description = "SelfHealing Test")
	public void tc_0() throws Exception {
		String webSite = "http://172.24.135.200:8480/pc/PolicyCenter.do";

		Log.testCaseInfo("SelfHealing Gw");

		SelfHealingDriver driver = SelfHealingDriver.create(WebDriverFactory.get());
		driver.get(webSite);

		SignInPageGw signInPageGw = new SignInPageGw(driver);
		signInPageGw.typeTextIntoUsername("username");
		signInPageGw.typeTextIntoPassword("password");
		signInPageGw.clickLogin();
		driver.quit();

		Log.pass("SelfHealing Gw");
	}

	// @Test
	// SelfHealingTest
	public void tc_01() throws MalformedURLException, InterruptedException {
		String webSite = "https://testautomationpractice.blogspot.com/";

		WebDriver driver1 = WebDriverFactory.get();
		driver1.get(webSite);
		System.out.println(driver1.getCurrentUrl());

		Log.testCaseInfo(webSite);

		WebDriver driver = SelfHealingDriver.create(WebDriverFactory.get());

		driver.get(webSite);

		By byName = By.id("name");

		// Alter DOM and change ID attribute of password field
		WebElement nameTextbox = driver.findElement(byName);
		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('id','idEditedg12')", nameTextbox);
		nameTextbox = driver.findElement(byName);
		nameTextbox.sendKeys("Test_Input");

		// demo purpose- hold the execution for 2 secs
		Thread.sleep(1000);

		driver.quit();
	}

	// @Test
	// SelfHealingTest
	public void tc_angular() throws MalformedURLException, InterruptedException {
		String webSite = "https://www.upwork.com/";
		WebDriver driver = SelfHealingDriver.create(WebDriverFactory.get());

		driver.get(webSite);

		By byLogin = By.cssSelector("a[href='/blog']");

		// Alter DOM and change ID attribute of password field
		WebElement loginButton = driver.findElement(byLogin);
		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('href','/ab/account-security/login123')",
				loginButton);
		loginButton = driver.findElement(byLogin);
		loginButton.click();

		// demo purpose- hold the execution for 2 secs
		Thread.sleep(1000);

		driver.quit();
	}

	// @Test
	// SelfHealingTest
	public void tc_react() throws MalformedURLException, InterruptedException {
		String webSite = "https://www.producthunt.com/products/uxpin";
		SelfHealingDriver driver = SelfHealingDriver.create(WebDriverFactory.get());

		driver.get(webSite);

		By bySearchBox = By.cssSelector("input[title='Search']");

		// Alter DOM and change ID attribute of password field
		WebElement searchTextbox = driver.findElement(bySearchBox);
		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('title','idEditedg12')", searchTextbox);
		// nameTextbox = driver.findElement(byName);
		searchTextbox.sendKeys("Test_Input");

		// demo purpose- hold the execution for 2 secs
		Thread.sleep(1000);

		driver.quit();
	}

	// @Test
	// SelfHealingTest
	public void tc_rp() throws Exception {
		String webSite = "https://dev-manage.revolutionparts.com/login";
		SelfHealingDriver driver = SelfHealingDriver.create(WebDriverFactory.get());

		driver.get(webSite);
		RpLoginPage rpLoginPage = new RpLoginPage(driver);
		rpLoginPage.typeTextIntoEmail("ddd");

		// Alter DOM and change ID attribute of password field
		WebElement loginButton = driver.findElement(By.id("1-email"));
		By byLogin = By.id("1-email");
		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('id','12-email')", loginButton);
		loginButton = driver.findElement(byLogin);
		loginButton.sendKeys("hg");

		rpLoginPage.typeTextIntoEmail("ddd");

		// demo purpose- hold the execution for 2 secs
		Thread.sleep(1000);

		driver.quit();
	}

}