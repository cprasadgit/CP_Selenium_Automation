package com.aspire.framework.tests;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aspire.utils.nft.AccessibilityUtils;
import com.aspire.utils.nft.ReportConfiguration;
import com.aspire.utils.nft.SecurityUtil;
import com.aspire.utils.nft.SecurityUtil.DriverType;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class AllyAndSecurityTest {

	WebDriver driver;

	@BeforeTest
	public void init() throws Exception {

		// create Self-healing driver
		driver = SecurityUtil.setupWebDriver(DriverType.EDGE, true);
		driver.manage().window().maximize();

		// Application login-Pre setup to follow
	}

	@DataProvider(name = "testData")
	public static Iterator<Object[]> provideTestData() throws IOException, CsvValidationException {
		String csvFilePath = "nftTestData.csv";
		List<Object[]> testData = new ArrayList<>();
		boolean isFirstEntry = true;
		try (CSVReader csvReader = new CSVReader(
				new InputStreamReader(AllyAndSecurityTest.class.getResourceAsStream("/testdata/" + csvFilePath)))) {
			String[] data;
			while ((data = csvReader.readNext()) != null) {
				if (!isFirstEntry)
					testData.add(data);
				else
					isFirstEntry = false;

			}
		}

		return testData.iterator();
	}

	@Test(dataProvider = "testData")
	public void allyAndSecuritytTest(String pageName, String url) throws InterruptedException {

		try {
			driver.get(url);

			Thread.sleep(1000);
			// Accessbility testing
			new AccessibilityUtils(driver).performFullPageAccessibilityScan(pageName);

			// Security testing
			SecurityUtil securityUtil = new SecurityUtil();
			securityUtil.waitForPassiveScanToComplete();
			securityUtil.reportGeneration(pageName);
			securityUtil.checkRiskCount(pageName, url);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterTest
	public void generateReport() throws IOException, URISyntaxException {
		driver.quit();
		ReportConfiguration.generateReport();
	}

}
