package com.aspire.framework.tests;

import java.net.MalformedURLException;

import org.testng.annotations.Test;

import com.aspire.utils.Log;
import com.aspire.utils.web.WebDriverFactory;
import com.epam.healenium.SelfHealingDriver;

public class ReportTestScript {

	@Test
	public void tc01_ExtentReportPass() {
		Log.testCaseInfo("Test- ExtentReport Pass");
		Log.message("message");
		Log.event("event");
		Log.pass("Pass");
		Log.endTestCase();
	}

	@Test
	public void tc02_ExtentReportFail() {
		Log.testCaseInfo("Test- ExtentReport Fail");
		Log.message("message");
		Log.event("event");
		Log.fail("Fail");
		Log.endTestCase();
	}

	@Test
	public void tc03_ExtentReportScreenshot() throws MalformedURLException {
		Log.testCaseInfo("Test- ExtentReport Screenshot1");

		SelfHealingDriver driver = SelfHealingDriver.create(WebDriverFactory.get());
		driver.get("https://www.google.com/");
		Log.message("message1", driver, true);
		Log.message("message2", driver, true);
		Log.message("message3", driver, true);
		driver.quit();
		Log.endTestCase();
	}

}