package com.aspire.framework.tests;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.testng.annotations.Test;

import com.aspire.utils.testdata.TestDataReader;

public class DataReaderTestScript {

	@Test
	// readDataFromExcel
	public void tc_01() {
		Map<String, String> testData = TestDataReader.readData(DataReaderTestScript.class.getSimpleName(),
				new DataReaderTestScript() {
				}.getClass().getEnclosingMethod().getName());

		testData.forEach((k, v) -> System.out.println(k + "" + v));
	}

	@Test
	// readDataFromGoogleSheet
	public void tc_02() {
		Map<String, String> testData = TestDataReader.readData(DataReaderTestScript.class.getSimpleName(),
				new DataReaderTestScript() {
				}.getClass().getEnclosingMethod().getName());
		testData.forEach((k, v) -> System.out.println(k + " - " + v));
	}

	@Test
	// readDataFromGoogleSheet
	public void tc_03() {
		Map<String, String> testData = TestDataReader.readData(DataReaderTestScript.class.getSimpleName(),
				new DataReaderTestScript() {
				}.getClass().getEnclosingMethod().getName());
		testData.forEach((k, v) -> System.out.println(k + "" + v));
	}

	@Test
	public void tc04() throws IOException {
		InputStream inputStream = DataReaderTestScript.class.getResourceAsStream("/mainSource.js");
		String text = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
		System.out.println(text);
	}

}