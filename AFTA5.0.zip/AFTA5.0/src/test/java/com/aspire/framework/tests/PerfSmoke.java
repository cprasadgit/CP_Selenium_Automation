package com.aspire.framework.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.json.JSONObject;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aspire.utils.Log;
import com.aspire.utils.nft.PerfUtils;
import com.aspire.utils.web.WebDriverFactory;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;

public class PerfSmoke {

	private String webSite;
	public static String workBookName;
	public static String workBookName_Updated;
	public static String scenarioName;
	public static Capabilities cap = null;
	public static String buildNumber;
	public String browser;
	public static String dbUrl;
	public static String WebdriverLocation;
	public static String OutputFileLocation;
	public static String measurementName;
	public static String testdata;
	public static boolean perfMetricCal;
	public static boolean influxDB;
	public static Date testStartTime;
	public static Date testEndTime;

	public static List<JSONObject> responses = new ArrayList<>();

	@BeforeMethod(alwaysRun = true)
	public void init(ITestContext context) throws IOException, InvalidFormatException {
		webSite = Objects.nonNull(System.getProperty("webSite")) ? System.getProperty("webSite")
				: context.getCurrentXmlTest().getParameter("webSite");

		perfMetricCal = Boolean.valueOf(context.getCurrentXmlTest().getParameter("PerfMetricCalExcel"));
		influxDB = Boolean.valueOf(context.getCurrentXmlTest().getParameter("InfluxDBCon"));
		buildNumber = context.getCurrentXmlTest().getParameter("buildNumber");
		browser = context.getCurrentXmlTest().getParameter("browser");
		dbUrl = context.getCurrentXmlTest().getParameter("dbUrl");
		measurementName = context.getCurrentXmlTest().getParameter("measurementName");
		scenarioName = context.getCurrentXmlTest().getParameter("scenarioName");
		workBookName = context.getCurrentXmlTest().getParameter("workBookName");
		// workBookName_Updated =
		// context.getCurrentXmlTest().getParameter("workBookName_Updated");
		OutputFileLocation = System.getProperty("user.dir");
		WebdriverLocation = System.getProperty("user.dir") + "\\drivers\\";

		// Test starting time
		testStartTime = new Date();
	}

	@Test(description = "Perf Analysis")
	public void TC_01_LearnOS() throws Exception {

		Log.testCaseInfo("<small><b><i>[" + browser + "]</b></i></small>");

		// PerfUtils.getDBConnection(Boolean.valueOf(influxDB), dbUrl, measurementName,
		// buildNumber);

		WebDriver driver = null;

		try {

			driver = WebDriverFactory.get();
			driver.get("https://systems.aspiresys.com");
			List<String> urlList = PerfUtils.getUrlList(driver, Boolean.valueOf(perfMetricCal));
			responses.add(PerfUtils.calculateMeasurement(measurementName, "TC_01_Aspiresys_Page", true, false, driver,
					browser, urlList, buildNumber, dbUrl, perfMetricCal, influxDB));
			Log.message("Aspiresys-PerfAnaylzed");

			// ----------------------------------------------------------------------------------------------------------------------

			driver.get("https://amazon.in");
			urlList = PerfUtils.getUrlList(driver, perfMetricCal);
			responses.add(PerfUtils.calculateMeasurement(measurementName, "TC_02_Amazon_Page", false, true, driver,
					browser, urlList, buildNumber, dbUrl, perfMetricCal, influxDB));
			Log.message("AmazonPage-PerfAnaylzed");

			// ----------------------------------------------------------------------------------------------------------------------

			driver.get("https://www.ebay.com");
			urlList = PerfUtils.getUrlList(driver, perfMetricCal);
			responses.add(PerfUtils.calculateMeasurement(measurementName, "TC_03_eBay_Page", false, true, driver,
					browser, urlList, buildNumber, dbUrl, perfMetricCal, influxDB));
			Log.message("eBayPage-PerfAnaylzed");

			//Log.testCaseResult(driver);
		} catch (Exception e) {
			Log.exception(e);
		} finally {
			 Log.endTestCase();
			 driver.quit();
		}
	}

	@AfterSuite
	public void generateReport() throws IOException {
		testEndTime = new Date();
		PerfUtils.createPerfResultSheet(responses, testStartTime, testEndTime);
	}

}
